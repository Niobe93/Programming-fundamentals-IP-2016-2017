
/**
 * Write a description of class Plane here.
 * 
 * @author Gema Rico Pozas 
 * @version 04/10/2016
 */
public class Plane
{
    //Constantes de la clase plane

    public final static int MIN_FUEL=0;
    public final static int MAX_FUEL=5000;
    public final static char MIN_IDENTIFIER='A';
    public final static char MAX_IDENTIFIER='Z';

    //Constantes de equipaje y precio del ticket
    public final static int MIN_PRICE_OF_TICKET=0;
    public final static int MIN_WEIGHT_OF_LUGGAGE=0;

    //Constantes de posición
    public final static int MAX_X_Y=10;
    public final static int MIN_X_Y=0;    

    //Constantes de velocidad
    public final static int MAX_SPEED=1;
    public final static int MIN_SPEED=-1;

    //Atributos de la clase plane

    private char identifier;
    private int fuel;
    private Person pilot;
    private int xPos;
    private int yPos;
    private int xSpeed;
    private int ySpeed;

    /**
     * Constructor for objects of class Plane
     */
    public Plane()
    {
        setIdentifier ('A');
        setFuel (0);
    }

    /**
     * Constructor for objects of class Plane with parametres
     */
    public Plane (Person pilot, char identifier, int fuel)
    { 
        this();
        setPilot (pilot);
        setFuel (fuel);
        setIdentifier (identifier);
    }    

    /**
     *  Método que modifica el valor del atributo combustible
     *
     * @param cambia el valor del atributo fuel del tipo int
     * 
     */
    private void setFuel (int fuel)
    {
        this.fuel = fuel;
    }

    /**
     * Método que devuelve el valor del atributo combustible
     *
     * @return devuelve el valor del atributo fuel del tipo int
     */
    public int getFuel()
    { 
        return fuel ;
    }

    /**
     *  Método que modifica el valor del atributo identificador
     *
     * @param cambia el valor del atributo identificador del tipo char
     */
    private void setIdentifier (char identifier)
    {
        if(identifier >= MIN_IDENTIFIER && identifier <= MAX_IDENTIFIER)
            this.identifier = identifier;
    }

    /**
     * Método que devuelve el valor del atributo identificador
     *
     * @return devuelve el valor del atributo identifier del tipo char
     */
    public char getIdentifier()
    { 
        return identifier ;
    }

    /**
     * Método que modifica el valor del atributo pilot
     *
     * @param cambio del valor del atributo piloto del tipo person
     * 
     */
    private void setPilot(Person pilot)
    {
        this.pilot = pilot;
    }

    /**
     * Método que devuelve el valor del atributo pilot
     *
     * @return devuelve el valor del atributo piloto del tipo Person
     */
    public Person getPilot ()
    { 
        return pilot ;
    } 

    /**
     * Método que modifica el valor de la posición "x" del avión
     *
     * @param cambio del valor de la posición "x" de Plane de tipo int
     * 
     */
    private void setXPos(int xPos)
    {
        if ((xPos <=  MAX_X_Y) && (xPos >= MIN_X_Y))
            this.xPos = xPos;
    }

    /**
     * Método que devuelve el valor de la posición  "x" del avión
     *
     * @return devuelve el valor del atributo Xpos del tipo int
     */
    public int getXPos()
    { 
        return xPos ;
    }

    /**
     * Método que modifica el valor de la posición "y" del avión
     *
     * @param cambio del valor de la posición "y" de Plane de tipo int
     * 
     */
    private void setYPos(int yPos)
    {
        if ((yPos <=  MAX_X_Y) && (yPos >= MIN_X_Y))
            this.yPos = yPos;
    }

    /**
     * Método que devuelve el valor de la posición  "y" del avión
     *
     * @return devuelve el valor del atributo Ypos del tipo int
     */
    public int getYPos()
    { 
        return yPos ;
    }

    /**
     * Método que modifica el valor de la velocidad "x" del avión
     *
     * @param cambio del valor de la velocidad "x" de Plane de tipo int
     * 
     */
    private void setXSpeed(int xSpeed)
    {
        if (( xSpeed <= MAX_SPEED) && (xSpeed >= MIN_SPEED))
            this.xSpeed = xSpeed;
    }

    /**
     * Método que devuelve el valor de la velocidad "x" del avión
     *
     * @return devuelve el valor del atributo XSpeed del tipo int
     */
    public int getXSpeed()
    { 
        return xSpeed ;
    }

    /**
     * Método que modifica el valor de la posición "y" del avión
     *
     * @param cambio del valor de la posición "y" de Plane de tipo int
     * 
     */
    private void setYSpeed(int ySpeed )
    {
        if (( ySpeed <= MAX_SPEED) && (ySpeed >= MIN_SPEED))
            this.ySpeed = ySpeed;
    }

    /**
     * Método que devuelve el valor de la velocidad y del avión
     *
     * @return devuelve el valor del atributo YSpeed del tipo int
     */
    public int getYSpeed()
    { 
        return ySpeed ;
    }

    /**
     * Método que devuelve la información del piloto si lo tiene asignado, del combustible y del identificador del avión.
     *
     * 
     * @return devuelve el identificador del avión, el combustible y si tiene un piloto asignado su información (nombre, apellidos y edad) y si no la cadena "no pilot"
     */

    public String toString()
    {
        if ( getPilot() == null )

            return (this.getIdentifier() + "-" + this.getFuel() + "-" + "NO PILOT");

        else
            return (this.getIdentifier() + "-" + this.getFuel() + "-" + pilot.getHashCode());
    }

    /**
     * Método que devuelve el coste del viaje
     *
     * @param luggageWeith es el peso del equipaje 
     * @param ticketCost es el precio del billete
     * 
     * @return    devuelve el coste del viaje según el peso del equipaje
     */
    public double travelCost(int ticketCost, int luggageWeight)
    {

        if ((luggageWeight) <= MIN_WEIGHT_OF_LUGGAGE||  (ticketCost <=MIN_PRICE_OF_TICKET))
            return 0;

        else if( luggageWeight > 50 )
            return ((ticketCost * 0.12) + ticketCost );

        else if ((luggageWeight > 20 ) && ( luggageWeight <= 50))
            return ((ticketCost * 0.06) + ticketCost);

        else if ((luggageWeight <= 20 ) && ( luggageWeight > MIN_WEIGHT_OF_LUGGAGE))
            return ticketCost + 5;   

        else 
            return 0;

    }

    /**
     * Método que modifica la velocidad relativa del avión
     *
     * @param  xSpeed // velocidad de la coordenada x en el plano (-1,0,1)
     * @param ySpeed // velocidad de la coordenada y en el plano (-1,0,1)
     * 
     */
    public void accelerate( int xSpeed, int ySpeed )
    {
        if (( xSpeed <= MAX_SPEED) && (xSpeed >= MIN_SPEED) &&( ySpeed <= MAX_SPEED) && (ySpeed >= MIN_SPEED))

        {  this.xSpeed = xSpeed;

            this.ySpeed = ySpeed;
        }

    }

    /**
     * An example of a method - replace this comment with your own
     *
     * 
     * @return// devuelve false si la cantidad de combustible es cero y devuelve true si la cantidad de combustible es distinta de cero y disminuye una unidad.
     */
    public boolean fly ()
    {
        if ( getFuel() == MIN_FUEL )
            return false;
        
        else 
          {
            setFuel(getFuel() - 1);
            return true;
          }
    }

}
