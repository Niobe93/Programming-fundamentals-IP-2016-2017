
/**
 * Class Wheel para sesion 6 del laboratorio de IP
 * 
 * @author Gema Rico Pozas
 * @version 19/10/2016
 */
public class Wheel
{
    //Constantes de la clase Wheel 
    
    public static final double THRESHOLD=85; //porcentaje de presión para que la rueda sea operativa
    
    public static final double DEFAULT_MAX_PRESSURE = 0;
    public static final double DEFAULT_PRESSURE = 0;
    
    // instance variables 
    private double maxPressure; //indica la capacidad max de la rueda en milibares
    private double pressure; //indica la presion del aire  de la rueda en milibares

    /**
     * Constructor sin parámetro for objects of class Wheel
     */
    public Wheel()
    {
        setMaxPressure(DEFAULT_MAX_PRESSURE);
        setPressure(DEFAULT_PRESSURE);
    }    
    
    /**
     * Constructor con parámetros presión y presión máxima for objects of class Wheel
     */
    public Wheel(double pressure, double maxPressure)
    {
        this();
        setPressure(pressure);
        setMaxPressure(maxPressure);
    
    }

    /**
     * Método que modifica el valor de la presión máxima de la rueda
     * 
     * @param  presión máxima de la rueda de tipo double.
     * 
     */
    private void setMaxPressure(double maxPressure)
    {
       if (maxPressure >=0)
        this.maxPressure = maxPressure;
    }
    
    /**
     * Método que modifica la presión de la rueda
     * 
     * @param  presión de la rueda de tipo double.
     * 
     */
    private void setPressure(double pressure)
    {
        if (pressure >=0)
          this.pressure = pressure;
    }
    

    /**
     * Método que devuelve la presión máxima de la rueda
     *
     * 
     * @return  // devuelve la presión máxima de la rueda
     */
    public double getMaxPressure()
    {
        return maxPressure;
    }
    
    /**
     * Método que devuelve la presión de la rueda
     *
     * 
     * @return // devuelve la presión de la rueda
     */
    public double getPressure()
    {
         return pressure;
    }
    

    /**
     * Método que valida el estado de la rueda
     *
     * 
     * @return // devuelve true si la presión de la rueda es mayor o igual que el 85% de la presión máxima de la rueda
     * @return // devuelve false si no se cumple la condición anterior
     */
    public boolean test()
    {
        if ( getPressure() >= (THRESHOLD * getMaxPressure())/100)
          return true;
        else 
          return false;
        
    }    
    
    /**
     * Método que devuelve el porcentaje de presión de la rueda
     * 
     * @return // devuelve el porcentaje de la presión de la rueda.
     * 
     */
    private double getPercentage()
    {
     return ((this.getPressure() * 100 ) / this.getMaxPressure());
    }    
    
     /**
     * Método que devuelve una cadena de caracteres que informa del estado actual de la rueda
     * 
     * @return // devuelve: la presión máxima en milibares, la presión en milibares, el porcentaje de la presión y la validación de la rueda.
     * 
     */    
    public String toString ()

    { 
        return " MaxP: " + this.getMaxPressure() + " Mb " + " - " + " Pressure: " + this.getPressure() + " Mb " + " - " + " Percentage: " 
        + String.format("%.2f",this.getPercentage()) + " - " + " Test: " + this.test();

    }
    
     /**
     * Método que muestra por pantalla (salida estándar) una cadena de caracteres con información del la clase rueda
     *
     * //Imprime en pantalla la información de la presión máxima de la rueda y la presión actual y el porcentaje. Ok, si ha pasado el test, fail si no lo ha pasado.
     */
    public void print ()
    {
         if ( this.test()== true)
          {
            System.out.println(" Max Pressure......." + this.getMaxPressure() + " Mb ");
            System.out.println(" Current Pressure... " + this.getPressure() + " Mb" +  String.format ("(%.2f", this.getPercentage())+" %)");
            System.out.println(" Test..... OK ");
          }
         else 
          {
            System.out.println(" Max Pressure......." + this.getMaxPressure() + " Mb ");
            System.out.println(" Current Pressure... " + this.getPressure() + " Mb" +  String.format ("(%.2f", this.getPercentage())+" %)");
            System.out.println(" Test..... FAIL ");
          }
    }



}
