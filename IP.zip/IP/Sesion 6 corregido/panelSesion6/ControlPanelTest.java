

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class ControlPanelTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class ControlPanelTest
{
    /**
     * Default constructor for test class ControlPanelTest
     */
    public ControlPanelTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }    
   
    @Test
    public void testPress()
    {
        //crear un objeto de la clase controlpanel los estados inciales del interruptor y bombilla es ON (true)
        ControlPanel controlP1 = new ControlPanel();
        
        //CASO 1 llamamos al metodo press y cambiamos el estado a false (de encendido a apagado)
        controlP1.press();
        assertEquals(false, controlP1.getLampState());
        assertEquals(false, controlP1.getSwitchState());
        
        //CASO 2 llamamos al metodo press y cambiamos el estado a true(de apagado a encendido)
        controlP1.press();
        assertEquals(true, controlP1.getLampState());
        assertEquals(true, controlP1.getSwitchState());
    }

    @Test
    public void testMovePotentiometer()
    {
        //creamos un objeto control panel y comprobamos valores inciales de posicion y temperatura, 0 y 10 respectivamente.
        ControlPanel controlP1 = new ControlPanel();
        assertEquals(0, controlP1.getPosition());
        assertEquals(10.0, controlP1.getTemperature(), 0.1);
        
        //CASO 1 llamamos al metodo move y cambiamos el potenciometro a un valor intermedio 
        controlP1.movePotentiometer(5);
        assertEquals(5, controlP1.getPosition());
        assertEquals(10.0, controlP1.getTemperature(), 0.1);
        
        //PRUEBAS POSITIVAS
        
        //CASO 2 llamamos al metodo y cambiamos el potenciometro al valor superior del limite (temperatura a 27)
        controlP1.movePotentiometer(10);
        assertEquals(10, controlP1.getPosition());
        assertEquals(27.0, controlP1.getTemperature(), 0.1);
        
        //CASO 3 llamamos al metodo y cambiamos el potenciometro a 1 (temperatura no cambia)
        controlP1.movePotentiometer(1);
        assertEquals(1, controlP1.getPosition());
        assertEquals(27.0, controlP1.getTemperature(), 0.1);
        
        //PRUEBAS NEGATIVAS
        
        //CASO 4  llamamos al metodo y cambiamos el potenciometro a un valor negativo (posicion y temperatura no cambia)      
        controlP1.movePotentiometer(-3);
        assertEquals(1, controlP1.getPosition());
        assertEquals(27.0, controlP1.getTemperature(), 0.1);
        //CASO 5  llamamos al metodo y cambiamos el potenciometro a un valor superior al maximo (posicion y temperatura no cambia) 
        controlP1.movePotentiometer(12);
        assertEquals(1, controlP1.getPosition());
        assertEquals(27.0, controlP1.getTemperature(), 0.1);
    }
}



