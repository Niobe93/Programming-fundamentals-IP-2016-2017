

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class HeaterTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class HeaterTest
{
    /**
     * Default constructor for test class HeaterTest
     */
    public HeaterTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }

    

    @Test
    public void testChangeTemperature()
    {
        //crear un objeto radiador
        Heater heater1 = new Heater(); 
        //PRUEBAS POSITIVAS
        //CASO 1 cambiar temperatura a el valor minimo
        heater1.changeTemperature(10);
        assertEquals("10.0ºC", heater1.toString());
        //CASO 2 cambiar temperatura a un valor intermedio
        heater1.changeTemperature(20);
        assertEquals("20.0ºC", heater1.toString());
        //CASO 3 cambiar temperatura a el valor maximo
        heater1.changeTemperature(27);
        assertEquals("27.0ºC", heater1.toString());
        
        //PRUEBAS NEGATIVAS
        //CASO 4 cambiar temperatura a 0
        heater1.changeTemperature(0);
        assertEquals("27.0ºC", heater1.toString());
        //CASO 5 cambiar temperatura a un valor superior
        heater1.changeTemperature(28);
        assertEquals("27.0ºC", heater1.toString());
    }

    @Test
    public void testToString()
    {
        //crear un objeto clase Heater
        Heater heater1 = new Heater();        
        assertEquals("10.0ºC", heater1.toString());
        //PRUEBAS POSITIVAS
        //CASO 1 cambiar temperatura a el valor superior
        heater1.changeTemperature(27);
        assertEquals("27.0ºC", heater1.toString());
        //CASO 2 cambiar temperatura a el valor intermedio
        heater1.changeTemperature(15);
        assertEquals("15.0ºC", heater1.toString());
        
        //PRUEBAS NEGATIVAS
        //CASO 3 cambiar temperatura a 0
        heater1.changeTemperature(0);
        assertEquals("15.0ºC", heater1.toString());      
        //CASO 4 cambiar temperatura a un valor superior
        heater1.changeTemperature(28);
        assertEquals("15.0ºC", heater1.toString());
    }
}



