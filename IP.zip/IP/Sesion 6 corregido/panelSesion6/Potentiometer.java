
/**
 * Class Potentiometer para laboratorio de IP.
 * 
 * @author Gema Rico Pozas 
 * @version 25/10/2016
 */
public class Potentiometer
{
    public final static int MAX_POSITION=10; //maxima posicion del potenciometro
    public final static int MIN_POSITION=0; //minima posicion del potenciomtetro

    // instance variables 
    private int position;

    /**
     * Constructor for objects of class Potentiometer
     */
    public Potentiometer()
    {
        position=MIN_POSITION;
    }    

    /**
     * Método que representa la posición al que se puede colocar entre 0 y 10
     * 
     * @param  posición del potenciometro entre 0 y 10.
     * 
     */
    public void movePosition(int position)
    {
        if ((position >= MIN_POSITION) && (position <= MAX_POSITION))
            this.position = position;

    }

    /**
     * Metodo que devuelve el valor del potenciometro
     *
     * 
     * @return devuelve el valor del potenciometro con un valor int desde 0 a 10
     */
    public int getPosition()
    {

        return this.position;
    }

    /**
     * Método que devuelve una cadena de caracteres.
     *
     * @return una cadena con el valor de la posición
     */

    public String toString ()

    { 
        return String.valueOf(position);

    }    
}
