

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class PotentiometerTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class PotentiometerTest
{
    /**
     * Default constructor for test class PotentiometerTest
     */
    public PotentiometerTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }

    @Test
    public void testMovePosition()
    {
        //crear un objeto clase potenciometro
        Potentiometer potentio1 = new Potentiometer();
        //PRUEBAS POSITIVAS
        //CASO 1 cambiar posicion a valor intermedio        
        potentio1.movePosition(5);
        assertEquals("5", potentio1.toString());
        //CASO 2 cambiar posicion a valor superior
         potentio1.movePosition(10);
        assertEquals("10", potentio1.toString());
        //CASO 3 cambiar posicion a el minimo
        potentio1.movePosition(0);
        assertEquals("0", potentio1.toString());
        //PRUEBAS NEGATIVAS
        //CASO 4 cambiar posicion a valor superior al maximo
         potentio1.movePosition(12);
        assertEquals("0", potentio1.toString());
        //CASO 5 cambiar posicion a un valor negativo
         potentio1.movePosition(-5);
        assertEquals("0", potentio1.toString());
    }

    @Test
    public void testToString()
    {
        //creamos un objeto de la clase potentiometer, ejecutamos el metodo y nos devuelve los valores inciales, 0
        Potentiometer potentio1 = new Potentiometer();
        assertEquals("0", potentio1.toString());
        //cambiamos el valor a 5 y nos devuelve 5.
        potentio1.movePosition(5);
        assertEquals("5", potentio1.toString());
    }
}


