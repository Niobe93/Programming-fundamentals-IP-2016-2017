
/**
 * Class Lamp para sesion 6 de laboratorio de IP
 * 
 * @author Gema Rico Pozas 
 * @version 19/10/2016
 */
public class Lamp
{
    public final static boolean LAMP_ON=true;
    public final static boolean LAMP_OFF=false;
    
    // instance variables 
    private boolean lampState; //LAMP_ON = true ; LAMP_OFF =  false
    

    /**
     * Constructor for objects of class Lamp
     */
    public Lamp()
    {
        lampState= LAMP_ON;
        
    } 
    
    /**
     * Metodo que devuelve el estado de la bombilla
     * 
     * @return devuelve el estado de la bombilla
     */
    public boolean getLampState()
    {

        return this.lampState;
        
    }
    
    /**
     * Método que enciende la bombilla
     *
     * @param //modifica el estado de la bombilla a encendida: lampState = true indica encendida
     */
    public void turnOn()
    {
        lampState = LAMP_ON;
          
    }

    /**
     * Método que apaga la bombilla
     *
     * @param // modifica el estado de la bombilla a apagada: lampState = false indica apagada
     */
    public void turnOff()
    {
        lampState = LAMP_OFF;
          
    }
    
    /**
     * Método que devuelve una cadena de caracteres.
     *
     * @return una cadena con la representación del estado de la bombilla. //APAGADA cuando false, ENCENDIDA cuando true.
     */

    public String toString ()

    { 
        if(lampState == LAMP_ON)
         return " ENCENDIDA ";
        else if(lampState == LAMP_OFF)
         return " APAGADA ";
         else 
         return "ERROR";

    }    
    }
