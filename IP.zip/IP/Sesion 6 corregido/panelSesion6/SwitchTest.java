

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class SwitchTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class SwitchTest
{
    /**
     * Default constructor for test class SwitchTest
     */
    public SwitchTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }

    @Test
    public void testPress()
    {
        //crear objeto interruptor y comprobamos que esta encendido
        Switch switch1 = new Switch();        
        assertEquals(" ON ", switch1.toString());
        //CASO 1 usar el metodo press y apagar el interruptor
        switch1.press();
        assertEquals(" OFF ", switch1.toString());
        //CASO 2 usar el metodo press y encender el interruptor
        switch1.press();
        assertEquals(" ON ", switch1.toString());
    }

    @Test
    public void testToString()
    {
        //crear un objeto interruptor 
        Switch switch1 = new Switch();
        //CASO 1 cuando esta encendido usamos metodo string
        assertEquals(" ON ", switch1.toString());
        //CASO 2 usamos press y cambiamos a apagado y usamos string
        switch1.press();
        assertEquals(" OFF ", switch1.toString());
    }
}


