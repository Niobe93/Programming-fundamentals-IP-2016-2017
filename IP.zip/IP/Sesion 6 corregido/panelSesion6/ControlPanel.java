
/**
 * Class ControlPanel para el laboratorio de IP sesion 6.
 * 
 * @author Gema Rico Pozas
 * @version 19/10/2016
 */
public class ControlPanel
{
    // instance variables 
    private Lamp bombilla;
    private Switch interruptor;
    private Potentiometer potenciometro;
    private Heater radiador;
    /**
     * Constructor for objects of class ControlPanel
     */
    public ControlPanel()
    { 

        bombilla = new Lamp();
        interruptor = new Switch();
        potenciometro = new Potentiometer();
        radiador = new Heater();

    }

    /**
     * Método que muestra por pantalla una cadena de caracteres con información del estado del panel de control 
     *
     */
    public void print ()
    {

        System.out.println("========== ESTADO DEL PANEL ==========");        
        System.out.println(" Interruptor: " + interruptor.toString()); 
        System.out.println(" Bombilla: " + bombilla.toString());
        System.out.println(" Potenciómetro: " + potenciometro.toString());
        System.out.println(" Radiador: " + radiador.toString());

    }

    /**
     * Método que cambia el estado de la bombilla y el interruptor
     *
     * // cambia el estado del interruptor ON/OFF y enciende la bombilla o la apaga.
     */
    public void press()
    {

        interruptor.press();

        if ( interruptor.toString()== " ON ")
            bombilla.turnOn();          
        else
            bombilla.turnOff();

    }
    
    /**
     * Metodo que devuelve el estado del interruptor
     * 
     * @return devuelve el estado del interruptor
     */
    public boolean getSwitchState()
    {

        boolean switchState;
        switchState=interruptor.getSwitchState();

        return switchState;

    }
    
    /**
     * Metodo que devuelve el estado de la bombilla
     * 
     * @return devuelve el estado de la bombilla
     */
    public boolean getLampState()
    {

        boolean LampState;
        LampState=bombilla.getLampState();

        return LampState;

    }
    
    /**
     * Metodo que devuelve la nueva posicion del potenciometro 
     * 
     * @return devuelve la posicion del potenciometro desde 0 a 10
     */
    public int getPosition()
    {
        int position;
        
        position=potenciometro.getPosition();
        return position;
        
    }
    
    /**
     * Metodo que devuelve la nueva temperatura
     * 
     * @return devuelve la temperatura desde 10 a 27
     */
    public double getTemperature()
    {
        double temperature;
        
        temperature=radiador.getTemperature();
        return temperature;
        
    }
    

    /**
     * Método que modifica la posicion del potenciometro y el valor de la temperatura
     * 
     * @param  posición del potenciometro entre 0 y 10.
     * 
     */
    public void movePotentiometer(int position)
    {

        
        
        potenciometro.movePosition(position);

        if (position == potenciometro.MIN_POSITION)
            radiador.changeTemperature(radiador.MIN_TEMPERATURE);

        if (position == potenciometro.MAX_POSITION)
            radiador.changeTemperature(radiador.MAX_TEMPERATURE);

    }
}


