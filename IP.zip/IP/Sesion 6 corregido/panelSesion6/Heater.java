
/**
 * Class Heater para el laboratorio de Ip
 * 
 * @author Gema Rico Pozas 
 * @version 25/10/2016
 */
public class Heater
{
    public final static double MAX_TEMPERATURE=27;
    public final static double MIN_TEMPERATURE=10;
    // instance variables 
    private double temperature;

    /**
     * Constructor for objects of class Heater
     */
    public Heater()
    {
        temperature = MIN_TEMPERATURE;
    }

    /**
     * Modifica el valor de la temperatura al valor recibido como parámetro
     * 
     * @param  temperatura de tipo double min 10 y maximo 27
     * 
     */
    public void changeTemperature(double temperature)
    {
        if ((temperature <= MAX_TEMPERATURE) && (temperature >= MIN_TEMPERATURE))
         this.temperature = temperature;
    } 
    
     /**
     * Metodo que devuelve el valor de la temperatura
     *
     * 
     * @return devuelve el valor de la temperatura de tipo double desde 10 a 27
     */
    public double getTemperature()
    {

        return this.temperature;
    }
    
    /**
     * Método que devuelve una cadena de caracteres.
     *
     * @return una cadena con la temperatura.
     */

    public String toString ()

    { 
        return (this.temperature + "ºC");

    }    
}
