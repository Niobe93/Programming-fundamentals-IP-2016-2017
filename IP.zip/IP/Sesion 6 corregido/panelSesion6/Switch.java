
/**
 * Class Switch para laboratorio de IP sesión 6
 * 
 * @author Gema Rico Pozas 
 * @version 19/10/2016
 */
public class Switch
{
   public final static boolean ON=true;
   public final static boolean OFF=false;
    
    // instance variables
    
   private boolean switchState; // ON = true ; OFF = false.

    /**
     * Constructor for objects of class Switch
     */
    public Switch()
   {
       switchState=ON;
   }  
   
   /**
     * Metodo que devuelve el estado del interruptor
     * 
     * @return devuelve el estado del interruptor
     */
    public boolean getSwitchState()
    {

        return this.switchState;
        
    }

   /**
     * Método que cambia el estado del interruptor
     *
     * @param //modifica el estado del interruptor ON|OFF
     */
    public void press()
    {
        if(switchState == ON)
         switchState = OFF;
        else
         switchState = ON;         
      
    }

    /**
     * Método que devuelve una cadena de caracteres.
     *
     * @return una cadena con la representación del estado del interruptor.
     *     //ON cuando switchState es true; OFF cuando switchState es false;
     */

    public String toString ()

    { 
        if(switchState == ON)
         return " ON ";
        else
         return " OFF ";

   }
}