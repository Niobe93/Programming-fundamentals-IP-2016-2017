

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class LampTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class LampTest
{
    /**
     * Default constructor for test class LampTest
     */
    public LampTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }

    @Test
    public void testTurnOn()
    {
        //crear un objeto bombilla
        Lamp lamp1 = new Lamp();
        //CASO 1 usar el metodo turn on y encender la bombilla
        lamp1.turnOn();
        assertEquals(" ENCENDIDA ", lamp1.toString());
    }

    @Test
    public void testTurnOff()
    {
        //crear un objeto bombilla
        Lamp lamp1 = new Lamp();
        //CASO1 usar el metodo turn off y apagar la bombilla que estada encendida
        lamp1.turnOff();
        assertEquals(" APAGADA ", lamp1.toString());
    }

    @Test
    public void testToString()
    {
        //crear un objeto bombilla
        Lamp lamp1 = new Lamp();
        //CASO 1 cuando la bombilla esta encendida
        assertEquals(" ENCENDIDA ", lamp1.toString());
        //CASO 2 usar el metodo turn off y cambiar el estado a apagada
        lamp1.turnOff();
        assertEquals(" APAGADA ", lamp1.toString());
    }
}



