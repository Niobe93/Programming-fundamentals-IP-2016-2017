

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class LandingGearTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class LandingGearTest
{
    /**
     * Metodo de prueba de el constructor sin parametros de la clase LandingGear
     */
    @Test
    public void TestLandingGear()
    {
        LandingGear tren = new LandingGear();
        
        
    }
    
    /**
     * Metodo de prueba de el metodo MoveLever
     */
    @Test
    public void TestMoveLever()
    {
        LandingGear tren = new LandingGear(); //Se crea replegado
        //Caso 1: Estando replegado mover a down
        tren.moveLever(tren.LEVER_DOWN);
        assertEquals(tren.LEVER_DOWN,tren.getLever());
        assertEquals(WheelStrut.IS_DEPLOYED,tren.getNose().isDeployed());
        assertEquals(WheelStrut.IS_DEPLOYED,tren.getLeft().isDeployed());
        assertEquals(WheelStrut.IS_DEPLOYED,tren.getRight().isDeployed());
        //Caso 2: Estando down mover a replegado
        tren.moveLever(tren.LEVER_UP);
        assertEquals(tren.LEVER_UP,tren.getLever());
        assertEquals(! WheelStrut.IS_DEPLOYED,tren.getNose().isDeployed());
        assertEquals(! WheelStrut.IS_DEPLOYED,tren.getLeft().isDeployed());
        assertEquals(! WheelStrut.IS_DEPLOYED,tren.getRight().isDeployed());
        //Caso 3: Estando replegado mover a up(replegado)
        tren.moveLever(tren.LEVER_UP);
        assertEquals(tren.LEVER_UP,tren.getLever());
        assertEquals(! WheelStrut.IS_DEPLOYED,tren.getNose().isDeployed());
        assertEquals(! WheelStrut.IS_DEPLOYED,tren.getLeft().isDeployed());
        assertEquals(! WheelStrut.IS_DEPLOYED,tren.getRight().isDeployed());
        //Caso 4: Estando down mover a down
        
    }
    
    /**
     * Metodo de prueba de el metodo test
     */
    @Test
    public void TestTest()
    {
        //Caso 1 : Todos los puntales son correctos
        LandingGear tren = new LandingGear();
        assertTrue(tren.test());
        //Caso 2 : Solo o al menos un puntal es incorrecto
        WheelStrut nose = new WheelStrut(3);
        nose.getWheel(1).reducePressure(1000);
        LandingGear tren1 = new LandingGear(nose, new WheelStrut(3), new WheelStrut(3));
        assertFalse(tren1.test());
    }
    
    /**
     * Metodo de prueba de el metodo print
     */
    @Test
    public void TestPrint()
    {
        //Caso 1 : Todo correcto
        LandingGear tren = new LandingGear();
        tren.print();
        //Caso 2 : Algo incorrecto
        WheelStrut nose = new WheelStrut(3);
        nose.getWheel(1).reducePressure(1000);
        LandingGear tren1 = new LandingGear(nose, new WheelStrut(3), new WheelStrut(3));
        tren1.print();
    }
}
