
/**
 * Clase bus
 * 
 * @author (Antonio Payá González) 
 * @version (08/10/2015)
 */
public class Bus
{
    // atributos de la clase bus
    private boolean driverPresent;
    private int availableSeats;

    //constantes de la clase bus
    public final static int MAX_SEATS = 60;
    public final static int MIN_SEATS = 0;

    /**
     * Constructor sin parámetros que inicializa:
     * que no hay conductor y el número de asientos libres es máximo
     */
    public Bus()
    {
        // valores iniciales de los atributos
        driverPresent = false;
        availableSeats = MAX_SEATS;

    }

    /**
     * Constructor con parámetros que inicializa:
     * que hay conductor y el número de asientos libres es 20
     * 
     * @param boolean driverPresent , conductor presente o no
     * @param int availableSeats , número libre de asientos
     */
    public Bus(boolean driverPresent , int availableSeats) 
    {
        // valores iniciales de los atributos
        driverExists(driverPresent);
        setAvailableSeats(availableSeats);

    }
    //Métodos set y driverExists
    /**
     * Método que cambia el valor del atributo driverPresent
     * 
     * @param  driverPresent , de tipo booleano , nuevo valor para el atributo driverPresent
     */
    public void driverExists(boolean driverPresent)
    {
        this.driverPresent = driverPresent;
    }

    /**
     * Método que cambia el número de asientos libres 
     * 
     * @param  driverPresent , de tipo booleano , nuevo valor para el atributo driverPresent
     */
    public void setAvailableSeats(int availableSeats)
    {
        
        if (availableSeats < 0   ||   availableSeats > MAX_SEATS){
            availableSeats = MAX_SEATS;
        }
        this.availableSeats = availableSeats;
    }

    //Métodos get
    
    /**
     * Método que devuelve el número de asientos libres 
     * 
     * @return  devuelve el numero de asientos libres, que es un int
     */
    public int getAvailableSeats()
    {
        return availableSeats;
    }

    //Otros Métodos

    /**
     * Método que cambia el valor del atributo diverPresent a true 
     */
    public void sitDriver()
    {
        driverPresent = true;
    }

    /**
     * Método que pide como parámetro l numero de pasajeros que quieren subirse al autobus y, 
     * si el conductor está presente y hay suficiente espacio , cambia el numero de asientos libres
     * restandole los que han entrado y devuelve el valor true
     * 
     * @param pasajerosQueSuben , cambia el valor del atributo que da los pasajeros que suben
     * @return devuelve true si los pasajeros pueden entrar y false en caso contrario, es un booleano
     */
    public boolean getOn(int pasajerosQueSuben)
    {

        if (driverPresent == true  &&  pasajerosQueSuben < availableSeats){
            availableSeats = ( availableSeats - pasajerosQueSuben );
            return true;
        }
        else {
            return false;
        }
    }

    
    /**
     * Método que devuelve una cadena que contiene la siguiente
     * informacion separada por guiones:
     * ON DUTY, si el conductor esta en el autobus o OUT OF SERVICE", si no lo esta.
     * Guion "-" El numero de asientos disponibles. 
     * 
     * @return devuelve una cadena de texto 
     */
    public String toString()
    {
      
        if (driverPresent == false ){
            return "OUT OF SERVICE" + " - " + availableSeats;
        }
        else{
            return "ON DUTY" + " - " + availableSeats;
        }
    }

}
