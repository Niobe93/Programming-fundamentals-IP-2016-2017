
/**
 * Clase LandingGear (tren de aterrizaje)
 * 
 * @author (Antonio Paya Gonzalez) 
 * @version (4/11/2015)
 */
public class LandingGear
{
    // Constantes de la clase
    public static final boolean LEVER_UP = true;
    public static final boolean LEVER_DOWN = false;
    // Atributos de la clase 
    private boolean lever;
    private WheelStrut nose;
    private WheelStrut left;
    private WheelStrut right;

    /**
     * Constructor de la clase LandingGear, sin parametros
     * Crea el tren de aterrizaje con palanca hacia arriba(Puntal no desplegado).
     */
    public LandingGear()
    {
        setLever(LEVER_UP);
        setNose(new WheelStrut(3));
        setRight(new WheelStrut(5));
        setLeft(new WheelStrut(5));
        nose.retract();
        left.retract();
        right.retract();
    }

    /**
     * Constructor de la clase LandingGear, con parametros
     * Crea el tren de aterrizaje con palanca hacia arriba(Puntal no desplegado).
     */
    public LandingGear(WheelStrut nose1,WheelStrut left1,WheelStrut right1)
    {
        this();
        setNose(nose1);
        setRight(left1);
        setLeft(right1);
        moveLever(LEVER_UP);
    }

    //Metodos set

    /**
     * Metodo que modifica el valor del atributo lever
     * 
     * @param  newLever, de tipo boolean
     */
    public void setLever(boolean newLever)
    {
        lever = newLever;
    }

    /**
     * Metodo que modifica el valor del atributo nose
     * 
     * @param  newNose, de tipo WheelStrut
     */
    public void setNose(WheelStrut newNose)
    {
        if (newNose != null){
            nose = newNose;
        }
    }

    /**
     * Metodo que modifica el valor del atributo left
     * 
     * @param  newLeft, de tipo WheelStrut
     */
    public void setLeft(WheelStrut newLeft)
    {
        if (newLeft != null){
            left = newLeft;
        }
    }

    /**
     * Metodo que modifica el valor del atributo right
     * 
     * @param  newRight, de tipo WheelStrut
     */
    public void setRight(WheelStrut newRight)
    {
        if (newRight != null){
            right = newRight;
        }
    }

    //Metodos get

    /**
     * Metodo que devuelve el valor del atributo lever
     * 
     * @return  devuelve el valor del atributo lever
     */
    public boolean getLever()
    {
        return lever;
    }

    /**
     * Metodo que devuelve el valor del atributo nose
     * 
     * @return  devuelve el valor del atributo nose
     */
    public WheelStrut getNose()
    {
        return nose;
    }

    /**
     * Metodo que devuelve el valor del atributo left
     * 
     * @return  devuelve el valor del atributo left
     */
    public WheelStrut getLeft()
    {
        return left;
    }

    /**
     * Metodo que devuelve el valor del atributo right
     * 
     * @return  devuelve el valor del atributo right
     */
    public WheelStrut getRight()
    {
        return right;
    }

    //Otros metodos

    /**
     * Metodo que mueve la palanca y el tren de aterrizaje
     * 
     * @param  accion a realizar LEVER_UP o LEVER_DOWN
     */
    public void moveLever(boolean action)
    {
        if (action == LEVER_UP){
            setLever(LEVER_UP);
            nose.retract();
            left.retract();
            right.retract();
        }
        else if (action == LEVER_DOWN){
            setLever(LEVER_DOWN);
            nose.deploy();
            left.deploy();
            right.deploy();
        }
    }

    /**
     * Metodo que devuelve true si todos sus puntales aprueban el test
     * 
     * @return , devuelve true o false dependiendo de si pasa el test o no, tipo boolean
     */
    public boolean test()
    {
        if (nose.test()== true && left.test()==true && right.test()){
            return true;
        }
        else{
            return false;
        }
    }

    /**
     * Metodo que imprime toda la informacion del tren de aterrizaje
     * Posicion de la palanca Lever...............UP/DOWN
     * Test del tren de aterrizaje................OK/FAIL
     * Para cada puntal
     * test..........OK/FAIL
     * desplegado....ON/OFF
     * 
     */
    public void print()
    {
        if (getLever() == LEVER_UP){
            System.out.println("Lever...............UP");
        }
        else{
            System.out.println("Lever...............DOWN");
        }
        
        if (test()){
            System.out.println("Test...............OK");
        }
        else{
            System.out.println("Test...............FAIL");
        }
        
        if (nose.test()){
            System.out.println("Test Nose......OK");
        }
        else{
            System.out.println("Test Nose......FAIL");
        }
        if (nose.isDeployed()){
            System.out.println("Desplegado Nose......ON");
        }
        else{
            System.out.println("Desplegado Nose......OFF");
        }
        
        if (left.test()){
            System.out.println("Test Left......OK");
        }
        else{
            System.out.println("Test Left......FAIL");
        }
        if (left.isDeployed()){
            System.out.println("Desplegado Left......ON");
        }
        else{
            System.out.println("Desplegado Left......OFF");
        }
        
        if (right.test()){
            System.out.println("Test Right......OK");
        }
        else{
            System.out.println("Test Right......FAIL");
        }
        if (right.isDeployed()){
            System.out.println("Desplegado Right......ON");
        }
        else{
            System.out.println("Desplegado Right......OFF");
        }
    }
}
