
/**
 * Clase avion con atributos:
 * pilot - de clase Person
 * identifier- de tipo char
 * combustible(fuel) - de tipo int
 * 
 * @author (Antonio Paya) 
 * @version (07/10/2015)
 */
public class Plane
{
    //Constantes de la clase Plane
    public final static Person STANDARD_PILOT = null;
    public final static char STANDARD_IDENTIFIER = 'M';
    public final static int STANDARD_FUEL = 4000;
    public final static int STANDARD_MAXFUEL = 5000;
    public final static int STANDARD_MINFUEL = 0;

    public final static int  MAX_X = 10;
    public final static int  MAX_Y = 10;
    public final static int  MIN_X = 0;
    public final static int  MIN_Y = 0;

    public final static int  MAX_X_SPEED = 1;
    public final static int  MIN_X_SPEED = -1;

    public final static int  MAX_Y_SPEED = 1;
    public final static int  MIN_Y_SPEED = -1;

    public final static int CONSUM = 500;

    // atributos de la clase Plane
    private Person pilot;  //piloto para el avion
    private char identifier;  //sera un caracter entre 'A' y 'Z'
    private int fuel; //combustible disponible en el avion
    private int xPos; //coordenada x del avion
    private int yPos; //coordenada y del avion
    private int xSpeed; //velocidad en la coordenada x del avion
    private int ySpeed; //velocidad en la  coordenada y del avion
    private LandingGear tren; //Tren de aterrizaje

    /**
     * Constructor estandar que inicializa los valores de la clase Plane:
     * Sin piloto
     * identificador 'M'
     * combustible 10000 litros
     */
    public Plane()
    {
        setPilot(STANDARD_PILOT);
        setIdentifier(STANDARD_IDENTIFIER);
        setFuel(STANDARD_FUEL);
        setXSpeed(0);
        setYSpeed(0);
        setXPos(0);
        setYPos(0);
        setTren(new LandingGear());
        tren.moveLever(tren.LEVER_UP);
    }

    /**
     * Constructor con dos parametros xPos e yPos
     * El resto de atributos los estandar
     * 
     * @param xPos, posicion del eje x , tipo entero
     * @param yPos, posicion del eje y , tipo entero
     */
    public Plane(int xPos,int yPos)
    {
        this();
        setXPos(xPos);
        setYPos(yPos);
    }

    /**
     * Constructor que pide por parametro el combustible del avion
     * El resto de atributos los estandar
     * 
     * @param newFuel, combustible del avi�n
     */
    public Plane(int newFuel)
    {
        this();
        setFuel(newFuel);
    }
    
    /**
     * Constructor con todos los parametros
     * El resto de atributos los estandar
     * 
     * @param pilot , tipo Person
     * @param identifier
     * @param fuel
     * @param xPos
     * @param yPos
     * @param xSpeed
     * @param ySpeed
     * @param tren, tipo LandingGear
     */
    public Plane(Person pilot,char identifier,int fuel,int xPos,int yPos,int xSpeed,int ySpeed)
    {
        setPilot(pilot);
        setIdentifier(identifier);
        setFuel(fuel);
        setXSpeed(xSpeed);
        setYSpeed(ySpeed);
        setXPos(xPos);
        setYPos(yPos);
    }

    //Metodos set

    /**
     * Metodo que modifica el valor del atributo tren
     * 
     * @param  newTren, de tipo LandingGear
     */

    private void setTren(LandingGear newTren)
    {
        if (newTren != null){
            tren = newTren;
        }
    }

    /**
     * Metodo que modifica el valor del atributo pilot
     * 
     * @param  newPilot nuevo piloto para el avion ,de tipo Person
     */
    public void setPilot(Person newPilot)
    {
        if (newPilot != null){
            pilot = newPilot;
        }
    }

    /**
     * Metodo que modifica el valor del atributo identifier
     * 
     * @param  identifier, nuevo identificador para el avion, de tipo char
     */
    public void setIdentifier(char newIdentifier)
    {
        identifier = newIdentifier;

    }

    /**
     * Metodo que modifica el valor del atributo fuel
     * 
     * @param  fuel nuevo combustible para el avion de tipo int
     */
    public void setFuel(int fuel)
    {
        if ( (fuel >= STANDARD_MINFUEL) && (fuel <= STANDARD_MAXFUEL) ){
            this.fuel = fuel;
        }

    }

    /**
     * Metodo que modifica el valor del atributo xPos
     * 
     * @param  xPos, nueva posicon x para el avion de tipo int
     */
    private void setXPos(int xPos)
    {
        if (MIN_X <= xPos && MAX_X >= xPos){
            this.xPos = xPos;

        }
    }

    /**
     * Metodo que modifica el valor del atributo tPos
     * 
     * @param  tPos, nueva posicon t para el avion de tipo int
     */
    private void setYPos(int yPos)
    {
        if (MIN_Y <= yPos && MAX_Y >= yPos){
            this.yPos = yPos;

        }
    }

    /**
     * Metodo que modifica el valor del atributo xSpeed
     * 
     * @param  xSpeed, nueva velocidad x para el avion de tipo int
     */
    private void setXSpeed(int xSpeed)
    {
        if (MIN_X_SPEED <= xSpeed && MAX_X_SPEED >= xSpeed){
            this.xSpeed = xSpeed;

        }
    }

    /**
     * Metodo que modifica el valor del atributo ySpeed
     * 
     * @param  ySpeed, nueva velocidad y para el avion de tipo int
     */
    private void setYSpeed(int ySpeed)
    {
        if (MIN_Y_SPEED <= ySpeed && MAX_Y_SPEED >= ySpeed){
            this.ySpeed = ySpeed;

        }
    }

    //Metodos get

    /**
     * Metodo que devuelve el valor del atributo tren
     * 
     * @return  devuelve el valor del atributo tren
     */
    public LandingGear getLandingGear()
    {
        return tren;
    }

    /**
     * Metodo que devuelve el valor del atributo pilot
     * 
     * @return  pilot  piloto del avion ,de tipo Person
     */
    public Person getPilot()
    {
        return pilot;

    }

    /**
     * Metodo que devuelve el valor del atributo identifier
     * 
     * @return  identifier, identificador del avion, de tipo char
     */
    public char getIdentifier()
    {
        return identifier;

    }

    /**
     * Metodo que devuelve el valor del atributo fuel
     * 
     * @return  fuel, combustible del avion  ,de tipo int
     */
    public int getFuel()
    {
        return fuel;

    }

    /**
     * Metodo que devuelve el valor de xPos
     * 
     * @return  xPos,posicon x del avion de tipo int
     */
    public int getXPos()
    {
        return xPos;
    }

    /**
     * Metodo que devuelve el valor de yPos
     * 
     * @return  yPos,posicon y del avion de tipo int
     */
    public int getYPos()
    {
        return yPos;
    }

    /**
     * Metodo que devuelve el valor de xSpeed
     * 
     * @return  xSpeed,velocidad x del avion de tipo int
     */
    public int getXSpeed()
    {
        return xSpeed;
    }

    /**
     * Metodo que devuelve el valor de ySpeed
     * 
     * @return  ySpeed,velocidad y del avion de tipo int
     */
    public int getYSpeed()
    {
        return ySpeed;
    }

    //otros metodos
    /**
     * Metodo que devuelva false si la cantidad de combustible es 0
     * y en otro caso que reduzca la cantidad de combustible en una unidad y que devuelva true
     * 
     * @return  boolean true si puede volar y false si no es posible
     */ 
    public boolean fly()
    {
        if ( getFuel() == 0){
            return false;
        }
        else{
            setFuel(getFuel()-1);
            setXPos(getXPos()+getXSpeed());
            setYPos(getYPos()+getYSpeed());
            return true;
        }

    }

    /**
     * Metodo que cambia el valor de xSpeed y el de ySpeed
     * 
     * @param xSpeed, de tipo int, valor de la velocidad en x
     * @param ySpeed, de tipo int, valor de la velocidad en y
     */
    public void accelerate0(int newXSpeed,int newYSpeed)
    {
        setXSpeed(newXSpeed);
        setYSpeed(newYSpeed);

    }

    /**
     * Metodo que incrementa en 1 la valocidad , sin que esta pase de 1 o -1
     */
    public void accelerate()
    {
        if (xSpeed+1 >= 1 || xSpeed-1 <= -1){
            if (xSpeed > 0){
                xSpeed = 1;
            }
            else{
                xSpeed ++;
            }
        }
        else{
            xSpeed ++;
        }

    }

    /**
     * Metodo que incrementa en 1 la valocidad , sin que esta pase de 1 o -1
     */
    public void deccelerate()
    {
        if (xSpeed+1 >= 1 || xSpeed-1 <= -1){
            if (xSpeed > 0){
                xSpeed = 0;
            }
            else if(xSpeed < 0){
                xSpeed = -1;
            }
            else{
                xSpeed --;
            }
        }
        else{
            xSpeed --;
        }

    }

    /**
     * Metodo que , si el tren de aterrizaje pasa su test y esta desplegado
     * y hay suficiente combustible para las horas de vuelo recibidas 
     * por parametro
     * 
     * Reduce la presion actual de las ruedas del morro en 10Mlb, reduce el 
     * fuel en funcion de las horas de vuelo y devuelve el valor final del fuel
     * 
     * En caso de que algo falle devolvera el valor -1
     * 
     * @param hours, de tipo int, horas de vuelo del avi�n
     * @return devuelve el fuel del avi�n , o -1 si algo falla
     */
    public int fly(int hours)
    {
        if(hours > 0){
            if(tren.test()== true && tren.getLever()==false && (getFuel() >= (hours*CONSUM))){
                for (int i=0;i<=tren.getNose().size();i++){
                    tren.getNose().getWheel(i).reducePressure(10);
                }

                setFuel(getFuel()-(hours*CONSUM));
                return getFuel();
            }
            else{
                return -1;
            }
        }
        else{
            return -1;
        }
    }
}
