

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class WheelStrutTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class WheelStrutTest
{
    /**
     * Pruebas para el constructor con 1 parametro
     */
    @Test
    public void TestWheelStrutTest1Parametro()
    {
        //Caso 1:Numero de ruedas positivo
        WheelStrut wheelStrut1 = new WheelStrut(4);
        assertEquals(WheelStrut.IS_DEPLOYED,wheelStrut1.isDeployed());
            //assertEquals(4,wheelStrut1.getWheelList().size());
        assertEquals(4,wheelStrut1.size());
        for(int i=0; i<wheelStrut1.size();i++){
            //assertEquals(WheelStrut.DEFAULT_PRESSURE_BOEING_737,wheelStrut1.getWheelList().get(i).getPressure(),0.1);
            assertEquals(WheelStrut.BOEING_737_PRESSURE,wheelStrut1.getWheel(i).getPressure(),0.1);
            assertEquals(WheelStrut.BOEING_737_PRESSURE,wheelStrut1.getWheel(i).getMaxPressure(),0.1);
        }
        //Caso 2:Numero de ruedas negativo
        try
        {
            wheelStrut1 = new WheelStrut(-4);
            fail();
        }
        
        catch (RuntimeException exception){
            assertEquals("Dimension negativa o 0",exception.getMessage());
        }
    }
    
    /**
     * Pruebas del metodo test
     */
    @Test
    public void testTest()
    {
        
        //Caso 1: Las ruedas tienen presion adecuada
        WheelStrut wheelStrut = new WheelStrut(5);
        assertTrue(wheelStrut.test());
        wheelStrut.print();
        
        //Caso 2: Una rueda no tiene la presion adecuada

        wheelStrut = new WheelStrut(4);
        Wheel wheel1 = wheelStrut.getWheel(0);
        wheel1.reducePressure(1000);
        assertFalse(wheelStrut.test());
        wheelStrut.print();
    }
    
    
    /**
     * Pruebas del metodo retract y el metodo deploy
     */
    @Test
    public void testRetractAndDeploy()
    {
        WheelStrut pilar = new WheelStrut(4);
        //Caso 1: Si esta desplegado , replegarlo
        pilar.retract();
        assertEquals(! pilar.IS_DEPLOYED,pilar.isDeployed());
        //Caso 2: Si esta replegado, deplegar
        pilar.deploy();
        assertEquals(pilar.IS_DEPLOYED,pilar.isDeployed());
        //Caso 3(negativo): estando replegado , replegar
        pilar.retract();
        assertEquals(!pilar.IS_DEPLOYED,pilar.isDeployed());
        //Caso 4(negativo): estando desplegado , desplegar
        pilar.deploy();
        assertEquals(pilar.IS_DEPLOYED,pilar.isDeployed());
    }
}
