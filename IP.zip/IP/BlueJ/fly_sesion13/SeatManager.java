import java.util.ArrayList;
/**
 * Clase que es el gestor de asientos del avion
 * 
 * @author (Antonio Paya Gonzalez) 
 * @version (26/11/2015)
 */
public class SeatManager
{
    //Constantes
    public static final int FIRST_ROWS = 3;
    public static final int STANDARD_ROWS = 4;
    public static final int COLUMNS = 6;

    // Atributos
    private int firstRows;    //Numero de filas en primera clase
    private int standardRows; 
    private Person [][] seats;  //Matriz de los asientos del avion

    /**
     * Constructor de la clase SeatManager sin parametros
     */
    public SeatManager()
    {
        setFirstRows(FIRST_ROWS);
        setStandardRows(STANDARD_ROWS);
        seats = new Person [getFirstRows() + getStandardRows()][COLUMNS];
    }

    /**
     * Constructor de la clase SeatManager con dos parametros
     * 
     * @param first, numero de filas en primera clase
     * @param standard, numero de filas en clase standard
     */
    public SeatManager(int first,int standard)
    {
        this();
        setFirstRows(first);
        setStandardRows(standard);
        seats = new Person [getFirstRows() + getStandardRows()][COLUMNS];
    }

    //Metodos set

    /**
     * Metodo que modifica el atributo firstRows
     * 
     * @param first, numero de filas en primera clase
     */
    public void setFirstRows(int first)
    {
        if (first >= FIRST_ROWS){
            firstRows = first;
        }
        else{
            firstRows = FIRST_ROWS;
        }
    }

    /**
     * Metodo que modifica el atributo firstRows
     * 
     * @param standard, numero de filas en primera clase
     */
    public void setStandardRows(int standard)
    {
        if (standard >= STANDARD_ROWS){
            standardRows = standard;
        }
        else {
            standardRows = STANDARD_ROWS;
        }
    }

    //Metodos get

    /**
     * Metodo que devuelve el atributo firstRows
     * 
     * @param numero de filas en primera clase
     */
    public int getFirstRows()
    {
        return firstRows;
    }

    /**
     * Metodo que devuelve el atributo standardRows
     * 
     * @return numero de filas  clase media
     */
    public int getStandardRows()
    {
        return standardRows;
    }

    /**
     * Metodo que devuelve la persona introducida por fila y columna
     * 
     * @return persona 
     */
    public Person getSeat(int fila,int columna)
    {
        return seats[fila][columna];
    }

    /**
     * Que devuelve el valor del atrbuto seats
     * @return devuelve el valor de seats
     */
    public Person[][] getSeats()
    {
        return seats;
    }

    //Otros metodos
    /**
     * Metodo que reserva un asiento cuya fila y columna se indican como parametro
     * para una persona recibida por parametro
     * 
     * @param Person persona, persona para entrar en el avion
     * @param fila, fila pa reservar
     * @param columna,columna pa reservar
     * @return true si se ha reservado el asiento, falso si no se ha podido reservar
     * @exception , "Parametro incorrecto cuando se produce el error
     */
    public boolean bookSeat(Person persona,int fila,int columna)
    {
        if(persona != null && fila >= 0 && fila < seats.length && columna >= 0 &&columna < seats[fila].length){
            if(seats[fila][columna] == null){
                seats[fila][columna] = persona;
                return true;
            }
            return false;
        }
        else {
            throw new RuntimeException("Parametros incorrectos");
        }
    }

    /**
     * Metodo que devuelve el pasajero de mas edad sentado en el avion o null si el avion esta
     * vacio
     */
    public Person oldestPassenger()
    {
        Person contador = null;
        int edad = 0;
        for(int i=0;i < seats.length;i++){
            for(int j=0; j < seats[i].length;j++){
                if (seats[i][j]!= null){
                    if(edad < seats[i][j].getAge()){
                        edad = seats[i][j].getAge();
                        contador = seats[i][j];
                    }
                }
            }
        }
        return contador;
    }

    /**
     * Metodo que devuelve el numero de asientos libres en la fila del avion que se le pasa
     * como parametro
     */
    public int numberOfSeats(int row)
    {
        if (row >= getSeats().length || row<0){
            throw new RuntimeException("La fila especificada no existe");
        }

        int contador = 0;
        for(int i=0; i< seats[row].length; i++){
            if (seats[row][i] == null){
                contador++;
            }
        }
        return contador;
    }

    /**
     * Metodo que devuelve X si el que esta sentado es un adulto, C si es un ni�o y ? si esta
     * vacio
     */
    public String mirar(int row,int column)
    {
        if (seats[row][column]== null){
            return "?";
        }
        else if(seats[row][column].getAge() <= 18){
            return "C";
        }
        else{
            return "X";
        }
    }

    /**
     * Metodo que imprime por pantalla el estado de los asientos del avion con el formato:
     * X para adulto, C para ni�o y ? para asiento libre
     */
    public void print()
    {
        System.out.println("    "+"A   "+"B   "+"C   "+"  D   "+"E   "+"F");
        for (int i=0 ; i < firstRows ; i++){
            System.out.print (i);
            for (int j=0 ; j<3; j++){
                System.out.print ("   "+ mirar(i,j));
            }
            System.out.print("  ");
            for(int j=3; j<seats[0].length; j++){
                System.out.print ("   "+ mirar(i,j));
            }
            System.out.println();
        }
        System.out.println("---------------------------");
        for (int i= firstRows; i<firstRows+standardRows; i++){
            System.out.print (i);
            for (int j=0 ; j<3; j++){
                System.out.print ("   "+ mirar(i,j));
            }
            System.out.print("  ");
            for(int j=3; j<seats[0].length; j++){
                System.out.print ("   "+ mirar(i,j));
            }
            System.out.println();
        }
    }

    /**
     * Metodo que libera un asiento dada la fila y la columna
     * 
     * @param row , fila a liberar
     * @param column , columna a liberar
     * @return , devuelve la persona sentada en el asiento o null si no hay nadie
     */
    public Person releaseSeat(int row,int column)
    {
        if (row >= getSeats().length || row<0 || column >= COLUMNS || column<0){
            throw new RuntimeException("Parametros incorrectos");
        }
        Person p1 = seats[row][column];
        seats[row][column] = null;
        return p1;
    }

    /**
     * Metodo que devuelve la edad del pasajero mas joven
     * 
     * @return edad del pasajero mas joven o 120 si no hay pasajeros
     */

    private int getYoungestAge()
    {
        int contador = Person.MAX_AGE;
        Person person = null;
        for (int i=0; i < seats.length ; i++){
            for (int j=0; j< seats[i].length ; j++){
                if (seats[i][j] != null && seats[i][j].getAge() <= contador){
                    contador = seats[i][j].getAge();
                    person = seats[i][j];
                }
            }
        }
        if(person == null){
            throw new RuntimeException("Avion vacio");
        }
        return contador;
    }

    /**
     * Metodo que devuelve un ArrayList que contiene las personas de menor edad sentadas en el avion
     * 
     * @return ArrayList
     */
    public ArrayList<Person> getYoungestPeople()
    {
        ArrayList <Person> youngestPeople = new ArrayList <Person>();
        int edadJoven = getYoungestAge();
        for (int i=0; i < seats.length ; i++){
            for (int j=0; j< seats[i].length ; j++){
                if (seats[i][j]!=null && seats[i][j].getAge()== edadJoven){
                    youngestPeople.add(seats[i][j]);
                }
            }
        }
        return youngestPeople;
    }

    /**
     * Metodo que devuelve un ArrayList con los mas jovenes del avion
     * @return ArryList
     */
    public ArrayList<Person> childrenPassengers()
    {
        ArrayList <Person> children = new ArrayList <Person>();
        int edadMinima = Person.ADULTHOOD_AGE;
        for (int i=0; i < seats.length ; i++){
            for (int j=0; j< seats[i].length ; j++){
                if (seats[i][j]!=null && seats[i][j].getAge()<= edadMinima){
                    children.add(seats[i][j]);
                }
            }
        }
        return children;
    }

    /**
     * Metodo que devuelve el numero de pasajeros sentados en un area del avion
     * Un area puede ser primera clase, clase estandar o todo el avion
     * Primera clase area = 1
     * Segunda clase area = 2
     * Tercera clase area = 3
     * 
     * @param area de tipo byte
     * @return Numero de pasajeros sentados en esa zona , de tipo int
     */
    public int getNumPax(byte area)
    {
        int contador = 0;
        if (area == 2){
            for (int i=getFirstRows()-1; i < seats.length ; i++){
                for (int j=0; j< seats[i].length ; j++){
                    if (seats[i][j]!=null){
                        contador++;
                    }
                }
            }
        }
        else if (area == 1){
            for (int i=0; i < getFirstRows()-1; i++){
                for (int j=0; j< seats[i].length ; j++){
                    if (seats[i][j]!=null){
                        contador++;
                    }
                }
            }
        }
        else if (area == 3){
            for (int i=0; i < seats.length; i++){
                for (int j=0; j< seats[i].length ; j++){
                    if (seats[i][j]!=null){
                        contador++;
                    }
                }
            }
        }
        else{
            throw new RuntimeException("El prametro introducido no es correcto");
        }
        return contador;
    }

    /**
     * Metodo que devuelve el numero de pasajeros sentdos en una seccion del avion
     * Una posicon se representa mediante la primera posicion de una fila y la 
     * ultima posicion de una fila
     *
     * @param  row1, de tipo int
     * @param  colum1, de tipo int
     * @param  row2, de tipo int
     * @param  colum2, de tipo int
     * 
     * @return devuelve el numero de personas sentadas en una seccion del avion
     */
    public int getNumPaxBySection(int row1,int colum1,int row2,int colum2)
    {
        if(row1>=0 && row1<seats.length && row2>=0 && row2<=seats.length && colum1 >= 0 && colum1 <= COLUMNS && colum2 >= 0 && colum2 <= COLUMNS){
            int contador=0;
            for(int i=row1;i <= row2;i++){
                for(int j=colum1; j <= colum2;j++){
                    if (seats[i][j] != null){
                        contador++;
                    }
                }
            }
            return contador;
        }
        else{
            throw new RuntimeException("El prametro introducido no es correcto");
        }
    }

    /**
     * Metodo que sienta en el avion a un numero dado de pasajeros.Se iran
     * sentando en los asientos libres desde las primeras filas del avion
     *
     * @param  paxNumber, de tipo int
     */
    public void loadPax(int paxNumber)
    {
        if (paxNumber >=0){
            int temp = 0;
            for (int i=0; i < seats.length ; i++){
                for (int j=0; j< seats[i].length ; j++){
                    if (temp < paxNumber && seats[i][j] == null ){
                        bookSeat(new Person(),i,j);
                        temp++;
                    }
                }
            }
        }
        else{
            throw new RuntimeException("El prametro introducido no es correcto");
        }
    }

    /**
     * Metodo que cambia los numeros por letras para las columnas
     *
     * @param  j , de tipo int
     * @return devuelve una letra
     */
    public String cambiaColum(int j)
    {
        if (j >= 0 && j <= 5){
            switch (j){
                case 0: //Columna 0 
                return "A";

                case 1: //Columna 1
                return "B";

                case 2: //Columna 2
                return "C";

                case 3: //Columna 3
                return "D";

                case 4: //Columna 4
                return "E";

                case 5: //Columna 5
                return "F";

                default:
                return null;
            }
        }
        else{
            throw new RuntimeException("El prametro introducido no es correcto");
        }
    }

    /**
     * Metodo que imprime un informe detallado de todos los pasajeros del avion
     */
    public void printManifest()
    {
        System.out.println("MANIFEST");
        System.out.println("FIRST CLASS");
        for (int i=0; i < getFirstRows()-1; i++){
            for (int j=0; j< seats[i].length ; j++){
                if (seats[i][j]!=null){
                    System.out.println("ROW: "+i+" SEAT: "+cambiaColum(j)+" - "+getSeat(i,j).getName()+" "+getSeat(i,j).getSurname1()+" - AGE: "+getSeat(i,j).getAge());
                }
            }
        }
        System.out.println("STANDARD CLASS");
        for (int i=getFirstRows()-1; i < seats.length ; i++){
            for (int j=0; j< seats[i].length ; j++){
                if (seats[i][j]!=null){
                    System.out.println("ROW: "+i+" SEAT: "+cambiaColum(j)+" - "+getSeat(i,j).getName()+" "+getSeat(i,j).getSurname1()+" - AGE: "+getSeat(i,j).getAge());
                }
            }
        }
    }

    /**
     * Metodo que recibe una lista de personas y un nombre y devuelve la primera persona que esta en la lista con ese nombre
     * 
     * @param list lista de personas
     * @param name nombre de la persona a buscar
     * @return person persona con el nombre dado
     */
    public Person seekPerson(ArrayList<Person> list, String name)
    {
        if ( list != null && name != null ){
            for ( Person person : list){
                if (person.getName().equals(name)){
                    return person;
                }
            }
            return null;
        }
        else{
            throw new RuntimeException("Parametros incorrectos");
        }
    }

    /**
     * Metodo que recibe tres nombres y devuelve un array con las tres primeras personas con esos nombres
     * 
     * @param name1 primer nombre
     * @param name2 segundo nombre
     * @param name3 tercer nombre
     * @return array de tres posiciones con las personas cuyos nombres se reciben como par?tro
     */
    public Person[] seekPersons(String name1, String name2, String name3)
    {
        if ( name1 != null && name2 != null && name3 != null ){
            Person[] persons = new Person[3];
            for ( int i = 0; i < seats.length; i++ ){
                for ( int j = 0; j < seats[i].length; j++){
                    if ( seats[i][j].getName().equals(name1) ){
                        persons[0] = seats[i][j];
                    }
                    else if ( seats[i][j].getName().equals(name2) ){
                        persons[1] = seats[i][j];
                    }
                    else if ( seats[i][j].getName().equals(name3) ){
                        persons[2] = seats[i][j];
                    }
                }
            }
            return persons;
        }
        else
        {
            throw new RuntimeException("Parametros incorrectos");
        }
    }

    /**
     * Metodo que copia una parte de una matriz en otra
     * 
     * @param row fila de comienzo
     * @param colum columna de comienzo
     * @return copia el trozo de la matriz de asientos desde la fila y columna de comienzo hasta el final
     */
    public Person[][] copyPieceOfSeats(int row, int colum)
    {
        Person[][] personas = new Person[seats.length-row][COLUMNS-colum];
        int contador=0;
        int contador2=0;
        if (row>=0 && row<seats.length && colum >= 0 && colum <= COLUMNS){
            for (int i=row; i < seats.length;i++){
                for (int j=colum; j< seats[i].length;j++){
                    personas[contador][contador2]=seats[i][j];
                    contador2++;
                }
                contador2=0;
                contador++;
            }
            return personas;
        }
        else{
            throw new RuntimeException("Parametros incorrectos");
        }
    }

    /**
     * Metodo que recibe una matriz de personas y devuelve un array list de posiciones con las posiciones libres del avion
     * @param personas, matriz de personas
     * @return devuelve un arrayList de posiciones libres
     */
    public ArrayList<Position> listOfFreeSeats(Person[][] personas)
    {
        if(personas != null){   
            ArrayList<Position> posiciones = new ArrayList<Position>(); 
            for (int i=0; i<personas.length; i++){
                for (int j=0; j<personas[i].length; j++){
                    if (personas[i][j]== null){
                        posiciones.add(new Position(i,j));
                    }
                }
            }
            return posiciones;
        }
        else{
            throw new RuntimeException("Parametros incorrectos");
        }
    }

    /**
     * Metodo que recibe dos numeros de filas e intercambia las personas de la matriz sentadas fila pasada como primer parametro con las filas  pasada como
     * segundo parametro, quedando todas ellas en la misma columna
     * 
     * @param row1, fila 1
     * @param row2, fila 2
     */
    public void changeRows(int row1,int row2)
    {
        if(row1>=0 && row1<seats.length && row2>=0 && row2<seats.length){
            Person aux;
            for (int i=0; i< seats[row1].length; i++){
                aux = seats[row1][i];
                seats[row1][i]=seats[row2][i];
                seats[row2][i]= aux;
            }
        }
        else{
            throw new RuntimeException("Parametros incorrectos");
        }
    }

    /**
     * Metodo que cambia de sexo a todas las personas mayores de edad con reserva en el avion situadas en una determinada columna
     * 
     * @param colum , columna a la que se le quiere cambiar de sexo a los mayores de edad
     */
    public void changeGender(int colum)
    {
        if(colum >=0 && colum < COLUMNS){
            for (int i=0; i< seats.length; i++){
                if(seats[i][colum] != null && (seats[i][colum].getAge() > Person.ADULTHOOD_AGE)){
                    seats[i][colum].changeGender(!seats[i][colum].getGender());
                }
            }
        }
        else{
            throw new RuntimeException("Parametros incorrectos");
        }
    }
}

