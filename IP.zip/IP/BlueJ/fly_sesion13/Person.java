import java.util.Random;

/**
 * Clase person correspondiente a la Sesion 1 de IP , servira para gestionar personas en un avion
 * 
 * @author (Antonio Paya Gonzalez) 
 * @version (28/11/2015)
 */
public class Person
{
    //Constantes definidas en la clase

    public final static int MIN_AGE = 0;        //valor minimo de la edad
    public final static int MAX_AGE = 120;      // valor máximo de la edad

    public final static boolean GENDER_MALE = true;
    public final static boolean GENDER_FEMALE = false;

    public final static int ADULTHOOD_AGE = 18;      //edad necesaria para ser adulto
    public final static int RETIREMENT_AGE = 65;    //edad de jubilación

    public final static int CURRENT_YEAR = 2015;   //anio actual
    
    public final static String maleNames[]= {"Pedro","Juan","Antonio","Carlos","Godofredo","Mariano","Wilfred"};
    public final static String surnames[]= {"Gutierrez","Martinez","Gonzalez","Diaz","Garcia","Menendez","Alvarez"};
    public final static String femaleNames[]= {"Sara","Lucia","Paula","Maria","Dolores","Marina","Silvia"};

    //Constantes para los valores estandar de los atributos
    public final static String STANDARD_NAME = "Fernando";
    public final static String STANDARD_SURNAME1 = "Alonso";
    public final static int STANDARD_AGE = 35;
    public final static boolean STANDARD_GENDER = GENDER_MALE;

    // Atributos o propiedades de la clase Person
    private String name;
    private String surname1;
    private String surname2;
    private int age;
    private boolean gender;


    /**
     * Constructor de los objetos
     * Crea un objeto con nombre y Apellidos de Fernando Alonso
     * Edad aleatoria
     */
    public Person()
    {
        Random random = new Random();
        setAge(random.nextInt(120));
        setSurname1((surnames[random.nextInt(surnames.length)]));
        int temp = random.nextInt(2);
        if (temp == 1){
            setGender(true);
            setName((maleNames[random.nextInt(maleNames.length)]));
        }
        else {
            setGender(false);
            setName((femaleNames[random.nextInt(femaleNames.length)]));
        }
    }
    /**
     * Constructor que toma los valores por defecto , pero salvo la edad que la recibe como parámetro
     * @param edad de la persona , de tipo entero
     */
    public Person(int age)
    {
        this(); //llama al constructor sin parámetros , ya que this() no tiene parámetros 
        setAge(age);

    }
    /**
     * Constructor que recibe como parámetro todos sus atributos , en caso de error dejará los valores estandar de Fernando Alonso
     * @param age, edad de tipo entero
     * @param name, nombre de tipo String
     * @param surname1 , apellido de tipo String
     * @param gender , género de tipo booleano (GENDER_MALE o GENDER_FEMALE)
     */
    public Person(int age, String name, String surname1, boolean gender)
    {
        this(); //llama al constructor sin parámetros , ya que this() no tiene parámetros 
        setAge(age);
        setName(name);
        setSurname1(surname1);
        setGender(gender);

    }
    /**
     * Metodo que modifica el valor del atributo name
     * 
     * @param  newName nuevo nombre para la clase persona, será un String 
     */
    public void setName(String name)
    {
        this.name = name;
    }

    /**
     * Método que devuelve el valor del atributo name
     *
     * @return   devuelve el valor del atributo name ,que es un String  
     */
    public String getName()
    {
        return name;
    }

    /**
     * Método que modifica el valor del atributo age
     *
     * @param  newAge nueva edad para la clase persona, será un entero
     */
    public void setAge(int age)
    {

        if ( age >= MIN_AGE && age < MAX_AGE ){
            this.age = age;
        }
    }

    /**
     * Método que devuelve el valor del atributo age
     *
     * @return     devuelve el valor del atributo age, que es un entero
     */
    public int getAge()
    {      
        return age;
    }

    /**
     * Metodo que modifica el valor del atributo surname1
     * 
     * @param  newSurname1 nuevo apellido para la clase persona, será un String 
     */
    public void setSurname1(String surname1)
    {
        this.surname1 = surname1;
    }

    /**
     * Método que devuelve el valor del atributo surname1
     *
     * @return   devuelve el valor del atributo surnname1 ,que es un String  
     */
    public String getSurname1()
    {
        return surname1;
    }

    /**
     * Metodo que modifica el valor del atributo surname2
     * 
     * @param  newSurname2 nuevo apellido para la clase persona, será un String 
     */
    public void setSurname2(String surname2)
    {
        this.surname2 = surname2;
    }

    /**
     * Método que devuelve el valor del atributo surname2
     *
     * @return   devuelve el valor del atributo surnname2 ,que es un String  
     */
    public String getSurname2()
    {
        return surname2;
    }

    /**
     * Metodo que modifica el valor del atributo gender
     * 
     * @param  gender nuevo apellido para la clase persona, será un booleano
     * 
     * Si el valor de gender es true , será Male, si es false , será Female
     */
    public void setGender(boolean gender)
    {
        this.gender = gender;
    }

    /**
     * Método que devuelve el valor del atributo 
     *
     * @return   devuelve el valor del atributo gender  ,que es un booleano
     */
    public boolean getGender()
    {
        return gender;
    }

    
    /**
     * Método que muestra por pantalla lo siguiente:
     * "Tengo x años y el año que viene tendré x+1"
     * Además debe imprimir en otra línea los valores de los atributos según formato estandar
     */
    public void print()
    {

        System.out.println("Me llamo "+ this.getName() + "y tengo " + getAge() + " años y el año que viene tendré " + (getAge()+1) );
        System.out.println( toString() );

    }

    
    /**
     * Método que devuelve una cadena con los valores de los atributos en el siguiente formato:
     * Nombre:valor ; Apellido:valor ; Edad:valor ; Género:valor
     * 
     * @return String cadena con valores de los atributos
     */
    public String toString()
    {
        String data;          //declaro una variable local de tipo String
        data = "Nombre: "+ getName()+ " ; Apellido:"+ getSurname1() + " ; Edad: "+ getAge() + " ; Género: ";
        if (getGender() == GENDER_MALE){
            data = data + " Masculino";
            return data;
        }
        else {
            data = data + " Femenino";
            return data;
        }
    }

    /**
     * Este es un método que devuelve:
     *  si la persona es menor de edad , el número de años que le faltan para tener los 18
     *  Si la persona ha llegado a la edad adulta y menor de 65 años,  el número de años que le faltan para llegar a la edad de jubilación (65 años)
     *  Si la persona ha llegado a la jubilación, el número de años que han trascurrido desde la jubilación
     *
     * @return     devuelve como String si es un menor de edad, adulto o jubilado , y los años que le faltan para pasar de ser menor a adulto y de adulto a jubilado
     */
    public String getCriticalAge()
    {
        if (age < ADULTHOOD_AGE){
            return "Es menor de edad y le quedan " + (ADULTHOOD_AGE - age) + " años para ser mayor de edad"; 

        }
        if (age > ADULTHOOD_AGE && age < RETIREMENT_AGE){
            return "es un adulto al que le quedan " + (RETIREMENT_AGE - age) + " años para jubilarse" ;
        }
        if (age == ADULTHOOD_AGE) {
            return "acaba de ser mayor de edad";
        }
        if (age == RETIREMENT_AGE) {
            return "acaba de jubilarse";
        }
        else{
            return "Lleva jubilado " + (age - RETIREMENT_AGE)+ " años";
        }
    }

    /**
     *Método que devuelve un código (una cadena) con información extraída de los valores de los atributos con el siguiente formato:
     *1. La edad
     *2. Un guión “-�? 
     *3. El nombre en mayúsculas 
     *4. Un guión “-�? 
     *5. La longitud del nombre  
     *6. Un guión “-�? 
     *7. El apellido en mayúsculas 
     *8. Un guión “-�? 
     *9. La longitud del apellido
     *
     *@return devuleve una cadena (String) con el formato:  “35-PEDRO-5-ALVAREZ-7�? 
     */
    public String getHashCode()
    {

        String nombre = new String(getName());
        String apellido = new String(getSurname1());
        return getAge() + "-" + getName().toUpperCase() + "-" + nombre.length() + "-" + getSurname1().toUpperCase() + "-" + apellido.length() ;
    }

    /**
     * Método que cambia la edad de la persona a aquella calculada a partir del año de nacimiento recibido
     * como parámetro.
     * Además devuelve el numero de años (edad) que ha incrementado o reducido , si la mantiene o si no es posible cambiarla.
     * Solo se podra cambiar la edad si difiere de la antigua en un máximo de 5 años arriba o abajo
     *
     * @param  newBirthYear , nuevo año de nacimiento , sera de tipo int
     * @return   devuelve un String con el numero de años (edad) que ha incrementado o reducido , si la mantiene o si no es posible cambiarla.
     */
    public String changeMyAge(int newBirthYear)
    {
        int BirthYear = (CURRENT_YEAR - newBirthYear);
        int edadAntigua = getAge();

        
        if(BirthYear > (edadAntigua + 5) || BirthYear < (edadAntigua - 5)){
            return "NO ES POSIBLE CAMBIAR LA EDAD";
        }
        else if(BirthYear <= (edadAntigua + 5) && BirthYear > edadAntigua){
            setAge(BirthYear);
            return "HE INCREMENTADO LA EDAD "+(BirthYear - edadAntigua)+ " AÑOS";
        }
        else if(BirthYear >= (edadAntigua - 5) && BirthYear < edadAntigua){
            setAge(BirthYear);
            return "HE REDUCIDO LA EDAD "+ (edadAntigua - BirthYear)+ " AÑOS";
        }
        else {
            return "MANTENGO LA EDAD";
        }

    }
    
    /**
     * Metodo que modifica el valor del atributo gender
     * 
     * @param  gender 
     * 
     * Si el valor de gender es true , sera Male, si es false , sera Female
     */
    public void changeGender(boolean gender)
    {
        this.gender = gender;
    }
}
        
   
