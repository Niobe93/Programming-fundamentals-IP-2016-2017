

import static org.junit.Assert.*;
import org.junit.Test;

/**
 * The test class BusTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class BusTest
{
    @Test
    public void testToString()
    {
        Bus bus1 = new Bus();
        
        bus1.driverExists(false);
        bus1.setAvailableSeats(30);
        assertEquals("OUT OF SERVICE" + " - " + 30, bus1.toString());
        
        bus1.driverExists(true);
        bus1.setAvailableSeats(50);
        assertEquals("ON DUTY" + " - " + 50, bus1.toString());
        
    }
    
    @Test
    public void testGetAvailableSeats()
    {
        Bus bus1 = new Bus();
        
        //Pruebas positivas
        bus1.setAvailableSeats(30);
        assertEquals(30, bus1.getAvailableSeats());
        
        bus1.setAvailableSeats(0);
        assertEquals(0, bus1.getAvailableSeats());
        
        //Pruebas negativas
        bus1.setAvailableSeats(70);
        assertEquals(60, bus1.getAvailableSeats());
        
         bus1.setAvailableSeats(-70);
        assertEquals(60, bus1.getAvailableSeats());
        
    }
    
    @Test
    public void testGetOn()
    {
        Bus bus1 = new Bus();
        
        //pruebas positivas
        bus1.getOn(10);
        bus1.setAvailableSeats(40);
        bus1.driverExists(true);
        assertEquals(true, bus1.getOn(10));
        
        //pruebas negativas
        bus1.getOn(70);
        bus1.setAvailableSeats(40);
        bus1.driverExists(true);
        assertEquals(false, bus1.getOn(70));
        
         bus1.getOn(10);
        bus1.setAvailableSeats(40);
        bus1.driverExists(false);
        assertEquals(false, bus1.getOn(10));
        
    }
    
  

}
