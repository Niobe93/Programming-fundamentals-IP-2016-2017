
/**
 * Clase  Position
 * 
 * @author (Antonio Paya) 
 * @version (a version number or a date)
 */
public class Position
{
    // Atributos
    private int row;
    private int colum;
    
    /**
     * Constructor de la clase Position
     */
    public Position(int fila,int columna)
    {
        row = fila;
        colum = columna;
    }
    
}
