
import static org.junit.Assert.*;
import org.junit.Test;

/**
 * The test class planeTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class planeTest
{
    @Test
    public void testPlaneWhithOneParameter()
    {
        //Caso 1: Combustible introducido mayor que el maximo
        Plane plane1 = new Plane(6000);
        assertEquals(plane1.STANDARD_PILOT,plane1.getPilot());
        assertEquals(plane1.STANDARD_IDENTIFIER,plane1.getIdentifier());
        assertEquals(plane1.STANDARD_FUEL,plane1.getFuel());
        assertEquals(0,plane1.getXSpeed());
        assertEquals(0,plane1.getYSpeed());
        assertEquals(0,plane1.getXPos());
        assertEquals(0,plane1.getYPos());
        assertEquals(false,plane1.getLandingGear().getNose().isDeployed());
        assertEquals(false,plane1.getLandingGear().getLeft().isDeployed());
        assertEquals(false,plane1.getLandingGear().getRight().isDeployed());
        assertEquals(true,plane1.getLandingGear().getLever());
        //Caso 2: Combustible introducido dentro de los limites
        Plane plane2 = new Plane(4000);
        assertEquals(plane2.STANDARD_PILOT,plane2.getPilot());
        assertEquals(plane2.STANDARD_IDENTIFIER,plane2.getIdentifier());
        assertEquals(4000,plane2.getFuel());
        assertEquals(0,plane2.getXSpeed());
        assertEquals(0,plane2.getYSpeed());
        assertEquals(0,plane2.getXPos());
        assertEquals(0,plane2.getYPos());
        assertEquals(false,plane2.getLandingGear().getNose().isDeployed());
        assertEquals(false,plane2.getLandingGear().getLeft().isDeployed());
        assertEquals(false,plane2.getLandingGear().getRight().isDeployed());
        assertEquals(true,plane2.getLandingGear().getLever());
        //Caso 3: Combustible introducido en el limite superior
        Plane plane3 = new Plane(5000);
        assertEquals(plane3.STANDARD_PILOT,plane3.getPilot());
        assertEquals(plane3.STANDARD_IDENTIFIER,plane3.getIdentifier());
        assertEquals(5000,plane3.getFuel());
        assertEquals(0,plane3.getXSpeed());
        assertEquals(0,plane3.getYSpeed());
        assertEquals(0,plane3.getXPos());
        assertEquals(0,plane3.getYPos());
        assertEquals(false,plane3.getLandingGear().getNose().isDeployed());
        assertEquals(false,plane3.getLandingGear().getLeft().isDeployed());
        assertEquals(false,plane3.getLandingGear().getRight().isDeployed());
        assertEquals(true,plane3.getLandingGear().getLever());
        //Caso 4: Combustible introducido en el limite inferior
        Plane plane4 = new Plane(0);
        assertEquals(plane4.STANDARD_PILOT,plane4.getPilot());
        assertEquals(plane4.STANDARD_IDENTIFIER,plane4.getIdentifier());
        assertEquals(0,plane4.getFuel());
        assertEquals(0,plane4.getXSpeed());
        assertEquals(0,plane4.getYSpeed());
        assertEquals(0,plane4.getXPos());
        assertEquals(0,plane4.getYPos());
        assertEquals(false,plane4.getLandingGear().getNose().isDeployed());
        assertEquals(false,plane4.getLandingGear().getLeft().isDeployed());
        assertEquals(false,plane4.getLandingGear().getRight().isDeployed());
        assertEquals(true,plane4.getLandingGear().getLever());
        //Caso 4: Combustible introducido debajo del limite inferior
        Plane plane5 = new Plane(-1000);
        assertEquals(plane5.STANDARD_PILOT,plane5.getPilot());
        assertEquals(plane5.STANDARD_IDENTIFIER,plane5.getIdentifier());
        assertEquals(plane1.STANDARD_FUEL,plane5.getFuel());
        assertEquals(0,plane5.getXSpeed());
        assertEquals(0,plane5.getYSpeed());
        assertEquals(0,plane5.getXPos());
        assertEquals(0,plane5.getYPos());
        assertEquals(false,plane5.getLandingGear().getNose().isDeployed());
        assertEquals(false,plane5.getLandingGear().getLeft().isDeployed());
        assertEquals(false,plane5.getLandingGear().getRight().isDeployed());
        assertEquals(true,plane5.getLandingGear().getLever());
    }

    @Test
    public void testSetFuel()
    {
        Plane plane1 = new Plane();

        //Pruebas positivas
        //Caso 1 : combustible dento de los límites

        plane1.setFuel(200);
        assertEquals(200, plane1.getFuel());

        plane1.setFuel(0);
        assertEquals(0, plane1.getFuel());

        plane1.setFuel(plane1.STANDARD_MAXFUEL);
        assertEquals(plane1.STANDARD_MAXFUEL, plane1.getFuel());

        //Pruebas negativas
        //Caso 2 : combustible fuera de los límites
        plane1.setFuel(-4);
        assertEquals(plane1.STANDARD_MAXFUEL, plane1.getFuel());

        plane1.setFuel(10000000);
        assertEquals(plane1.STANDARD_MAXFUEL, plane1.getFuel());

    }

    @Test
    public void testFly()
    {
        Plane plane1 = new Plane();

        plane1.setFuel(Plane.STANDARD_MINFUEL);
        assertEquals(false, plane1.fly());
        assertEquals(Plane.STANDARD_MINFUEL,plane1.getFuel());

        plane1.setFuel(plane1.STANDARD_MAXFUEL);
        assertEquals(true, plane1.fly());
        assertEquals((Plane.STANDARD_MAXFUEL - 1),plane1.getFuel());

    }

    @Test
    public void testConstructorWithoutParameters()
    {
        Plane plane1 = new Plane();

        assertEquals(Plane.STANDARD_PILOT, plane1.getPilot());
        assertEquals(Plane.STANDARD_IDENTIFIER, plane1.getIdentifier());
        assertEquals(Plane.STANDARD_FUEL, plane1.getFuel());

    }

    @Test
    public void testConstructorWithXposYposParameters()
    {
        //Pruebas positivas:
        //caso1: parametros dentro de limites
        Plane plane1 = new Plane(Plane.MIN_X +1, Plane.MIN_Y +1);
        assertEquals(Plane.MIN_X +1,plane1.getXPos()); 
        assertEquals(Plane.MIN_Y +1,plane1.getYPos()); 
        //caso2: parametros en limite inferior
        Plane plane2 = new Plane(Plane.MIN_X, Plane.MIN_Y);
        assertEquals(Plane.MIN_X,plane2.getXPos()); 
        assertEquals(Plane.MIN_Y,plane2.getYPos());
        //caso3: parametros en limite superior
        Plane plane3 = new Plane(Plane.MAX_X, Plane.MAX_Y);
        assertEquals(Plane.MAX_X,plane3.getXPos()); 
        assertEquals(Plane.MAX_Y,plane3.getYPos());

        //Pruebas negativas
        //caso4: parametros por debajo de limite inferior
        Plane plane4 = new Plane(Plane.MIN_X -1, Plane.MIN_Y -1);
        assertEquals(0,plane4.getXPos()); 
        assertEquals(0,plane4.getYPos()); 
        //caso5: parametros por encima de limite inferior
        Plane plane5 = new Plane(Plane.MAX_X +1, Plane.MAX_Y +1);
        assertEquals(0,plane5.getXPos()); 
        assertEquals(0,plane5.getYPos()); 

    }

    @Test
    public void testAccelerate0()
    {
        Plane plane1 = new Plane();

        //Pruebas positivas
        plane1.accelerate0(1,-1);
        assertEquals(1,plane1.getXSpeed());
        assertEquals(-1,plane1.getYSpeed());

        plane1.accelerate0(0,0);
        assertEquals(0,plane1.getXSpeed());
        assertEquals(0,plane1.getYSpeed());

        plane1.accelerate0(1,0);
        assertEquals(1,plane1.getXSpeed());
        assertEquals(0,plane1.getYSpeed());

        //Pruebas negativas
        plane1.accelerate0(8,-1);
        assertEquals(1,plane1.getXSpeed());
        assertEquals(-1,plane1.getYSpeed());

        plane1.accelerate0(0,9);
        assertEquals(0,plane1.getXSpeed());
        assertEquals(-1,plane1.getYSpeed());

    }

    /**
     * Metodo que prueba el metodo fly
     */
    @Test
    public void testFlyWhithHours()
    {
//         //Caso 1: Todo correcto 
//         Plane plane1 = new Plane(4000);
//         plane1.getLandingGear().moveLever(plane1.getLandingGear().LEVER_DOWN);
//         assertEquals(3000,plane1.fly(2));
//         for (int i=0;i<=plane1.getLandingGear().getNose().size();i++){
//             assertEquals(1729.0,plane1.getLandingGear().getNose().getWheel(i).getPressure(),0.1);
//         }
// 
//         //Caso 2: Falla el que no esta desplegado el LandingGear
//         Plane plane2 = new Plane(4000);
//         assertEquals(-1,plane2.fly(2));
// 
//         //Caso 3: Las horas son mas que el combustible para esas horas
//         Plane plane3 = new Plane(4000);
//         assertEquals(-1,plane3.fly(200));
// 
//         //Caso 4: Falla el test del LandingGear de aterrizaje
//         Plane plane4 = new Plane(4000);
//         for (int i=0;i<=plane4.getLandingGear().getNose().size();i++){
//             plane4.getLandingGear().getNose().getWheel(i).reducePressure(1000);
//         }
//         assertEquals(-1,plane4.fly(200));
// 
//         //Caso 4: Horas negativas
//         Plane plane5 = new Plane(4000);
//         for (int i=0;i<=plane5.getLandingGear().getNose().size();i++){
//             plane5.getLandingGear().getNose().getWheel(i).reducePressure(1000);
//         }
//         assertEquals(-1,plane5.fly(-10));
    }

}
