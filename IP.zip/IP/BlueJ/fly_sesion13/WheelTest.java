
import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class WheelTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class WheelTest
{
    /**
     * Default constructor for test class WheelTest
     */
    public WheelTest()
    {
    }

    /**Metodo de prueba para el constructor de dos parametros
     * 
     */
    @Test
    public void testWheelWithParams(){
        //Pruebas positivas
        //caso1: ambos parametros dentro de los limites
        Wheel wheel1 = new Wheel(Wheel.MIN_PRESSURE +1 , Wheel.MIN_PRESSURE +0.5); 
        assertEquals(Wheel.MIN_PRESSURE +1 , wheel1.getMaxPressure(),0.1);
        assertEquals(Wheel.MIN_PRESSURE +0.5 , wheel1.getPressure(),0.1);
        //caso2: ambos parametros en limite inferior
        wheel1 = new Wheel(Wheel.MIN_PRESSURE , Wheel.MIN_PRESSURE); 
        assertEquals(Wheel.MIN_PRESSURE, wheel1.getMaxPressure(),0.1);
        assertEquals(Wheel.MIN_PRESSURE, wheel1.getPressure(),0.1);
        //caso3: pressure en limite superior y MaxPressure dentro de limite 
        wheel1 = new Wheel(Wheel.MIN_PRESSURE +10 , Wheel.MIN_PRESSURE +10); 
        assertEquals(Wheel.MIN_PRESSURE +10, wheel1.getMaxPressure(),0.1);
        assertEquals(Wheel.MIN_PRESSURE +10, wheel1.getPressure(),0.1);
        
        //Pruebas negativas
        //caso4: ambos parametros debajo del limite inferior
        wheel1 = new Wheel(Wheel.MIN_PRESSURE -1 , Wheel.MIN_PRESSURE -2); 
        assertEquals(Wheel.MIN_PRESSURE, wheel1.getMaxPressure(),0.1);
        assertEquals(Wheel.MIN_PRESSURE, wheel1.getPressure(),0.1);
        //caso5:pressure por encima de limite superior
        wheel1 = new Wheel(Wheel.MIN_PRESSURE +1 , Wheel.MIN_PRESSURE +2); 
        assertEquals(Wheel.MIN_PRESSURE +1, wheel1.getMaxPressure(),0.1);
        assertEquals(Wheel.MIN_PRESSURE, wheel1.getPressure(),0.1);
    }
    
    @Test
    public void testTest(){
        //Pruebas positivas
        //caso1: Presion en el limite optimo inferior
        Wheel wheel1 = new Wheel(Wheel.MIN_PRESSURE +10 , Wheel.MIN_PRESSURE +8.5);
        assertEquals(true, wheel1.test());
        //caso2:Presion en el limite optimo superior
        wheel1 = new Wheel(Wheel.MIN_PRESSURE +10 , Wheel.MIN_PRESSURE +10);
        assertEquals(true, wheel1.test());
        //caso3:Presion optima dentro de los limites
        wheel1 = new Wheel(Wheel.MIN_PRESSURE +10 , Wheel.MIN_PRESSURE +9);
        assertEquals(true, wheel1.test());
        
        //Pruebas negativas
        //caso4:Presion por encima de la presion maxima
        wheel1 = new Wheel(Wheel.MIN_PRESSURE +10 , Wheel.MIN_PRESSURE +4);
        assertEquals(false, wheel1.test());
    }
    
    @Test
    public void testPrint(){
        Wheel wheel1 = new Wheel(1000,900);
        wheel1.print();
        wheel1 = new Wheel(1000,300);
        wheel1.print();
    }
    
    /**
     * Metodo que prueba el metodo reducePressure
     */
    @Test
    public void testReducePressure(){
        Wheel rueda = new Wheel(1000,900);

        //Caso 1: Se reduce dentro de los limites
        rueda.reducePressure(100);
        assertEquals(800,rueda.getPressure(),0.1);
        //Caso 2: Se introduce cantidad negativa
        rueda.reducePressure(-100);
        assertEquals(800,rueda.getPressure(),0.1);
        //Caso 3: La cantidad reducida es mayor que la actual
        rueda.reducePressure(900);
        assertEquals(800,rueda.getPressure(),0.1);
        //Caso 4: La cantidad reducida es la misma que la actual
        rueda.reducePressure(800);
        assertEquals(800,rueda.getPressure(),0.1);
    }
}
