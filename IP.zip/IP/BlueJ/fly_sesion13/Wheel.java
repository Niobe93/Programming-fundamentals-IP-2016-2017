
/**
 * Clase Wheel , que es una rueda del avi�n, corresponde a la sesion 6
 * Dispone de presion maxima y actual
 * Tendra un metodo que compruebe si la presion es adecuada
 * Tendra otro metodo que muestre informacion sobre su estado
 * 
 * @author (Antonio Paya Gonzalez) 
 * @version (21/10/2015)
 */
public class Wheel
{
    //Constantes 
    public static final double MIN_PRESSURE = 0;    //Valor minimo de presion

    // Atributos
    private double maxPressure;     //Presion maxima para la rueda
    private double pressure;        //Presion actual de la rueda

    /**
     * Constructor con dos parametros de la clase Wheel
     * 
     * @param maxPressure, presion maxima para la rueda, de tipo double
     * @param pressure , presion actual de la rueda , de tipo double
     */
    public Wheel(double maxPressure,double pressure)
    {
        setMaxPressure(maxPressure);
        setPressure(pressure);
    }

    /**
     * Metodo que modifica el valor del atributo maxPressure
     *
     * @param  maxPressure, nuevo valor para la presion maxima de la rueda
     */
    private void setMaxPressure(double maxPressure)
    {
        if (maxPressure > MIN_PRESSURE){
            this.maxPressure = maxPressure;
        }
    }

    /**
     * Metodo que modifica el valor del atributo pressure
     *
     * @param  pressure, nuevo valor para la presion actual de la rueda
     */
    private void setPressure(double pressure)
    {
        if (pressure > MIN_PRESSURE && pressure <= getMaxPressure()){
            this.pressure = pressure;
        }
    }

    /**
     * Metodo que devuelve el valor del atributo maxPressure
     *
     * @return  maxPressure,  valor para la presion maxima de la rueda
     */
    public double getMaxPressure()
    {
        return maxPressure;
    }

    /**
     * Metodo que devuelve el valor del atributo pressure
     *
     * @return  pressure,  valor para la presion actual de la rueda
     */
    public double getPressure()
    {
        return pressure;
    }

    //OTROS METODOS
    /**
     * Metodo que comprueba que la presion de las ruedas es adecuada, sera adecuada
     * si es mayor o igual que un umbral determinado (85 % de la presion maxima)
     * 
     * @return  true, si presion adecuada
     */
    public boolean test()
    {
        if ( pressure >= (0.85*getMaxPressure())){
            return true;
        }
        else{
            return false;
        }
    }

    /**
     * Metodo que imprima por pantalla el estado de la rueda con el siguiente formato:
     * Presion Maxima.....10Mb.
     * Presion Actual.....3Mb.
     * Test................Fail (OK si fallase)
     * 
     */
    public void print()
    {
        System.out.println("Presion Maxima......." + getMaxPressure() + " Mb");
        System.out.println("Presion Actual......." + getPressure() + " Mb");
        if (test()==true){
            System.out.println("Test OK");
        }
        else{
            System.out.println("Test FAIL");
        }

    }
    
    /**
     * M�todo que reduce la presion actual de la rueda la cantidad positiva recibida como parametro
     * 
     * @param value, de tipo int, valor positivo en el que se reduce la presion
     */
    public void reducePressure(int value)
    {
        if (value >= 0){
            setPressure(getPressure()-value);
        }
    }
}
