import java.util.ArrayList;

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class SeatManagerTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class SeatManagerTestL6
{
    

         @Test
        public void testListOfFreeSeatsParametroIncorrecto()
        {
             try
         {
             SeatManager seatManager1 = new SeatManager(5,5);
           
             seatManager1.listOfFreeSeats(null);
             fail();
         }
         catch (RuntimeException e)
         {
             assertEquals("Parametros incorrectos", e.getMessage());
         }
        }
        @Test
        public void changeRoadFilaLlenaFilaVacia()
        {
            // caso 1 cambio una fila llena por otra vacía
              SeatManager seatManager1 = new SeatManager(5,5);
              for (int j=0; j<6; j++)
                seatManager1.bookSeat(new Person(), 0,j);
              seatManager1.changeRows(0, 2);
              for (int j=0; j<6; j++)
                  assertNull(seatManager1.getSeat(0,j));
              for (int j=0; j<6; j++)
                  assertNotNull(seatManager1.getSeat(2,j));
        }
        
        @Test
        public void changeRoadFilaMediadaFilaMediada()
        {
            // caso 2 cambio una mediada por otra mediada
            SeatManager seatManager1 = new SeatManager(5,5);
             for (int j=0; j<6; j=j+2)
                seatManager1.bookSeat(new Person(), 0,j);
             seatManager1.changeRows(0, 2);  
             for (int j=0; j<6; j++)
                  assertNull(seatManager1.getSeat(0,j));
             for (int j=0; j<6; j=j+2)
                  assertNotNull(seatManager1.getSeat(2,j));
             for (int j=1; j<6; j=j+2)
                  assertNull(seatManager1.getSeat(2,j));
         }
         
            // caso 3 parámetro incorrecto
         @Test
        public void changeRoadParametroIncorrecto()
        {
             try
         {
             SeatManager seatManager1 = new SeatManager(5,5);
           
             seatManager1.changeRows(-10, 2);  
             fail();
         }
         catch (RuntimeException e)
         {
             assertEquals("Parametros incorrectos", e.getMessage());
         }
           try
         {
             SeatManager seatManager1 = new SeatManager(5,5);
           
             seatManager1.changeRows(20, 2);  
             fail();
         }
         catch (RuntimeException e)
         {
             assertEquals("Parametros incorrectos", e.getMessage());
         }
        try
         {
             SeatManager seatManager1 = new SeatManager(5,5);
           
             seatManager1.changeRows(0, -2);  
             fail();
         }
         catch (RuntimeException e)
         {
             assertEquals("Parametros incorrectos", e.getMessage());
         }
         try
         {
             SeatManager seatManager1 = new SeatManager(5,5);
           
             seatManager1.changeRows(0, 20);  
             fail();
         }
         catch (RuntimeException e)
         {
             assertEquals("Parametros incorrectos", e.getMessage());
         }
        }
        @Test
        public void testChangeGenderColumnaVacia()
        {
            // caso 1 columna vacía
            SeatManager seatManager1 = new SeatManager(5,5);
            seatManager1.changeGender(2);
            for (int i=0; i<10; i++)
                assertNull(seatManager1.getSeat(i,2));
        }
         @Test
        public void testChangeGenderColumnaLLena()
        {
        
            // caso 2 columna llena
            SeatManager seatManager1 = new SeatManager(5,5);
            for (int i=0; i<10; i++)
                seatManager1.bookSeat(new Person(),i,2);
            boolean[] colum = new boolean[10];
            for (int i=0; i<10; i++)    
                colum [i]= seatManager1.getSeat(i,2).getGender();   //getGender en vez de getSex que es el metodo implementado en esta proyecto
            seatManager1.changeGender(2);
            for (int i=0; i<10; i++)
            {
                if(seatManager1.getSeats()[i][2].getAge()>=18)
                {
                     assertEquals(seatManager1.getSeat(i,2).getGender(),! colum[i]);
                }
                else
                {
                    assertEquals(seatManager1.getSeat(i,2).getGender(),colum[i]);
                }
            }
         }
            
          @Test
        public void testChangeGenderParametroIncorrecto()
        {   
            // caso 3 parámetro incorrecto
            try
         {
             SeatManager seatManager1 = new SeatManager(5,5);
           
            seatManager1.changeGender(20); 
             fail();
         }
         catch (RuntimeException e)
         {
             assertEquals("Parametros incorrectos", e.getMessage());
         }
           
            // caso 3 parámetro incorrecto
            try
         {
             SeatManager seatManager1 = new SeatManager(5,5);
           
            seatManager1.changeGender(-20); 
             fail();
         }
         catch (RuntimeException e)
         {
             assertEquals("Parametros incorrectos", e.getMessage());
         }
         
        }
        
        
    
}
