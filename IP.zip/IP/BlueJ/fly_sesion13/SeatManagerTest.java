
import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import java.util.ArrayList;
/**
 * The test class SeatManagerTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class SeatManagerTest
{
    /**
     * Prueba el metodo BookSeat
     */
    @Test
    public void TestBookSeat()
    {
        //Caso 1: el asiento esta ocupado
        SeatManager seatManager1 = new SeatManager(4,5);
        Person p1 = new Person();
        seatManager1.bookSeat(p1,1,1);

        assertEquals(false,seatManager1.bookSeat(new Person(),1,1));
        assertEquals(p1,seatManager1.getSeat(1,1));
        //Caso 2: el asiento no esta ocupado
        seatManager1 = new SeatManager(4,5);
        p1 = new Person();

        assertEquals(true,seatManager1.bookSeat(p1,1,1));
        assertEquals(p1,seatManager1.getSeat(1,1));
    }

    /**
     * Metodo de prueba del metodo oldestPassenger()
     */
    @Test
    public void TestOldestPassenger()
    {
        SeatManager sm = new SeatManager(3,4);
        Person person1 = new Person(19);
        Person person2 = new Person(98);
        Person person3 = new Person(56);
        Person person4 = new Person(98);

        // Caso 1: El avion esta vacio
        assertNull(sm.oldestPassenger());

        // Caso 2: Hay una sola persona en el avion
        assertTrue(sm.bookSeat(person1,1,1));
        assertEquals(person1, sm.oldestPassenger());

        // Caso 3: Personas con multiples edades
        assertTrue(sm.bookSeat(person2,1,2));
        assertTrue(sm.bookSeat(person3,1,3));
        assertEquals(person2, sm.oldestPassenger());

        // Caso 4: Dos personas con la misma edad la cual es la mayor
        assertTrue(sm.bookSeat(person4,1,4));
        assertEquals(person2, sm.oldestPassenger()); // Devuelve esta persona y no person4 porque, al recorrer los pasajeros, este no supera la edad m�xima, y no se registra
    }

    /**
     * Metodo de prueba para el el metodo numberOfSeats()
     */
    @Test
    public void TestNumberOfSeats()
    {
        SeatManager sm = new SeatManager(3,4);
        Person person1 = new Person(19);
        Person person2 = new Person(98);
        Person person3 = new Person(56);
        Person person4 = new Person(37);
        Person person5 = new Person(29);
        Person person6 = new Person(45);   

        // Caso 1: La fila esta vacia
        assertEquals(SeatManager.COLUMNS, sm.numberOfSeats(2));   

        // Caso 2: La fila tiene pasajeros
        assertTrue(sm.bookSeat(person1,2,0));
        assertTrue(sm.bookSeat(person2,2,1));
        assertTrue(sm.bookSeat(person3,2,2));
        assertTrue(sm.bookSeat(person4,2,3));                                 
        assertEquals(SeatManager.COLUMNS-4, sm.numberOfSeats(2));

        // Caso 3: La fila esta llena
        assertTrue(sm.bookSeat(person5,2,4));
        assertTrue(sm.bookSeat(person6,2,5));                                  
        assertEquals(SeatManager.COLUMNS-6, sm.numberOfSeats(2));   

        // Caso 4: La fila no existe
        try 
        {
            sm.numberOfSeats(7);  
            fail(); 
        }
        catch (Exception ex)
        {
            assertEquals("La fila especificada no existe", ex.getMessage());  
        }

        // Caso 5: La fila especificada es negativa
        try 
        {
            sm.numberOfSeats(-3);  
            fail();  
        }
        catch (Exception ex)
        {
            assertEquals("La fila especificada no existe", ex.getMessage());
        }
    }

    @Test
    public void TestRelaeseSeat()
    {
        //Caso 1: Liberar un sitio vacio
        SeatManager sm = new SeatManager(4,5);
        for (int i=0; i < 9; i++){
            for (int j=0; j < sm.COLUMNS; j++){
                assertNull(sm.releaseSeat(i,j));
            }
        }
        //Caso 2: Liberar un sitio con persona
        sm =  new SeatManager(4,5);
        Person p1 = new Person();
        sm.bookSeat(p1,1,1);
        assertEquals(p1,sm.releaseSeat(1,1));
        assertNull(sm.getSeat(1,1));
        //Caso 3: Parametros incorrectos
        //Caso 3.1: Fila menor que minimo
        sm =  new SeatManager(4,5);
        try 
        {
            sm.releaseSeat(-1,2);  
            fail();  
        }
        catch (Exception ex)
        {
            assertEquals("Parametros incorrectos", ex.getMessage());
        }
        //Caso 3.2: Fila mayor que maximo
        sm =  new SeatManager(4,5);
        try 
        {
            sm.releaseSeat(12,2);  
            fail();  
        }
        catch (Exception ex)
        {
            assertEquals("Parametros incorrectos", ex.getMessage());
        }
        //Caso 3.3: Columna menor que minimo
        sm =  new SeatManager(4,5);
        try 
        {
            sm.releaseSeat(2,-1);  
            fail();  
        }
        catch (Exception ex)
        {
            assertEquals("Parametros incorrectos", ex.getMessage());
        }
        //Caso 3.4: Columna mayor que maximo
        sm =  new SeatManager(4,5);
        try 
        {
            sm.releaseSeat(2,8);  
            fail();  
        }
        catch (Exception ex)
        {
            assertEquals("Parametros incorrectos", ex.getMessage());
        }
    }

    @Test
    public void TestGetYoungestPeople()
    {
        //Caso 1: Avion vacio
        SeatManager sm = new SeatManager(4,5);
        try 
        {
            sm.getYoungestPeople();
            fail();
        }
        catch (Exception ex)
        {
            assertEquals("Avion vacio", ex.getMessage());
        }
        //Caso 2: Avion con varias personas jovenes
        sm = new SeatManager(4,5);
        for (int i=0; i< sm.COLUMNS; i++){
            sm.bookSeat(new Person(18),0,i);
        }
        for (int j=0; j< sm.COLUMNS; j++){
            sm.bookSeat(new Person(28),0,j);
        }
        ArrayList<Person> list = sm.getYoungestPeople();
        assertEquals(sm.COLUMNS, list.size());
        for (int i=0; i< sm.COLUMNS; i++){
            assertEquals(18, list.get(i).getAge());
        }
    }

    @Test
    public void TestChildrenPassengers()
    {
        //Caso 1: Avion solo con mayores
        SeatManager sm = new SeatManager(4,5);
        for (int i=0; i< sm.COLUMNS; i++){
            sm.bookSeat(new Person(28),0,i);
        }
        for (int j=0; j< sm.COLUMNS; j++){
            sm.bookSeat(new Person(38),0,j);
        }
        for (int i=0; i<sm.childrenPassengers().size();i++){
            assertEquals(null,sm.childrenPassengers().get(i));
        }
        //Caso 2:Avion con algun ni�o
        sm = new SeatManager(4,5);
        for (int i=0; i< sm.COLUMNS; i++){
            sm.bookSeat(new Person(12),0,i);
        }
        for (int j=0; j< sm.COLUMNS; j++){
            sm.bookSeat(new Person(38),0,j);
        }
        ArrayList<Person> list = sm.childrenPassengers();
        assertEquals(sm.COLUMNS, list.size());
        for (int i=0; i< sm.COLUMNS; i++){
            assertEquals(12, list.get(i).getAge());
        }
        //Caso 3: Avion vacio
        sm = new SeatManager(4,5);
        try 
        {
            sm.getYoungestPeople();
            fail();
        }
        catch (Exception ex)
        {
            assertEquals("Avion vacio", ex.getMessage());
        }
    }

    @Test
    public void TestGetNumPax()
    {
        //Caso 1:Parametro incorrecto menor que 1
        SeatManager sm = new SeatManager(4,5);
        try 
        {
            byte temp = 0;
            sm.getNumPax(temp);
            fail();
        }
        catch (Exception ex)
        {
            assertEquals("El prametro introducido no es correcto", ex.getMessage());
        }
        //Caso 2:Parametro incorrecto mayor que 3
        sm = new SeatManager(4,5);
        try 
        {
            byte temp = 4;
            sm.getNumPax(temp);
            fail();
        }
        catch (Exception ex)
        {
            assertEquals("El prametro introducido no es correcto", ex.getMessage());
        }

        //Caso 3: Se introduce primera clase
        sm = new SeatManager(4,5);
        sm.loadPax(4);
        byte temp = 1;
        assertEquals(4,sm.getNumPax(temp));
        //Caso 4: Se introduce segunda clase
        sm = new SeatManager(4,5);
        sm.bookSeat(new Person(),4,4);
        sm.bookSeat(new Person(),4,3);
        byte temp2 = 2;
        assertEquals(2,sm.getNumPax(temp2));
        //Caso 5: Se introduce todo el avion
        sm = new SeatManager(4,5);
        sm.loadPax(4);
        sm.bookSeat(new Person(),4,4);
        sm.bookSeat(new Person(),4,3);
        byte temp3 = 3;
        assertEquals(6,sm.getNumPax(temp3));
    }

    @Test
    public void TestGetNumPaxBySection()
    {
        //Caso 1: Avion vacio
        SeatManager sm = new SeatManager(4,4);
        assertEquals(0,sm.getNumPaxBySection(0,0,4,4));
        //Caso 2: Una o mas personas en la zona seleccionada
        sm = new SeatManager(4,4);
        sm.loadPax(8);
        assertEquals(6,sm.getNumPaxBySection(0,0,1,3));
        //Caso 3: Avion con personas pero fuera de la zona seleccionada
        sm = new SeatManager(4,4);
        sm.bookSeat(new Person(),4,4);
        assertEquals(0,sm.getNumPaxBySection(0,0,1,2));
        //Caso 4: Algun parametro incorrecto
        sm = new SeatManager(4,4);
        //Caso 4.1 : Fila menor que 0
        try 
        {
            sm.getNumPaxBySection(0,0,-1,2);
            fail();
        }
        catch (Exception ex)
        {
            assertEquals("El prametro introducido no es correcto", ex.getMessage());
        }
        //Caso 4.2 : Columna menor que 0
        try 
        {
            sm.getNumPaxBySection(0,0,1,-2);
            fail();
        }
        catch (Exception ex)
        {
            assertEquals("El prametro introducido no es correcto", ex.getMessage());
        }
        //Caso 4.3; Fila mayor que maximo de filas
        try 
        {
            sm.getNumPaxBySection(0,0,12,2);
            fail();
        }
        catch (Exception ex)
        {
            assertEquals("El prametro introducido no es correcto", ex.getMessage());
        }
        //Caso 4.4 : Columna mayor que maximo de columnas
        try 
        {
            sm.getNumPaxBySection(0,0,3,8);
            fail();
        }
        catch (Exception ex)
        {
            assertEquals("El prametro introducido no es correcto", ex.getMessage());
        }
    }

    @Test
    public void TestLoadPax()
    {
        //Caso 1: Parametros incorrctos
        SeatManager sm = new SeatManager();
        try 
        {
            sm.loadPax(-1);
            fail();
        }
        catch (Exception ex)
        {
            assertEquals("El prametro introducido no es correcto", ex.getMessage());
        }
        //Caso 2: Todo correcto
        sm = new SeatManager(4,4);
        sm.loadPax(4);
        byte temp = 1;
        assertEquals(4,sm.getNumPax(temp));
    }

    @Test
    public void TestChangeGender()
    {
        //Caso 1: Parametros incorrctos: columna menor que 0
        SeatManager sm = new SeatManager();
        try 
        {
            sm.changeGender(-1);
            fail();
        }
        catch (Exception ex)
        {
            assertEquals("Parametros incorrectos", ex.getMessage());
        }
        //Caso 2: Parametros incorrectos: Columna mayor que maximo de columnas
        try 
        {
            sm.changeGender(8);
            fail();
        }
        catch (Exception ex)
        {
            assertEquals("Parametros incorrectos", ex.getMessage());
        }
        //Caso 3: Cambiar una columna sin mayores de edad
        sm = new SeatManager(4,4);
        sm.bookSeat(new Person(17,"Antonio","Paya",true),0,4);
        sm.bookSeat(new Person(12,"Felipe","Paya",true),1,4);
        sm.bookSeat(new Person(15,"Rodrigo","Paya",true),2,4);
        sm.changeGender(4);
        assertTrue(sm.getSeat(0,4).getGender());
        assertTrue(sm.getSeat(1,4).getGender());
        assertTrue(sm.getSeat(2,4).getGender());
        //Caso 4: Cambiar una columna con algun mayor de edad
        sm = new SeatManager(4,4);
        sm.bookSeat(new Person(17,"Antonio","Paya",true),0,4);
        sm.bookSeat(new Person(30,"Felipe","Paya",true),1,4);
        sm.bookSeat(new Person(68,"Rodrigo","Paya",true),2,4);
        sm.changeGender(4);
        assertTrue(sm.getSeat(0,4).getGender());
        assertFalse(sm.getSeat(1,4).getGender());
        assertFalse(sm.getSeat(2,4).getGender());
    }

    @Test
    public void TestChangeRows()
    {
        //Caso 1: Parametros incorrctos: fila menor que 0
        SeatManager sm = new SeatManager();
        try 
        {
            sm.changeRows(-1,1);
            fail();
        }
        catch (Exception ex)
        {
            assertEquals("Parametros incorrectos", ex.getMessage());
        }
        //Caso 2: Parametros incorrectos: Fila mayor que maximo de columnas
        try 
        {
            sm.changeRows(20,3);
            fail();
        }
        catch (Exception ex)
        {
            assertEquals("Parametros incorrectos", ex.getMessage());
        }
        //Caso 3: Cambiar dos filas correctamente
        sm = new SeatManager(4,4);

        sm.bookSeat(new Person(17),1,3);
        sm.bookSeat(new Person(30),1,4);
        sm.bookSeat(new Person(60),1,5);

        sm.bookSeat(new Person(20),3,3);
        sm.bookSeat(new Person(40),3,4);
        sm.bookSeat(new Person(50),3,5);

        sm.changeRows(1,3);
        assertEquals(20,sm.getSeat(1,3).getAge());
        assertEquals(40,sm.getSeat(1,4).getAge());
        assertEquals(50,sm.getSeat(1,5).getAge());

        assertEquals(17,sm.getSeat(3,3).getAge());
        assertEquals(30,sm.getSeat(3,4).getAge());
        assertEquals(60,sm.getSeat(3,5).getAge());
        
        //Caso 4:Cambiar dos filas siendo una de null
        sm = new SeatManager(4,4);

        sm.bookSeat(new Person(17),1,3);
        sm.bookSeat(new Person(30),1,4);
        sm.bookSeat(new Person(60),1,5);

        sm.bookSeat(new Person(20),3,3);
        sm.bookSeat(new Person(40),3,4);
        sm.bookSeat(new Person(50),3,5);

        sm.changeRows(1,4);
        assertNull(sm.getSeat(1,3));
        assertNull(sm.getSeat(1,4));
        assertNull(sm.getSeat(1,5));

        assertEquals(17,sm.getSeat(4,3).getAge());
        assertEquals(30,sm.getSeat(4,4).getAge());
        assertEquals(60,sm.getSeat(4,5).getAge());
    }

    @Test
    public void TestListOfFreeSeats()
    {
        //Caso 1: Matriz con personas
        SeatManager sm = new SeatManager(4,4);
        sm.bookSeat(new Person(17),1,3);
        sm.bookSeat(new Person(30),1,4);
        sm.bookSeat(new Person(60),1,5);

        sm.bookSeat(new Person(20),3,3);
        sm.bookSeat(new Person(40),3,4);
        sm.bookSeat(new Person(50),3,5);
        ArrayList<Position> a = sm.listOfFreeSeats(sm.getSeats());
        int contador=0;
        for (int i=0;i<sm.getSeats().length;i++){
            for (int j=0;j<sm.getSeats()[i].length;j++){
                contador++;
            }
        }
        assertEquals(contador-6,a.size());

        //Caso 2: Matriz dada por parametro vacia
        sm = new SeatManager(4,4);

        a = sm.listOfFreeSeats(sm.getSeats());
        contador=0;
        for (int i=0;i<sm.getSeats().length;i++){
            for (int j=0;j<sm.getSeats()[i].length;j++){
                contador++;
            }
        }
        assertEquals(contador,a.size());
        
        //Caso 3: Parametro igual a null
        sm = new SeatManager();
        try 
        {
            sm.listOfFreeSeats(null);
            fail();
        }
        catch (Exception ex)
        {
            assertEquals("Parametros incorrectos", ex.getMessage());
        }
    }
}
