import java.util.*;
/**
 * Clase puntal del avion que contiene atributo desplegado y las dos ruedas
 * corresponde a la sesion 7
 * 
 * @author (Antonio Paya Gonzalez) 
 * @version (28/10/2015)
 */
public class WheelStrut
{
    //Constantes
    public static final double BOEING_737_PRESSURE = 1739.0;
    public static final boolean IS_DEPLOYED = true;

    // Atributos
    private boolean deployed;  //True si esta el puntal desplegado
    //     private Wheel leftWheel;   //Rueda izquierda del puntal
    //     private Wheel rightWheel;  //Rueda derecha del puntal
    //private ArrayList<Wheel> wheelList; //Lista que almacena las ruedas
    private Wheel[] wheelList;

    /**
     * Constructor con un parametro 
     * Puental desplegado y ruedas con presion maxima y actual las del BOEING-737
     * 
     * @param numberOfWheels numero de ruedas del puntal , de tipo entero
     */
    public WheelStrut(int numberOfWheels)
    {
        setDeployed(IS_DEPLOYED);
        setWheelList(numberOfWheels);
        //leftWheel = new Wheel(BOEING_737_PRESSURE,BOEING_737_PRESSURE);
        //setLeftWheel(new Wheel(BOEING_737_PRESSURE,BOEING_737_PRESSURE));
        //rightWheel = new Wheel(BOEING_737_PRESSURE,BOEING_737_PRESSURE);
        //setRightWheel(new Wheel(BOEING_737_PRESSURE,BOEING_737_PRESSURE));
    }

    /**
     * Constructor con parametros (ruedas del puntal) el resto seria igual
     * que el constructor sin parametros.
     * Si alguna rueda no es correcta dejara la estandar
     */
    public WheelStrut(Wheel left,Wheel right)
    {
        //this();
        //setLeftWheel(left);
        //setRightWheel(right);
    }

    /**
     * Crea la lista con tantas ruedas como indique el parametro
     * Las ruedas con presion del BOEING 737
     *
     * @param  numero de ruedas
     */
    public void setWheelList(int numberOfWheels)
    {
        if (numberOfWheels > 0){
            //wheelList = new ArrayList<Wheel>();
            wheelList = new Wheel[numberOfWheels];
            for (int i = 0; i < numberOfWheels; i++){
                //wheelList.add(new Wheel(BOEING_737_PRESSURE,BOEING_737_PRESSURE));
                wheelList[i]=new Wheel(BOEING_737_PRESSURE,BOEING_737_PRESSURE);
            }
        }
        else {
            throw new RuntimeException("Dimension negativa o 0");
        }
    }

    /**
     *  Modifica el valor del atributo deployed
     * 
     * @param  nuevo valor para deployed , true si esta desplegado , boolean
     */
    private void setDeployed(boolean newDeployed)
    {
        deployed = newDeployed;
    }

    /**
     * Devuelve el valor del atributo deployed
     * 
     * @return  devuelve el valor deployed , true si esta desplegado , boolean
     */
    public boolean isDeployed()
    {
        return deployed;
    }

    /** Metodo que prueba el puntal 
     * devuelve true si sus ruedas tienen la presion adecuada (presion por encima del umbral)
     * 
     * @return true si sus ruedas tienen la presion adecuada
     */
    public boolean test()
    {
        for (int i = 0; i < wheelList.length ; i++){
            if (wheelList[i].test()==false){
                return false;
            }
        }
        return true;
    }

    /** Metodo print que imprime con el siguiente formato
     * Ejemplo
     * 
     * RETRACTED (O DEPLOYED)
     * Test.....OK(O FAIL)
     * 
     * Rueda 1
     * Presion maxima ........XX Mb
     * Presion actual ........YY Mb
     * Test.......... ........OK (O FAIL)
     * 
     * Rueda 2
     * Presion maxima ........XX Mb
     * Presion actual ........YY Mb
     * Test.......... ........OK (O FAIL)
     */
    public void print()
    {
        if (isDeployed()){
            System.out.println("DEPLOYED");
        }
        else{
            System.out.println("RETRACTED");
        }

        if (test()){
            System.out.println("Test.....OK");
        }
        else{
            System.out.println("Test.....FAIL");
        }
        System.out.println();
        int i=0;
        for (Wheel wheel:wheelList){
            System.out.println("Rueda"+i);
            i++;
            wheel.print();
        }
    }

    /**
     * Metodo que repliegue el puntal
     */
    public void retract()
    {
        setDeployed(! IS_DEPLOYED);
    }

    /**
     * Metodo que despliegue el puntal
     */
    public void deploy()
    {
        setDeployed(IS_DEPLOYED);
    }
    
    /**
     * Metodo que devuelve el numero de elementos que tiene la lista
     * @return numero de elementos de la lista
     */
    public int size()
    {
        return wheelList.length;
    }
    
    /**
     * Metodo que devuelve la rueda pasada por parametro
     * @return devuelve la rueda que esta en la posicion recibida como parametro
     * @param int position, posicion en la lista
     */
    public Wheel getWheel(int position)
    {
        if(position >= 0 && position < wheelList.length){
            return wheelList[position];
        }
        return null;
    }
}
