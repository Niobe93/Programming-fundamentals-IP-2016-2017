import java.util.ArrayList;
/**
 * Realiza la simulacion de un conjunto de aviones colocandolos en el radar y permitiendo su vuelo
 * 
 * @author (Antonio Paya Gonzalez) 
 * @version (9/12/2015)
 */
public class FlySimulator
{
    // Atributos
    private ArrayList<Plane> planes; //Lista de aviones que se simulan
    private char[][] radar;

    /**
     * Constructor de la clase FlySimulator
     * Crea una lista vacia y un radar, con todos sus elementos a '~'
     */
    public FlySimulator()
    {
        planes = new ArrayList<Plane> ();
        radar = new char[Plane.MAX_X+1][Plane.MAX_Y+1];
        for (int i=0; i<radar.length;i++){
            for (int j=0; j<radar[i].length;j++){
                radar[i][j]= '~';
            }
        }
    }

    //Sets y gets
    
    /**
     * Metodo que modifica el valor del atributo planes
     *
     * @param planes nuevo valor para el atributo planes
     */
    private void setPlanes(ArrayList<Plane> planes)
    {
        if ( planes != null){
            this.planes = planes;
        }
    }
    
    /**
     * Metodo que devuelve el valor del atributo planes
     *
     * @param planes valor para el atributo planes
     */
    public ArrayList<Plane> getPlanes()
    {
        return planes;
    }
    
    /**
     * Metodo que modifica el valor del atributo radar
     *
     * @param radar nuevo valor para el atributo radar
     */
    private void setRadar(char[][] radar)
    {
        if (radar != null){
            this.radar = radar;
        }
    }
    
    /**
     * Metodo que devuelve el valor del atributo radar
     *
     * @param radar valor para el atributo radar
     */
    public char[][] getRadar()
    {
        return radar;
    }
    
    //Otros metodos
    
    /**
     * Metodo que a�ade un avion al simulador y lo coloca en el radar
     * @param plane, de tipo Plane
     * @return true si se pudo meter el avion
     */
    public boolean addPlane(Plane plane)
    {
        if ( plane != null){
            if ( radar[plane.getXPos()][plane.getYPos()] == '~' && !existOtherIdentPlane(plane) ){
                planes.add(plane);
                radar[plane.getXPos()][plane.getYPos()] = plane.getIdentifier();
                return true;
            }
            else{
                return false;
            }
        }
        else{
            throw new RuntimeException("Parametros incorrectos");
        }
    }

    /**
     * Metodo  que comprueba que no exista otro avion con el mismo identificador
     */
    private boolean existOtherIdentPlane(Plane plane)
    {
        for (int i=0; i<radar.length;i++){
            for (int j=0; j<radar[i].length;j++){
                if (radar[i][j]== plane.getIdentifier()){
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Metodo  devuelve el valor de una posicion del radar
     * @param , row , de tipo int
     * @param , colum , de tipo int
     * @return devuelve la lista de aviones
     */
    public char getIdentifier(int row,int colum)
    {
        if(row >=0 && row < radar.length && colum >=0 && colum <radar[row].length){
            return radar[row][colum];
        }
        else{
            throw new RuntimeException("Parametros incorrectos");
        }
    }
    
    /**
     * Metodo que spinta el radar por consola
     */
    public void paintRadar()
    {
        for ( int i = 0; i < radar.length; i++ ){
            for ( int j = 0; j < radar[i].length; j++ ){
                System.out.print(radar[i][j] + " ");
            }
            System.out.println();
        }
    }
    
    
    /**
     * Metodo que simula el vuelo de todos los aviones
     */
    public void simulate()
    {
        for ( Plane plane : planes ){
            int initialXPos = plane.getXPos();
            int initialYPos = plane.getYPos();
            if ( plane.fly() ){
                radar[initialXPos][initialYPos] = '~';
                if ( radar[plane.getXPos()][plane.getYPos()] == '~'){
                    radar[plane.getXPos()][plane.getYPos()] = plane.getIdentifier();
                }
                else{
                    radar[plane.getXPos()][plane.getYPos()] = '%';
                }
            }
        }
        paintRadar();
    }
}
