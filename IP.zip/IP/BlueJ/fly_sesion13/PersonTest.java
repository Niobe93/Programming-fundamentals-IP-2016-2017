

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class PersonTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class PersonTest
{
    /**
     * Default constructor for test class PersonTest
     */
    public PersonTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }
    
    
    @Test
    public void testSetAge()
    {
        Person person1 = new Person();
        
        //Pruebas positivas
        //Caso 1 : edad dento de los límites
        
        person1.setAge(20);
        assertEquals(20, person1.getAge());
        
        person1.setAge(Person.MIN_AGE);
        assertEquals(Person.MIN_AGE, person1.getAge());
        
        //Pruebas negativas
        //Caso 2 : edad fuera de los límites
        
        person1.setAge(-1);
        assertEquals(Person.MIN_AGE, person1.getAge());
        
        person1.setAge(300);
        assertEquals(Person.MIN_AGE, person1.getAge());
        
        person1.setAge(Person.MAX_AGE);
        assertEquals(Person.MIN_AGE, person1.getAge());
    }
    
    @Test
    public void testGetCriticalAge()
    {
        Person person1 = new Person();
        //Pruebas positivas
            //Caso 1: menor de edad
        person1.setAge(2);
        assertEquals("Es menor de edad y le quedan " + (Person.ADULTHOOD_AGE - person1.getAge()) + " años para ser mayor de edad", person1.getCriticalAge());
            //Caso 2: 18 años
        person1.setAge(18);
        assertEquals("acaba de ser mayor de edad", person1.getCriticalAge());
            //Caso 3: Entre 18 y 65 años
        person1.setAge(45);
        assertEquals("es un adulto al que le quedan " + (Person.RETIREMENT_AGE - person1.getAge()) + " años para jubilarse" , person1.getCriticalAge());    
            //Caso 4: 65 años
         person1.setAge(65);
        assertEquals("acaba de jubilarse", person1.getCriticalAge());    
            //Caso 5: mayor de 65 años
         person1.setAge(85);
        assertEquals("Lleva jubilado " + (person1.getAge() - Person.RETIREMENT_AGE)+ " años", person1.getCriticalAge());
        
    }
    
    @Test
    public void testGetHashCode()
    {
        Person person1 = new Person();
        String nombre = new String(person1.getName());
        String apellido = new String(person1.getSurname1());
        assertEquals(person1.getAge() + "-" + person1.getName().toUpperCase() + "-" + nombre.length() + "-" + person1.getSurname1().toUpperCase() + "-" + apellido.length() , person1.getHashCode());
        
    }

    /**
     * Método que comprueba el método changeMyAge , dando valores tanto en los límites como dentro del conjunto de valores aceptados
     */
    @Test
    public void testChangeMyAge()
    {
        Person person1 = new Person();
        
        
        
        //Pruebas positivas
        
        //edad nueva mayor que la anterior
        person1.setAge(18);
        assertEquals("HE INCREMENTADO LA EDAD 2 AÑOS", person1.changeMyAge(1995));
        //edad nueva menor que la anterior
        person1.setAge(18);
        assertEquals("HE REDUCIDO LA EDAD 2 AÑOS", person1.changeMyAge(1999));
        //edad nueva igual que la anterior
        person1.setAge(18);
        assertEquals("MANTENGO LA EDAD", person1.changeMyAge(1997));
        //edad nueva en el límite superior
        person1.setAge(18);
        assertEquals("HE INCREMENTADO LA EDAD 5 AÑOS", person1.changeMyAge(1992));
         //edad nueva en el límite inferior
        person1.setAge(18);
        assertEquals("HE REDUCIDO LA EDAD 5 AÑOS", person1.changeMyAge(2002));
        
        
        //Pruebas negativas
        
        
        //edad nueva mayor que 5 años arriba
        person1.setAge(18);
        assertEquals("NO ES POSIBLE CAMBIAR LA EDAD", person1.changeMyAge(1990));
        //edad nueva mayor que 5 años debajo
        person1.setAge(18);
        assertEquals("NO ES POSIBLE CAMBIAR LA EDAD", person1.changeMyAge(2005));
        
        
    }
}


