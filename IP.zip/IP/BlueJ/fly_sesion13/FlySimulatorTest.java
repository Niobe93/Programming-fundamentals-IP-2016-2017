

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class FlySimulatorTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class FlySimulatorTest
{
    /**
     * Test para el constructor sin par�metros
     */
    @Test
    public void testConstructor()
    {
        FlySimulator flySimulator1 = new FlySimulator();
        
        for ( int i = 0; i < flySimulator1.getRadar().length; i++ ){
            for ( int j = 0; j < flySimulator1.getRadar()[i].length; j++ ){
                assertEquals('~', flySimulator1.getIdentifier(i, j));
            }
        }
    }
    
    /**
     * Prueba el metodo addPlane
     */
    @Test
    public void TestAddPlane()
    {
        FlySimulator flySimulator1 = new FlySimulator();
        
        //Caso 1 a�adir avi�n no existente en una posici�n vac�a
        Plane plane1 = new Plane(new Person(), 'Z', 200, 0, 0, 1, 1);
        assertTrue(flySimulator1.addPlane(plane1));
        assertEquals(1, flySimulator1.getPlanes().size());
        assertEquals('Z', flySimulator1.getIdentifier(0, 0));
        
        //Caso 2 a�adir avi�n existente
        plane1 = new Plane(new Person(), 'Z', 200, 1, 1, 1, 1);
        assertFalse(flySimulator1.addPlane(plane1));
        assertEquals(1, flySimulator1.getPlanes().size());
        assertEquals('Z', flySimulator1.getIdentifier(0, 0));
        assertEquals('~', flySimulator1.getIdentifier(1, 1));
        
        //Caso 3 a�adir avi�n no existente en posici�n ocupada
        plane1 = new Plane(new Person(), 'A', 200, 0, 0, 1, 1);
        assertFalse(flySimulator1.addPlane(plane1));
        assertEquals(1, flySimulator1.getPlanes().size());
        assertEquals('Z', flySimulator1.getIdentifier(0, 0));
        assertEquals('~', flySimulator1.getIdentifier(1, 1));
        
        //Caso 4 par�metros incorrectos
        try
        {
            flySimulator1.addPlane(null);
            fail();
        }
        catch ( RuntimeException exception )
        {
            assertEquals("Parametros incorrectos", exception.getMessage());
        }
    }
    
    /**
     * Prueba el metodo simulate
     */
    @Test
    public void TestSimulate()
    {
        FlySimulator flySimulator1 = new FlySimulator();
        flySimulator1.addPlane(new Plane(new Person(), 'A', 50, 0, 0, 1, 1));
        flySimulator1.addPlane(new Plane(new Person(), 'B', 50, 10, 0, -1, 1));
        flySimulator1.addPlane(new Plane(new Person(), 'C', 50, 0, 10, 1, -1));
        flySimulator1.addPlane(new Plane(new Person(), 'D', 50, 10, 10, -1, -1));
        
        for ( int i = 1; i <= 5; i++ )
        {
            System.out.println(" ... Simulaci�n" + i + "...");
            flySimulator1.simulate();
        }
    }
    
}
