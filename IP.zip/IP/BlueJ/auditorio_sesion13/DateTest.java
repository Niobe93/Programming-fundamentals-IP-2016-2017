

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class DateTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class DateTest
{
    /**
     * Test del constructor de la clase Date
     */
    @Test
    public void TestDate()
    {
        //Caso 1:Todo correcto
        Date date = new Date(12,10,2012);
        assertEquals(12,date.getDay());
        assertEquals(10,date.getMes());
        assertEquals(2012,date.getYear());
        //Caso 2:31 dias en mes que no tiene 31 dias
        date = new Date(31,2,2015);
        assertEquals(0,date.getDay());
        assertEquals(2,date.getMes());
        assertEquals(2015,date.getYear());
        //Caso 3:mes mayor de 12
        date = new Date(1,13,2015);
        assertEquals(1,date.getDay());
        assertEquals(0,date.getMes());
        assertEquals(2015,date.getYear());
        //Caso 4:year negativo
        date = new Date(1,11,-2015);
        assertEquals(1,date.getDay());
        assertEquals(11,date.getMes());
        assertEquals(0,date.getYear());
        //Caso 5:year bisiesto y dia 29 de febrero
        date = new Date(29,2,2016);
        assertEquals(29,date.getDay());
        assertEquals(2,date.getMes());
        assertEquals(2016,date.getYear());
        //Caso 6:year no bisiesto y dia 29 de febrero
        date = new Date(29,2,2015);
        assertEquals(0,date.getDay());
        assertEquals(2,date.getMes());
        assertEquals(2015,date.getYear());
        //Caso 7:dia 31 en mes que tiene 31 dias
        date = new Date(31,1,2015);
        assertEquals(31,date.getDay());
        assertEquals(1,date.getMes());
        assertEquals(2015,date.getYear());
        //Caso 8:dia negatvo
        date = new Date(-31,1,2015);
        assertEquals(0,date.getDay());
        assertEquals(1,date.getMes());
        assertEquals(2015,date.getYear());
        //Caso 9:mes negatvo
        date = new Date(31,-1,2015);
        assertEquals(0,date.getDay());
        assertEquals(0,date.getMes());
        assertEquals(2015,date.getYear());
    }
}
