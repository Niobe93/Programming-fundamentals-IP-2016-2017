

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class ConcertTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class ConcertTest
{
    /**
     * Default constructor for test class ConcertTest
     */
    @Test
    public void TestConstructor()
    {
        //Caso 1: Todo correcto
        Concert conci = new Concert("Conci",20.0,new Date(30,1,2015));
        assertEquals("Conci",conci.getName());
        assertEquals(20.0,conci.getPrice(),0.1);
        assertEquals(30,conci.getDate().getDay());
        assertEquals(1,conci.getDate().getMes());
        assertEquals(2015,conci.getDate().getYear());
        //Caso 2: Precio menor que 0
        conci = new Concert("Conci",-20.0,new Date(30,1,2015));
        assertEquals("Conci",conci.getName());
        assertEquals(0.0,conci.getPrice(),0.1);
        assertEquals(0.0,conci.getPriceVip(),0.1);
        assertEquals(30,conci.getDate().getDay());
        assertEquals(1,conci.getDate().getMes());
        assertEquals(2015,conci.getDate().getYear());
        //Caso 3: Fecha incorrecta
        conci = new Concert("Conci",20.0,new Date(30,2,2015));
        assertEquals("Conci",conci.getName());
        assertEquals(20.0,conci.getPrice(),0.1);
        assertEquals(0,conci.getDate().getDay());
        assertEquals(2,conci.getDate().getMes());
        assertEquals(2015,conci.getDate().getYear());
        //Caso 4: Nombre incorrecto
        conci = new Concert("",20.0,new Date(30,1,2015));
        assertEquals(null,conci.getName());
        assertEquals(20.0,conci.getPrice(),0.1);
        assertEquals(30,conci.getDate().getDay());
        assertEquals(1,conci.getDate().getMes());
        assertEquals(2015,conci.getDate().getYear());
    }
}
