import java.util.*;
/**
 * Clase Auditorium del proyecto Auditorio.
 * 
 * @author (Antonio Paya Gonzalez) 
 * @version (22/11/2015)
 */
public class Auditorium
{
    // Atributos
    private ArrayList <Concert> concerts;

    /**
     * Constructor de la clase Auditorium
     */
    public Auditorium()
    {
        concerts = new ArrayList<Concert>();
    }

    /**
     * Metodo que busca un concierto en la lista por el nombre, devuelve el
     * concierto si existe o null en caso contrario
     * 
     * @param  String concertName
     * @return  devuelve el concierto 
     */
    public Concert seekConcert(String concertName)
    {
        Iterator<Concert> iterador = concerts.iterator();
        while (iterador.hasNext()){
            Concert concierto = iterador.next();
            if (concierto.getName() == concertName){
                return concierto;
            }
        }
        return null;
    }

    /**
     * Metodo aniade un concierto siempre que no haya otro en la misma fecha y lo
     * incluye en la lista de conciertos del auditorio
     * 
     * @param  String concertName
     * @param  Date date
     * @param  double price
     */
    public void addConcert(String concertName,Date date,double price)
    {
        Iterator<Concert> iterador = concerts.iterator();
        boolean temp = false;
        while (iterador.hasNext()){
            Concert concierto = iterador.next();
            if (concierto.getDate().getDay()== date.getDay() && concierto.getDate().getMes()== date.getMes() && concierto.getDate().getYear()== date.getYear()){
                temp = true; 
            } 
        }
        if (temp == false ){
            concerts.add(new Concert(concertName,price,date));
        }

    }

    /**
     * Metodo que borra todos los conciertos de la lista que se hayan celebrado en
     * el year metido por parametro
     * 
     * @param  int year
     */
    public void removeConcerts(int year)
    {
        Iterator<Concert> iterador = concerts.iterator();
        while (iterador.hasNext()){
            Concert concierto = iterador.next();
            if (concierto.getDate().getYear() == year){
                iterador.remove();
            }
        }
    }
}
