
/**
 * Clase Date del proyecto Auditorio
 * 
 * @author (Antonio Paya Gonzalez) 
 * @version (22/11/215)
 */
public class Date
{
    // Atributos
    private int day;
    private int month;
    private int year;

    /**
     * Constructor de la clase Date con tres parametros: dia,mes y year
     * 
     * @param dia,tipo int
     * @param mes,tipo int
     * @param year,tipo int
     */
    public Date(int dia,int mes,int year)
    {
        setYear(year);
        setMes(mes);
        setDay(dia);
    }

    //Metodos set

    /**
     * Metodo que modifica el valor del atributo day
     * 
     * @param  dia,tipo int
     */
    private void setDay(int dia)
    {
        if (dia>=1 && getMes()%2==0 && dia<=30 && getMes()!=2){
            day = dia;
        }
        else if(dia>=1 && getMes()==2){
            if (getYear()%4==0 || (getYear()%100==0 && getYear()%400==0 )&& dia<=29){
                day = dia;
            }
            else if (dia<=28){
                day = dia;
            }
        }
        else if(dia>=1 && getMes()%2!=0 && dia<=31){
            day = dia;
        }
        else{
            day = 0;
        }
    }

    /**
     * Metodo que modifica el valor del atributo month
     * 
     * @param  mes,tipo int
     */
    private void setMes(int mes)
    {
        if (mes>=1 && mes<=12){
            month = mes;
        }
    }

    /**
     * Metodo que modifica el valor del atributo year
     * 
     * @param  newYear,tipo int
     */
    private void setYear(int newYear)
    {
        if (newYear>=0){
            year = newYear;
        }
    }

    //Metodos get

    /**
     * Metodo que devuelve el valor del atributo day
     * 
     * @return  devuelve el valor del atributo day
     */
    public int getDay()
    {
        return day;
    }
    
    /**
     * Metodo que devuelve el valor del atributo month
     * 
     * @return  devuelve el valor del atributo month
     */
    public int getMes()
    {
        return month;
    }
    
    /**
     * Metodo que devuelve el valor del atributo year
     * 
     * @return  devuelve el valor del atributo year
     */
    public int getYear()
    {
        return year;
    }
}
