
/**
 * Clase Concert del proyecto Auditorio
 * 
 * @author (Antonio Paya Gonzalez) 
 * @version (22/11/2015)
 */
public class Concert
{
    // Atributos
    private String name;
    private double price;
    private double priceVip;
    private Date date;

    /**
     * Constructor de la clase Concert
     */
    public Concert(String nombre,double price,Date fecha)
    {
       setName(nombre);
       setPrice(price);
       setDate(fecha);
    }

    //Metodos set
    
    /**
     * Metodo que modifica el atributo name
     * 
     * @param  nombre,tipo String
     */
    private void setName(String nombre)
    {
        if (nombre != null && nombre != ""){
            name = nombre;
        }
    }
    
    /**
     * Metodo que modifica el atributo price
     * 
     * @param  precio,tipo double
     */
    private void setPrice(double newPrice)
    {
        if (newPrice >= 0){
            price = newPrice;
        }
    }
    
    /**
     * Metodo que modifica el atributo date
     * 
     * @param  fecha,tipo Date
     */
    private void setDate(Date fecha)
    {
        if (fecha != null){
            date = fecha;
        }
    }
    
    //Metodos get
    
    /**
     * Metodo devuelve el valor el atributo name
     * 
     * @return devuelve el valor del atributo name
     */
    public String getName()
    {
        return name;
    }
    
    /**
     * Metodo devuelve el valor el atributo price
     * 
     * @return devuelve el valor del atributo price
     */
    public double getPrice()
    {
        return price;
    }
    
    /**
     * Metodo devuelve el valor el atributo date
     * 
     * @return devuelve el valor del atributo date
     */
    public Date getDate()
    {
        return date;
    }
    
    /**
     * Metodo devuelve el valor el atributo priceVip
     * 
     * @return devuelve el valor del atributo priceVip
     */
    public double getPriceVip()
    {
        return price*2;
    }
}
