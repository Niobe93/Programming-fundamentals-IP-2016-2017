

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class AuditoriumTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class AuditoriumTest
{
    /**
     * Metodo que prueba el metodo seekConcert de la clase Auditorium
     */
    @Test
    public void TestSeekConcert()
    {
        Auditorium audi = new Auditorium();
        
        //Todo correcto
        audi.addConcert("Conci",new Date(23,1,2015),20.0);
        assertEquals("Conci",audi.seekConcert("Conci").getName());
        //Nombre introducido no existe
        audi = new Auditorium();
        audi.addConcert("Conci",new Date(23,1,2015),20.0);
        assertNull(audi.seekConcert("Hola"));
    }
    
    /**
     * Metodo que prueba el metodo addConcert
     */
    @Test 
    public void TestAdd()
    {
        Auditorium audi = new Auditorium();
        //Todo correcto
        audi.addConcert("Conci",new Date(23,1,2015),20.0);
        audi.addConcert("Conci2",new Date(24,1,2015),20.0);
        audi.addConcert("Conci3",new Date(25,1,2014),20.0);
        assertNotNull(audi.seekConcert("Conci"));
        assertNotNull(audi.seekConcert("Conci2"));
        assertNotNull(audi.seekConcert("Conci3"));
        //Concierto en la misma fecha
        audi = new Auditorium();
        audi.addConcert("Conci",new Date(23,1,2015),20.0);
        audi.addConcert("Conci2",new Date(23,1,2015),20.0);
        audi.addConcert("Conci3",new Date(25,1,2014),20.0);
        assertNotNull(audi.seekConcert("Conci"));
        assertNull(audi.seekConcert("Conci2"));
        assertNotNull(audi.seekConcert("Conci3"));
        //Precio negativo
        audi = new Auditorium();
        audi.addConcert("Conci",new Date(23,1,2015),-20.0);
        audi.addConcert("Conci2",new Date(24,1,2015),20.0);
        audi.addConcert("Conci3",new Date(25,1,2014),20.0);
        assertNotNull(audi.seekConcert("Conci"));
        assertEquals(0.0,audi.seekConcert("Conci").getPrice(),0.1);
        assertNotNull(audi.seekConcert("Conci2"));
        assertNotNull(audi.seekConcert("Conci3"));
        //Nombre incorrecto
        audi = new Auditorium();
        audi.addConcert("",new Date(23,1,2015),20.0);
        audi.addConcert("Conci2",new Date(24,1,2015),20.0);
        audi.addConcert("Conci3",new Date(25,1,2014),20.0);
        assertNull(audi.seekConcert(""));
        assertNotNull(audi.seekConcert("Conci2"));
        assertNotNull(audi.seekConcert("Conci3"));
        
    }
    
    /**
     * Metodo que prueba el metodo removeConcerts de la clase Auditorium
     */
    @Test
    public void TestRemoveConcerts()
    {
        Auditorium audi = new Auditorium();
        
        //Todo correcto
        audi.addConcert("Conci",new Date(23,1,2015),20.0);
        audi.addConcert("Conci2",new Date(24,1,2015),20.0);
        audi.addConcert("Conci3",new Date(25,1,2014),20.0);
        audi.removeConcerts(2015);
        assertNull(audi.seekConcert("Conci"));
        assertNull(audi.seekConcert("Conci2"));
        assertNotNull(audi.seekConcert("Conci3"));
        
        
    }
}
