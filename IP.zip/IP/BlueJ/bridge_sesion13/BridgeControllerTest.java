

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class BridgeControllerTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class BridgeControllerTest
{
    /**
     * Test del constructor sin parametros de la clase BridgeController
     */
    @Test
    public void TestBridgeController()
    {
        BridgeController control = new BridgeController();
        
        assertEquals(control.MIN_LEVER,control.getLever());
        assertEquals(false,control.getClutch());
    }
    
    /**
     * Test del constructor cont parametros de la clase BridgeController
     */
    @Test
    public void TestBridgeControllerWithParameters()
    {
        //Pruebas positivas
        BridgeController control = new BridgeController(2);
        assertEquals(control.MAX_LEVER,control.getLever());
        assertEquals(false,control.getClutch());
        
        BridgeController control1 = new BridgeController(1);
        assertEquals(control.MED_LEVER,control1.getLever());
        assertEquals(false,control1.getClutch());
        
        BridgeController control2 = new BridgeController(0);
        assertEquals(control.MIN_LEVER,control2.getLever());
        assertEquals(false,control2.getClutch());
        
        //Pruebas negativas
        BridgeController control3 = new BridgeController(-1);
        assertEquals(control.MIN_LEVER,control3.getLever());
        assertEquals(false,control3.getClutch());
        
        BridgeController control4 = new BridgeController(3);
        assertEquals(control.MIN_LEVER,control4.getLever());
        assertEquals(false,control4.getClutch());
    }
    
    /**
     * Test del metodo changeClutch
     */
    @Test
    public void TestChangeClutch()
    {
        //Caso 1: False a True
        BridgeController control = new BridgeController();
        control.changeClutch();
        assertEquals(true,control.getClutch());
        //Caso 2: True a False
        control.changeClutch();
        assertEquals(false,control.getClutch());
    }
    
    /**
     * Test del metodo changeLever
     */
    @Test
    public void TestChangeLever()
    {
       //Caso 1: Posicion 0
        BridgeController control = new BridgeController();
        control.changeLever(0);
        assertEquals(0,control.getLever());
        assertEquals(0,control.getLevadizo().getSlope());
    }
}
