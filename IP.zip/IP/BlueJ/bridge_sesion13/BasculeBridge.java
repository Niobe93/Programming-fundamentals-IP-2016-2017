
/**
 * Clase Bascule Bidge (puente levadizo) en la que se desea controlar un puente levadizo
 * de manera que pueda subir y bajar para colocarse en tres posiciones diferentes.
 * 
 * @author (Antonio Paya Gonzalez) 
 * @version (3/11/2015)
 */
public class BasculeBridge
{
    //Constantes de la clase BasculeBridge
    public static final int MAX_SLOPE = 60;
    public static final int MIN_SLOPE = 0;
    public static final int MED_SLOPE = 30;
    
    public static final int MIN_CANT_POS = 0; //Minimo de cantidad que se puede aumentar o disminuir a la posicion del puente
    
    // Atributos de la clase BasculeBridge
    private int slope;      //Grados de la pendiente del puente

    /**
     * Constructor de la clase BasculeBridge sin parametros
     */
    public BasculeBridge()
    {
        setSlope(MIN_SLOPE);
    }
    
    /**
     * Constructor de la clase BasculeBridge con parametros
     * 
     * @param pendiente , nuevo valor para la pendiente del puente
     */
    public BasculeBridge(int pendiente)
    {
        setSlope(pendiente);
    }

    //Metodos set
    
    /**
     * Metodo que modifica el valor del atributo slope
     * 
     * @param  pendiente, nuevo valor para la pendiente del puente
     */
    private void setSlope(int pendiente)
    {
        if (pendiente >= MIN_SLOPE && pendiente <= MAX_SLOPE){
            slope = pendiente;
        }
    }
    
    //Metodos get
    
    /**
     * Metodo que devuelve el valor del atributo slope
     * 
     * @return  devuelve el valor de la pendiente del puente
     */
    public int getSlope()
    {
        return slope;
    }
    
    //Otros metodos
    
    /**
     * Metodo que modifica la posicion del puente , incrementandola en la cantidad
     * que recibe como parametro. Solo podra recibir valores positivos
     * 
     * @param  masPos, de tipo int
     */
    public void raiseBridge(int masPos)
    {
        if (masPos >= MIN_CANT_POS){
            setSlope(slope+masPos);
        }
    }
    
    /**
     * Metodo que modifica la posicion del puente , decrementandola en la cantidad
     * que recibe como parametro. Solo podra recibir valores positivos
     * 
     * @param  menosPos, de tipo int
     */
    public void dropBridge(int menosPos)
    {
        if (menosPos >= MIN_CANT_POS){
            setSlope(slope-menosPos);
        }
    }
}
