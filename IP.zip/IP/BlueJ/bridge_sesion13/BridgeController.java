
/**
 * Clase BridgeController (Controlador del puente)
 * 
 * @author (Antonio Paya Gonzalez) 
 * @version (3/11/2015)
 */
public class BridgeController
{
    //Constantes de la clase BridgeController
    public static final int MIN_LEVER = 0;
    public static final int MED_LEVER = 1;
    public static final int MAX_LEVER = 2;

    // Atributos de la clase BridgeController
    private int lever;
    private boolean clutch;
    private BasculeBridge levadizo;

    /**
     * Constructor sin parametros de la clase BridgeController
     */
    public BridgeController()
    {
        setLever(MIN_LEVER);
        setClutch(false);
        setLevadizo(levadizo);
    }

    /**
     * Constructor con parametros de la clase BridgeController
     * 
     * @param newLever , nuevo valor para la posicion de la palanca
     */
    public BridgeController(int newLever)
    {
        this();
        setLever(newLever);
    }

    //Metodos set

    /**
     * Metodo que modifica el valor de la posicion de la palanca
     * 
     * @param  newLever, de tipo int
     */
    private void setLever(int newLever)
    {
        if (newLever == MIN_LEVER){
            lever = newLever;
        }
        else if (newLever == MED_LEVER){
            lever = newLever;
        }
        else if (newLever == MAX_LEVER){
            lever = newLever;
        }
    }

    /**
     * Metodo que modifica el valor del atributo clutch
     * 
     * @param  newClutch, de tipo boolean
     */
    private void setClutch(boolean newClutch)
    {
        clutch = newClutch;
    }

    /**
     * Metodo que modifica el valor del atributo levadizo
     * 
     * @param  newPuente, de tipo BasculeBridge
     */
    private void setLevadizo(BasculeBridge newPuente)
    {
        if (newPuente != null){
            levadizo = newPuente;
        }
    }

    //Metodos get

    /**
     * Metodo que devuelve el valor del atributo lever
     * 
     * @return , devuelve el valor del atributo lever, de tipo int
     */
    public int getLever()
    {
        return lever;
    }

    /**
     * Metodo que devuelve el valor del atributo lever
     * 
     * @return , devuelve el valor del atributo lever, de tipo int
     */
    public boolean getClutch()
    {
        return clutch;
    }

    /**
     * Metodo que devuelve el valor del atributo levadizo
     * 
     * @return , tipo BasculeBridge
     */
    public BasculeBridge getLevadizo()
    {
        return levadizo;
    }

    //Otros metodos

    /**
     * Metodo que cambia la presion del embrague, si estaba presionado deja 
     * de estarlo y viceversa
     * 
     */
    public void changeClutch()
    {
        if (getClutch()==true){
            setClutch(false);
        }
        else{
            setClutch(true);
        }
    }

    /**
     * Metodo que recibe como parametro la nueva posicion de la palanca(1,2,0).
     * En caso de que el embrague este presionado comprueba si debe levantar
     * (raiseBridge) o bajar (dropBridge) el puente (dependiendo de la posicion 
     * actual y la nueva posicion) y calcula los grados que tiene que incrementar
     * para hacer que el puente modifique su inclinacion.
     * Si el embrague no esta presionado o la nueva posicion de la palanca no es 
     * correcta no modifica el valor de la palanca.
     * 
     * @param newLever, nueva posicion de la palanca de tipo int.
     * 
     */
    public void changeLever(int newLever)
    {
        if (newLever == MIN_LEVER){
            setLever(newLever);
            levadizo.dropBridge(levadizo.getSlope());
        }
        else if (newLever == MED_LEVER){
            setLever(newLever);
            if (levadizo.getSlope()<= levadizo.MED_SLOPE){
                levadizo.raiseBridge(levadizo.MED_SLOPE-levadizo.getSlope());
            }
            else{
                levadizo.dropBridge(levadizo.getSlope()-levadizo.MED_SLOPE);
            }
        }
        else if (newLever == MAX_LEVER){
            setLever(newLever);
            levadizo.raiseBridge(levadizo.MAX_SLOPE-levadizo.getSlope());
        }
    }
}

