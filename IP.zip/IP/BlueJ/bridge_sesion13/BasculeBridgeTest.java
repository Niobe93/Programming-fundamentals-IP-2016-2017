

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class BasculeBridgeTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class BasculeBridgeTest
{
    /**
     * Test del constructor sin parametros de la clase BasculeBridge
     */
    @Test
    public void TestBasculeBridge()
    {
        BasculeBridge puente = new BasculeBridge();
        
        assertEquals(puente.MIN_SLOPE,puente.getSlope());
    }
    
    /**
     * Test del constructor conn parametros de la clase BasculeBridge
     */
    @Test
    public void TestBasculeBridgeWithParameters()
    {
        BasculeBridge puente = new BasculeBridge(30);
        
        assertEquals(30,puente.getSlope());
    }
    
    /**
     * Test del metodo raiseBridge
     */
    @Test
    public void TestRaiseBridge()
    {
        BasculeBridge puente = new BasculeBridge(0);
        puente.raiseBridge(puente.MED_SLOPE);
        assertEquals(puente.MED_SLOPE,puente.getSlope());
    }
    
    /**
     * Test del metodo dropBridge
     */
    @Test
    public void TestDropBridge()
    {
        BasculeBridge puente = new BasculeBridge(60);
        puente.dropBridge(puente.MED_SLOPE);
        assertEquals(puente.MED_SLOPE,puente.getSlope());
    }
}
