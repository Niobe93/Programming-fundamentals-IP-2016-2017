
/**
 * Metodo que simula un panel de control. Contiene un boton  una bombilla
 * 
 * @author (Antonio Paya Gonzalez) 
 * @version (22/10/2015)
 */
public class ConrolPanel
{
    //Atributos
    Lamp lampara = new Lamp();
    Switch boton = new Switch();
    Potentiometer pot = new Potentiometer();
    Heater rad = new Heater();

    /**
     * Constructor sin parametros de la clase ControlPanel
     */
    public ConrolPanel()
    {
        //
    }

    /**
     * Metodo que muestra por pantalla el estado del panel
     */
    public void print()
    {
        System.out.println("=========== Estado del PANEL ============ ");
        System.out.println("Interuptor: "+ boton.toString());
        System.out.println("Bombilla: "+ lampara.toString());
        System.out.println("Potenciometro: "+ pot.toString());
        System.out.println("Radiador: "+ rad.toString());
    }

    /**
     * Metodo que camvia el estado de la lampara de on a off y viceversa
     */
    public void press()
    {
        boton.press();
        if (boton.getInterruptor() == boton.ON){
            lampara.turnOn();
        }
        else{
            lampara.turnOff();
        }
    }

    /**
     * Metodo que cambia la posicion del potenciometro y la temperatura del radiador
     * La temperatura la cambia en funcion de la
     * posicion del potenciometro: 10 ºC si el potenciometro esta a 0 (el
     * minimo posible en el radiador), 27ºC si el potenciometro esta a 10
     * (el máximo posible en el radiador).
     */
    public void  movePotentiometer(int newPos)
    {
        pot.movePosition(newPos);   
        double newTemp = 10+(newPos*1.7);
        rad.changeTemperature(newTemp);
    }
}
