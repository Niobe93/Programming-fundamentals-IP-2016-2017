

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class HeaterTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class HeaterTest
{
    @Test 
    public void testChangeTemperature()
    {
        Heater rad = new Heater();
        
        //Pruebas positivas
        rad.changeTemperature(22);
        assertEquals(22.0+" º C",rad.toString());
        rad.changeTemperature(10);
        assertEquals(10.0+" º C",rad.toString());
        rad.changeTemperature(27);
        assertEquals(27.0+" º C",rad.toString());
        
        //Pruebas negativas
        rad.changeTemperature(30);
        assertEquals(27.0+" º C",rad.toString());
        rad.changeTemperature(9);
        assertEquals(27.0+" º C",rad.toString());
    
    }
}
