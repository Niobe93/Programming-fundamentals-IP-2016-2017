
import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class ConrolPanelTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class ConrolPanelTest
{
    @Test
    public void testPress(){
        ConrolPanel panel = new ConrolPanel();
        Switch boton = new Switch();
        Lamp lamp1 = new Lamp();
        
        panel.press();
        if(boton.getInterruptor() == boton.ON){
            assertEquals("ENCENDIDA",lamp1.toString());
        }
        else{
            assertEquals("APAGADA",lamp1.toString());
        }
    }
    
    @Test
    public void testMovePotentiometer(){
        ConrolPanel panel = new ConrolPanel();
        Switch boton = new Switch();
        Lamp lamp1 = new Lamp();
        Potentiometer pot = new Potentiometer();
        Heater rad = new Heater();
        
        //Pruebas positivas
        panel.movePotentiometer(3);
        assertEquals(3+"",panel.pot.toString());
        assertEquals(15.1+" º C",panel.rad.toString());
        
        panel.movePotentiometer(0);
        assertEquals(0+"",panel.pot.toString());
        assertEquals(10.0+" º C",panel.rad.toString());
        
        panel.movePotentiometer(10);
        assertEquals(10+"",panel.pot.toString());
        assertEquals(27.0+" º C",panel.rad.toString());
        
        //Pruebas negativas
        panel.movePotentiometer(-10);
        assertEquals(10+"",panel.pot.toString());
        assertEquals(27.0+" º C",panel.rad.toString());
        
        panel.movePotentiometer(22);
        assertEquals(10+"",panel.pot.toString());
        assertEquals(27.0+" º C",panel.rad.toString());
        
    }
    
}