

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class LampTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class LampTest
{
    /**
     * Default constructor for test class LampTest
     */
    public LampTest()
    {
    }
    
    @Test
    public void TestTurnOn()
    {
        Lamp lamp1 = new Lamp();
        lamp1.turnOn();
        
        assertEquals("ENCENDIDA",lamp1.toString());
    }


    @Test
    public void TestTurnOff()
    {
        Lamp lamp1 = new Lamp();
        lamp1.turnOff();
        
        assertEquals("APAGADA",lamp1.toString());
    }
}

