
import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class SwitchTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class SwitchTest
{
    @Test
    public void TestPress(){
        Switch boton = new Switch();

        boton.press();
        if (boton.getInterruptor() == boton.ON){
            assertEquals("ON",boton.toString());

        }
        else{
            assertEquals("OFF",boton.toString());
        }

    }

    @Test
    public void TestToString(){
        Switch boton = new Switch();

        boton.press();
        if (boton.getInterruptor() == boton.OFF){
            assertEquals("OFF",boton.toString());
        }
        else{
            assertEquals("ON",boton.toString());
        }

    }
}
