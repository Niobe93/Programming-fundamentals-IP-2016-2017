
/**
 * Clase Heater que representa a un radiador  al que se le puede fijar
 * una temperatura entre 10 y 27 grados centígrados
 * 
 * @author (Antonio Paya Gonzalez) 
 * @version (26/10/2015)
 */
public class Heater
{
    //Constantes
    public static final double MAX_TEMP  = 27.0;
    public static final double MIN_TEMP  = 10.0;
    
    // Atributos
    private double temp;

    /**
     * Constructor de la clase Heater
     */
    public Heater()
    {
        temp = 20;
    }

    /**
     * Metodo changeTemperature que modifiqua el valor de la temperatura al valor recibido como parametro 
     * 
     * @param newTemp , nueva temperatura para la clase radiador
     */
    public void changeTemperature(double newTemp)
    {
        if(newTemp >= MIN_TEMP && newTemp <= MAX_TEMP){
        
            temp = newTemp;
        }
    }
    
    /**
     * Metodo que devuelve el valor del atributo temp 
     * 
     * @return devuelve el valor del atributo temp
     */
    public double getTemp()
    {
        return temp;
    }
    
    /**
     * Metodo que devuelve el valor de la temperatura como un String
     * 
     * @return devuelve el valor de la temperatura como un String
     */
    public String toString()
    {
        return getTemp() + " º C"; 
    }
}
