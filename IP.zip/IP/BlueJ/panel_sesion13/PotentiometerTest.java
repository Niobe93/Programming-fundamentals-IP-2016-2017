

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class PotentiometerTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class PotentiometerTest
{
    @Test
    public void TestMovePosition()
    {
        Potentiometer pot = new Potentiometer();
        
        //Pruebas positivas
        pot.movePosition(2);
        assertEquals(2+"", pot.toString());
        pot.movePosition(0);
        assertEquals(0+"", pot.toString());
        pot.movePosition(10);
        assertEquals(10+"", pot.toString());
        
        //Pruebas negativas
        pot.movePosition(-1);
        assertEquals(10+"", pot.toString());
        pot.movePosition(14);
        assertEquals(10+"", pot.toString());
    }
}
