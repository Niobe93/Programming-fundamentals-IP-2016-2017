
/**
 * Clse lamp que simula el funcionamiento de una bombilla. Tendra dos estados ON y OFF , dos 
 * metodos para encenderla y apagarla y un metodo que devuelve si esta encendida o apagada
 * 
 * @author (Antonio Paya Gonzalez) 
 * @version (22/10/2015)
 */
public class Lamp
{
    //constantes
    public static final boolean LAMP_ON = true;
    public static final boolean LAMP_OFF = false;
    // atributos
    private boolean estado;
    

    /**
     * Constructor de la clase lamp sin parametros
     */
    public Lamp()
    {
        setEstado(false);
    }
    
    /**
     * Metodo set del atributo estado
     * 
     * @param estado, de tipo boolean
     */
    private void setEstado(boolean estado)
    {
        this.estado = estado;
    }
    
    /**
     * Metodo get del atributo estado
     * 
     * @return devuelve el estado de la lampara , tipo boolean
     */
    public boolean getEstado()
    {
        return estado;
    }
    
    /**
     * Metodo que enciende la lampara
     */
    public void turnOn()
    {
        setEstado(LAMP_ON);
    }
    
    /**
     * Metodo que apaga la lampara
     */
    public void turnOff()
    {
        setEstado(LAMP_OFF);
    }
    
    /**
     * Metodo que devuelve un string que dice si la lampara esta encendida o apagada
     * 
     * @return devuelve un string que dice si esta encendida o apagada
     */
    public String toString()
    {
        if (getEstado() == LAMP_ON){
            return "ENCENDIDA";
        }
        else{
            return "APAGADA";
        }
    }
}
