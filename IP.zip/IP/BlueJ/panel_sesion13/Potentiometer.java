
/**
 * Clase Potentiometer ,  que representa un potenciometro al que se
 * puede colocar en una posición entre 0 y 10 
 * 
 * @author (Antonio Paya Gonzalez) 
 * @version (26/10/2015)
 */
public class Potentiometer
{
    //Constantes
    public static final int MAX_POS = 10;
    public static final int MIN_POS = 0;
   
    // Atributos
    private int pos;

    /**
     * Constructor de la clase Potentiometer
     */
    public Potentiometer()
    {
        pos = 5;
    }
    
    /**
     * Metodo movePosition que cambia el valor de la posicion el potenciometro a uno que se introduce por 
     * parametro
     * 
     * @param  newPos , nueva posicion para la clase potenciometro
     */
    public void movePosition(int newPos)
    {
        if (newPos <= MAX_POS && newPos >= MIN_POS){
            pos = newPos;
        }
    }
    
    /**
     * Metodo devuelve el valor del atributo pos
     * 
     * return  devuelve el valor del atributo pos
     */
    public int getPos()
    {
        return pos;
    }
    
    /**
     * Metodo que devuelve el valor de la posicion del potenciometro
     * 
     * @return  devuelve el valor de la posicion de tipo String
     */
    public String toString()
    {
        return getPos()+"";
    }
}
