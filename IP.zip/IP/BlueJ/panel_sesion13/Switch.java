
/**
 * Clase Switch
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Switch
{
    //Constantes
    public static final boolean ON = true;
    public static final boolean OFF = false;
    // Atributos
    private boolean interruptor;
    
    
    /**
     * Constructor sin parametros de la clase Switch
     */
    public Switch()
    {
        interruptor = OFF;
    }

    /**
     * Metodo que cambia el valor del interruptor, si esta en OFF lo cambia a ON y viceversa
     */
    public void press()
    {
        if (interruptor == OFF){
            interruptor = ON;
        }
        else{
            interruptor = OFF;
        }
    }
   
    /**
     * Metodo que devuelve el valor del atributo interruptor
     * 
     * @return devuelve el valor del atributo interruptor
     */
    public boolean getInterruptor()
    {
        return interruptor;
    }
    
    /**
     * Metodo que devuelve el valor del atributo interruptor
     * 
     * @return devuelve ON u OFF , depende del valor del interuptor , devuelve un String
     */
    public String toString()
    {
        if (getInterruptor() == OFF){
            return "OFF";
        }
        else{
            return "ON";
        }
    }
}
