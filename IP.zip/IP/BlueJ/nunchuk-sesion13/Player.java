
/**
 * Clase Player del proyecto nunchuk
 * 
 * @author (Antonio Paya) 
 * @version (11/11/2015)
 */
public class Player
{
    // Atributos
    private String name;
    private int number;

    /**
     * Constructor de la clase Player
     */
    public Player(String newName,int newNumber)
    {
        setName(newName);
        setNumber(newNumber);
    }


    //Metodos set
    
    /**
     * Metodo que modifica el atributo name
     * 
     * @param  newName , de tipo String, Nuevo nombre para el personaje
     */
    private void setName(String newName)
    {
        if (newName != null){
            name = newName;
        }
    }
    
    /**
     * Metodo que modifica el atributo number
     * 
     * @param  newNumber , de tipo int, Nuevo numero para el personaje
     */
    private void setNumber(int newNumber)
    {
        number = newNumber;
    }
    
    // Metodos get
    
    /**
     * Metodo que devuelve el valor de el atributo name
     * 
     * @return  devuelve el valor de el atributo name
     */
    public String getName()
    {
        return name;
    }
    
    /**
     * Metodo que devuelve el valor de el atributo number
     * 
     * @return  devuelve el valor de el atributo number
     */
    public int getNumber()
    {
        return number;
    }
}
