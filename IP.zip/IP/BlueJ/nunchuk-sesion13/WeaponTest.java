

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class WeaponTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class WeaponTest
{
    /**
     * Metodo test del constructor sin parametros de la clase Wheel
     */
    @Test
    public void TestWeapon(){
        Weapon arma = new Weapon();
        
        assertEquals("Gun",arma.getWeaponName());
        assertEquals(arma.MAX_MUN,arma.getAmmunition());
    }
    
    /**
     * Metodo test del constructor con parametros de la clase Wheel
     */
    @Test
    public void TestWeaponWithParameters(){
        Weapon arma = new Weapon("pistolita",12);
        
        assertEquals("pistolita",arma.getWeaponName());
        assertEquals(12,arma.getAmmunition());
    }
    

    @Test
    public void TestToString(){
        Weapon arma = new Weapon("pistolita",12);
        
        assertEquals("Nombre: pistolita  Municion: 12",arma.toString());
    }
}
