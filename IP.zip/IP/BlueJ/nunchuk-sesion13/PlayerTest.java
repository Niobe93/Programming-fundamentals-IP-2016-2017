

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class PlayerTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class PlayerTest
{
    /**
     * Test que prueba el constructor con parametros de la clase Player
     */
    @Test
    public void TestPlayerWhithParameters()
    {
        Player jugador = new Player("Antonio",0);
        assertEquals("Antonio",jugador.getName());
        assertEquals(0,jugador.getNumber());
    }
}
