
/**
 * Clase figure , simula el personaje de un juego
 * 
 * @author (Antonio Paya Gonzalez) 
 * @version (29/10/2015
 */
public class Figure
{
    //Constantes
    public static final int X_LOWER_EDGE = 0;
    public static final int Y_LOWER_EDGE = 0;
    public static final int X_UPPER_EDGE = 640;
    public static final int Y_UPPER_EDGE = 320;
    
    public static final char LEFT = 'a';
    public static final char RIGHT = 'd';
    public static final char UP = 'w';
    public static final char DOWN = 's';
    
     public static final int STEP = 10;
    
    // Atributos
    private int xPos;
    private int yPos;
    private String name;

    /**
     * Constructor sin parametros
     */
    public Figure()
    {
        xPos = X_LOWER_EDGE;
        yPos = Y_LOWER_EDGE;
        name = "Antonio";
    }

    /**
     * Constructor con parametros de la clase Figure, pide el nombre
     * por parametro
     * 
     * @param newName, nuevo nombre 
     */
    public Figure(String newName)
    {
        this();
        name = newName;
    }
    
    
    // Metodos set
    /**
     * Metodo que modifica el valor del atributo xPos
     * 
     * @param  newXPos, nuevo valor para la posicion en x
     */
    private void setXPos(int newXPos)
    {
        xPos = newXPos;
    }
    
    /**
     * Metodo que modifica el valor del atributo yPos
     * 
     * @param  newYPos, nuevo valor para la posicion en y
     */
    private void setYPos(int newYPos)
    {
        yPos = newYPos;
    }
    
    /**
     * Metodo que modifica el valor del atributo name
     * 
     * @param  newName, nuevo valor para el nombre del personaje
     */
    private void setName(String newName)
    {
        name = newName;
    }
    
    //Metodos get
    
    /**
     * Metodo devuelve el valor del atributo xPos
     * 
     * @return  devuelve el valor de la posicion en x
     */
    public int getXPos()
    {
        return xPos;
    }
    
    /**
     * Metodo devuelve el valor del atributo yPos
     * 
     * @return  devuelve el valor de la posicion en y
     */
    public int getYPos()
    {
        return yPos;
    }
    
    /**
     * Metodo que devuelve el valor del atributo name
     * 
     * @return  devuelve el nombre del personaje
     */
    public String getName()
    {
        return name;
    }
    
    
    //Otros metodos
    
    /**
     * Metodo queindica la direccion de movimiento del personaje.Si recibe LEFT o RIGHT
     * se mueve un paso adelante o atras en el eje x , si recibe UP o DOWN se mueve un paso
     * arriba en el eje y. Si al moverse se pasa del borde de la pantalla no se 
     * ejecuta movimiento
     * 
     * @param  tecla, tecla introducida por el usuario para mover al personaje, (w,a,s,d)
     */
    public void move(char tecla)
    {
        int newPos;
        if (tecla == LEFT){
            newPos = getXPos()-STEP;
            if (newPos >= X_LOWER_EDGE){
                setXPos(newPos);
            }
        }
        else if (tecla == RIGHT){
            newPos = getXPos()+STEP;
            if (newPos <= X_UPPER_EDGE){
                setXPos(newPos);
            }
        }
        else if (tecla == UP){
            newPos = getYPos()+STEP;
            if (newPos <= Y_UPPER_EDGE){
                setYPos(newPos);
            }
        }
        else if (tecla == DOWN){
            newPos = getYPos()-STEP;
            if (newPos >= Y_LOWER_EDGE){
                setYPos(newPos);
            }
        }
    }
    
    /**
     * Metodo que devuelve una cadena con el nombre de personaje y su
     * posicion X e Y
     * 
     * @return  devuelve un String
     */
    public String toString()
    {
        return "Nombre:"+getName()+" Posicion x:"+getXPos()+" Posicion y:"+getYPos();
    }
}

