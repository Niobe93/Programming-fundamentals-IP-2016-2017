
/**
 * Clase Weapon(arma) que simula un arma de un juego
 * 
 * @author (Antonio Paya Gonzalez) 
 * @version (29/10/2015)
 */
public class Weapon
{
    //Constantes
    public static final int MIN_MUN = 0;
    public static final int MAX_MUN = 20;
    
    // Atributos
    private String weaponName;
    private int ammunition;

    /**
     * Constructor sin parametros de la clase Weapon
     */
    public Weapon()
    {
        weaponName = "Gun";
        ammunition = MAX_MUN;
    }
    
    /**
     * Constructor con parametros que da valor a los atributos nombre y
     * municion
     * 
     * @param weaponName, nuevo nombre para el arma , tipo String
     * @param ammunition , nuevo valor para la cantidad de municion
     */
    public Weapon(String newName,int newMun)
    {
        this();
        setWeaponName(newName);
        setAmmunition(newMun);
    }

    
    //Metodos set
    /**
     * Metodo que modifica el valor del atributo weaponName
     * 
     * @param  newName, nuevo nombre para el arma
     */
    private void setWeaponName(String newName)
    {
        weaponName = newName;
    }
    
    /**
     * Metodo que modifica el valor del atributo ammunition
     * 
     * @param  newMun, nuevo valor para la municion del arma
     */
    private void setAmmunition(int newMun)
    {
        if (newMun > MIN_MUN && newMun < MAX_MUN){
            ammunition = newMun;
        }
    }
    
    //Metodos get
    
    /**
     * Metodo devuelve el valor del atributo weaponName
     * 
     * @return  devuelve el nombre del arma
     */
    public String getWeaponName()
    {
        return weaponName;
    }
    
    /**
     * Metodo devuelve el valor del atributo ammunition
     * 
     * @return  devuelve la cantidad de municion
     */
    public int getAmmunition()
    {
        return ammunition;
    }
    
    //Otros metodos
    
    /**
     * Metodo que si el arma tiene municion imprime por pantalla "BANG"
     * y disminuye en una unidad la municion.
     */
    public void shoot()
    {
        if (getAmmunition() > MIN_MUN){
            System.out.println("BANG");
            setAmmunition(getAmmunition()-1);
        }
    }
    
    /**
     * Metodo que devuelve una cadena con el nombre del arma y la municion
     * total que tiene
     */
    public String toString()
    {
        return "Nombre: "+getWeaponName()+"  Municion: "+getAmmunition();
    }
}

