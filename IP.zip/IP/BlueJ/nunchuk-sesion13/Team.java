import java.util.ArrayList;
/**
 * Clase equipo(Team)
 * 
 * @author (Antonio Paya) 
 * @version (11/11/2015)
 */
public class Team
{
    // Atributos
    private ArrayList<Player> equipo = new ArrayList<Player>();
    

    /**
     * Constructor de la clase Team
     */
    public Team()
    {
        equipo.add(new Player("Antonio",0));
        equipo.add(new Player("Menganito",1));
    }

    /**
     * Metodo que devuelve el ArrayList equipo
     * 
     * @return ArrayList
     */
    public ArrayList<Player> getEquipo()
    {
        return equipo;
    }
    
    /**
     * Metodo que añade un jugador a el equipo
     * 
     * @param player , de tipo Player
     */
    public void add(Player player)
    {
        if (player != null){
            equipo.add(player);
        }
    }
    
    /**
     * Metodo que añade un jugador a el equipo en la posicion indicada por index
     * 
     * @param index, de tipo int, posicion del jugador en array
     * @param player , de tipo Player
     */
    public void add(int index,Player player)
    {
        if (player != null && index <= equipo.size() && index >= 0){
            equipo.add(index,player);
        }
    }
    
    /**
     * Metodo que devuelve el jugador con el numero pasado como parametro
     * o null si no hay jugador con ese numero
     * 
     * @param number, de tipo int
     * @return devuelve el jugador o null
     */
    public Player seekPlayer(int number)
    {
        if(number >= 0 && number <= equipo.size()){
            return equipo.get(number);
        }
        else {
            return null;
        }
    }
    
    /**
     * Metodo que devuelve un ArrayList con los jugadores que tienen numero impar
     * 
     * @return devuelve jugadores con numero impar
     */
    public ArrayList<Player> trainPlayers()
    {
        ArrayList<Player> impares = new ArrayList<Player>();
        for(int i=1;i<=equipo.size();i=i+2){
            impares.add(equipo.get(i));
        }
        return impares;
    }
    
    /**
     * Metodo que elimina del equipo el jugador recibido como parametro
     * 
     * @param number, de tipo int, jugador a eliminar
     */
    public void removePlayer(int number)
    {
        if(number >= 0 && number <= equipo.size()){
            equipo.remove(number);
        }
    }
    
    /**
     * Metodo que muestra los jugadores por consola
     * 
     */
    public void seeContacts()
    {
        System.out.println(equipo);
    }
}
