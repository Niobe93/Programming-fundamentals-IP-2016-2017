

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class NunchukTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class NunchukTest
{
    /**
     * Test del constructor sin parametros de la clase Nunchuk
     */
    @Test
    public void TestNunchuk()
    {
        Nunchuk mando = new Nunchuk();
        
        assertNotNull(mando.getPersonaje());
        assertNotNull(mando.getArma());
    }
    
    /**
     * Test del constructor con parametros de la clase Nunchuk
     */
    @Test
    public void TestNunchukWithParameters()
    {
        Weapon pistolita = new Weapon();
        Figure paisano = new Figure();
        Nunchuk mando = new Nunchuk(paisano,pistolita);
        
        assertNotNull(mando.getPersonaje());
        assertNotNull(mando.getArma());
    }
    
    @Test
    public void TestAvanzar()
    {
        Nunchuk mando = new Nunchuk();

        //Mover a la derecha 
        mando.avanzar('d');
        assertEquals(10,mando.getPersonaje().getXPos());
        //Mover a la izquierda 
        mando.avanzar('a');
        assertEquals(0,mando.getPersonaje().getXPos());
        //Mover arriba 
        mando.avanzar('w');
        assertEquals(10,mando.getPersonaje().getYPos());
        //Mover abajo 
        mando.avanzar('s');
        assertEquals(0,mando.getPersonaje().getYPos());

    }
    
    @Test
    public void TestMidleAdvance()
    {
        Nunchuk mando = new Nunchuk();

        //Mover a la derecha 
        mando.midleAdvance('d');
        assertEquals(20,mando.getPersonaje().getXPos());
        //Mover a la izquierda 
        mando.midleAdvance('a');
        assertEquals(0,mando.getPersonaje().getXPos());
        //Mover arriba 
        mando.midleAdvance('w');
        assertEquals(20,mando.getPersonaje().getYPos());
        //Mover abajo 
        mando.midleAdvance('s');
        assertEquals(0,mando.getPersonaje().getYPos());

    }
    
    @Test
    public void TestMuchAdvance()
    {
        Nunchuk mando = new Nunchuk();

        //Mover a la derecha 
        mando.muchAdvance('d');
        assertEquals(50,mando.getPersonaje().getXPos());
        //Mover a la izquierda 
        mando.muchAdvance('a');
        assertEquals(0,mando.getPersonaje().getXPos());
        //Mover arriba 
        mando.muchAdvance('w');
        assertEquals(50,mando.getPersonaje().getYPos());
        //Mover abajo 
        mando.muchAdvance('s');
        assertEquals(0,mando.getPersonaje().getYPos());

    }
    
    @Test
    public void TestShootWeapon()
    {
        Nunchuk mando = new Nunchuk();

        mando.shootWeapon(true);
        assertEquals(15,mando.getArma().getAmmunition());
        mando.shootWeapon(false);
        assertEquals(14,mando.getArma().getAmmunition());
    }
    
    @Test
    public void TestShootForward()
    {
        Nunchuk mando = new Nunchuk();
        
        //Mover derecha
        mando.shootForward('d');
        assertEquals(19,mando.getArma().getAmmunition());
        assertEquals(10,mando.getPersonaje().getXPos());
        //Mover izquierda
        mando.shootForward('a');
        assertEquals(18,mando.getArma().getAmmunition());
        assertEquals(0,mando.getPersonaje().getXPos());
        //Mover arriba
        mando.shootForward('w');
        assertEquals(17,mando.getArma().getAmmunition());
        assertEquals(10,mando.getPersonaje().getYPos());
        //Mover abajo
        mando.shootForward('s');
        assertEquals(16,mando.getArma().getAmmunition());
        assertEquals(0,mando.getPersonaje().getYPos());
    }
}
