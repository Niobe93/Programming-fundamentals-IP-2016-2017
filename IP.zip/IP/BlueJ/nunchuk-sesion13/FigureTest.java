


import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class FigureTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class FigureTest
{
    /**
     * Test para el constructor sin parametros de la clase Figure
     */
    @Test
    public void TestFigure()
    {
        Figure figure1 = new Figure();
        
        assertEquals(0,figure1.getXPos());
        assertEquals(0,figure1.getYPos());
        assertEquals("Antonio",figure1.getName());
    }
    
    /**
     * Test para el constructor con parametros de la clase Figure
     */
    @Test
    public void TestFigureWithParameters()
    {
        Figure figure1 = new Figure("Rodolfo");
        
        assertEquals(0,figure1.getXPos());
        assertEquals(0,figure1.getYPos());
        assertEquals("Rodolfo",figure1.getName());
    }
    
    @Test
    public void TestMove()
    {
        Figure figure1 = new Figure();
        
        //Pruebas positivas
        
        //Mover a la derecha dentro de limites
        figure1.move('d');
        assertEquals(10,figure1.getXPos());
        //Mover a la izquierda dentro de limites
        figure1.move('a');
        assertEquals(0,figure1.getXPos());
        //Mover arriba dentro de limites
        figure1.move('w');
        assertEquals(10,figure1.getYPos());
        //Mover abajo dentro de limites
        figure1.move('s');
        assertEquals(0,figure1.getYPos());
        
        Figure figure2 = new Figure();
        //Pruebas negativas
        //Mover a la izquierda fuera de limites
        figure2.move('a');
        assertEquals(0,figure2.getXPos());
        //Mover a la derecha fuera de limites
        figure2.move('d');
        assertEquals(10,figure2.getXPos());
        //Mover abajo fuera de limites
        figure2.move('s');
        assertEquals(0,figure2.getYPos());
        //Mover arriba fuera de limites
        figure2.move('w');
        assertEquals(10,figure2.getYPos());
    }
    
    @Test
    public void TestToString()
    {
        Figure figure1 = new Figure("antonio");
        figure1.move('d');
        figure1.move('w');
        
        assertEquals("Nombre:antonio Posicion x:10 Posicion y:10",figure1.toString());
        
    }
}
