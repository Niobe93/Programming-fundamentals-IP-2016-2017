

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class TeamTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class TeamTest
{
    /**
     * Test que prueba el constructor sin parametros de la clase Team
     */
    @Test
    public void TestTeam()
    {
        Team team = new Team();
        assertEquals("Antonio",team.seekPlayer(0).getName());
        assertEquals(0,team.seekPlayer(0).getNumber());
        assertEquals("Pablo",team.seekPlayer(1).getName());
        assertEquals(1,team.seekPlayer(1).getNumber());
    }
    
    /**
     * Test que prueba el metodo add de la clase Team
     */
    @Test
    public void TestAdd()
    {
        Team team = new Team();
        //Caso 1:Se añade correctamente
        team.add(new Player("Menganito",2));
        assertEquals("Menganito",team.seekPlayer(2).getName());
        assertEquals(2,team.seekPlayer(2).getNumber());
        //Caso 2: Se añade en una posicion ocupada(no se modifica)
        team.add(new Player("Menganito",1));
        assertEquals("Pablo",team.seekPlayer(1).getName());
        assertEquals(1,team.seekPlayer(1).getNumber());
        //Caso 3: Se añade un jugador en una posicion sin que la anterior este ocupada
        team.add(new Player("Fulanito",4));
        assertEquals("Fulanito",team.seekPlayer(4).getName());
        assertEquals(4,team.seekPlayer(4).getNumber());
    }
    
    /**
     * Test que prueba el metodo add con 2 parametros de la clase Team
     */
    @Test
    public void TestAddWithIndex()
    {
        Team team = new Team();
        //Caso 1:Se añade correctamente
        team.add(2,new Player("Menganito",2));
        assertEquals("Menganito",team.seekPlayer(2).getName());
        assertEquals(2,team.seekPlayer(2).getNumber());
        //Caso 2: Se añade en una posicion ocupada(no se modifica)
        team.add(1,new Player("Pablo",1));
        assertEquals("Pablo",team.seekPlayer(1).getName());
        assertEquals(1,team.seekPlayer(1).getNumber());
        //Caso 3: Se añade un jugador en una posicion sin que la anterior este ocupada
        team.add(4,new Player("Fulanito",4));
        assertEquals("Fulanito",team.seekPlayer(4).getName());
        assertEquals(4,team.seekPlayer(4).getNumber());
        //Caso 4: Se añade con un index diferente al numero
        team.add(4,new Player("Fulanito",1));
        assertEquals("Fulanito",team.seekPlayer(4).getName());
        assertEquals(1,team.seekPlayer(4).getNumber());
    }
    
    /**
     * Test que prueba el metodo seekPlayer de la clase Team
     */
    @Test
    public void TestSeekPlayer()
    {
        Team team = new Team();
        
    }
}
