
/**
 * Clase Nunchuk 
 * 
 * @author (Antonio Paya Gonzalez) 
 * @version (29/10/2015)
 */
public class Nunchuk
{
    //Constantes
    public static final int MIN_MUN = 0;
    public static final int MAX_MUN = 20;

    public static final char ARRIBA = 'w';
    public static final char ABAJO = 's';
    public static final char IZQUIERDA = 'a';
    public static final char DERECHA = 'd';

    // Atributos
    private Figure personaje;
    private Weapon arma;

    /**
     * Constructor sin parametros de la clase Nunchuk
     */
    public Nunchuk()
    {
        personaje = new Figure();
        arma = new Weapon();
    }

    /**
     * Constructor con parametros que da valor a los atributos arma y personaje
     * 
     * @param personaje, nuevo personaje , tipo Figure
     * @param arma , nuevo arma , tipo Weapon
     */
    public Nunchuk(Figure paisano,Weapon pistola)
    {
        this();
        setArma(pistola);
        setPersonaje(paisano);
    }

    /**
     *  Modifica el valor del atributo personaje
     * 
     * @param  nuevo valor para personaje , de tipo Figure
     */
    private void setPersonaje(Figure newPersonaje)
    {
        if (newPersonaje != null){
            personaje = newPersonaje;
        }
    }

    /**
     * Devuelve el valor del atributo personaje
     * 
     * @return  devuelve el valor de personaje , de tipo personaje
     */
    public Figure getPersonaje()
    {
        return personaje;
    }

    /**
     *  Modifica el valor del atributo arma
     * 
     * @param  nuevo valor para arma , de tipo Weapon
     */
    private void setArma(Weapon newArma)
    {
        if (newArma != null){
            arma = newArma;
        }
    }

    /**
     * Devuelve el valor del atributo arma
     * 
     * @return  devuelve el valor de arma , de tipo Weapon
     */
    public Weapon getArma()
    {
        return arma;
    }

    //Otros metodos

    /**
     * Metodo que recibe como parametro la direccion hacia donde va a avanzar
     * el personaje
     * 
     * @param  tecla , de tipo char direccion del movimiento
     */
    public void avanzar(char tecla)
    {
        personaje.move(tecla);
    }

    /**
     * Metodo que recibe como parametro la direccion hacia donde va a avanzar
     * el personaje, avanza dos pasos.
     * 
     * @param  tecla , de tipo car , direccion del movimiento
     */
    public void midleAdvance(char tecla)
    {
        int i = 0;
        while (i<2){
            personaje.move(tecla);
            i= i+1;
        }
    }

    /**
     * Metodo que recibe como parametro la direccion hacia donde va a avanzar
     * el personaje, avanza cinco pasos.
     * 
     * @param  tecla , de tipo car , direccion del movimiento
     */
    public void muchAdvance(char tecla)
    {
        int i = 0;
        while (i<5){
            personaje.move(tecla);
            i= i+1;
        }
    }

    /**
     * Metodo que recibe como parametro un booleano que indica true si se dispara
     * 5 veces el arma y false si solo se dispara una
     * 
     * @param  rafaga, de tipo boolean , indica si se dispara una rafaga o no
     */
    public void shootWeapon(boolean rafaga)
    {
        int i = 0;
        if (rafaga == false){
            arma.shoot();
        }
        else{
            while (i<5){
                arma.shoot();
                i= i+1;
            }
        }
    }
    
    /**
     * Metodo que recibe como parametro la direccion hacia donde se debe
     * desplazar el personaje. El personaje se movera y disparara una vez
     * 
     * @param  tecla, de tipo char, direccion del movimiento
     */
    public void shootForward(char tecla)
    {
        personaje.move(tecla);
        arma.shoot();
    }
    
    /**
     * Metodo que imprime por pantalla el estado de los atributos
     */
    public void print()
    {
        System.out.print("\f");
        System.out.println(personaje.toString());
        System.out.println(arma.toString());
    }
}
