import java.util.Random;
/**
 * Ejercicio obligatorio de seminario
 * 
 * @author (Antonio Paya Gonzalez) 
 * @version (11/12/2015)
 */
public class Matriz
{
    // Atributos
    private int[][] matriz;

    /**
     * Constructor de la clase Matriz
     * @param dimension, de tipo int, dimension de la matriz
     */
    public Matriz(int dimension)
    {
        setMatriz(dimension);
    }

    /**
     * Constructor de la clase Matriz con un parametro array
     * @param array
     */
    public Matriz(int[][] array)
    {
        matriz=array;
    }

    /**
     * Metodo que crea una matriz cuadrada de dimension del parametro solicitado
     *
     * @param  dimension , de tipo int, dimension de la matriz
     */
    private void setMatriz(int dimension)
    {
        if (dimension > 1){
            matriz = new int[dimension][dimension];
        }
        else{
            throw new RuntimeException("Parametros incorrectos");
        }
    }

    /**
     * Metodo que devuelve la matriz
     *
     * @return devuelve la matriz.
     */
    public int[][] getMatriz()
    {
        return matriz;
    }

    /**
     * Metodo que devuelve el elemento de la matriz de los parametros introducidos
     *
     * @param row, fila , de tipo int
     * @param colum, columna , de tipo int
     * @return devuelve el elemento de la matriz.
     */
    public int getElemMatriz(int row,int colum)
    {
        if (row >=0 && row < matriz.length && colum >= 0 && colum < matriz.length){
            return matriz[row][colum];
        }
        else{
            throw new RuntimeException("Parametros incorrectos");
        }
    }

    /**
     * Metodo que devuelve True si la matriz esta llena o False si no
     *
     * @return boolean, True o False
     */
    public boolean comprobarMatriz()
    {
        for (int i=0;i<matriz.length;i++){
            for(int j=0;j<matriz.length;j++){
                if (matriz[i][j]==0){
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * Metodo que rellena la matriz con numeros aleatorios entre 1 y 50
     */
    public void fill()
    {
        Random r = new Random();
        for (int i=0; i<matriz.length;i++){
            for (int j=0; j<matriz.length;j++){
                matriz[i][j] = r.nextInt(50)+1;
            }
        }
    }

    /**
     * Metodo que imprime por pantalla la matriz
     */
    public void print()
    {
        for (int i=0; i<matriz.length;i++){
            for (int j=0; j<matriz.length;j++){
                if (matriz[i][j]>=10){
                    System.out.print("["+matriz[i][j]+"]");
                }
                else{
                    System.out.print("[ "+matriz[i][j]+"]");
                }
            }
            System.out.println();
        }
    }

    /**
     * Metodo que intercambia los elementos de las dos diagonales de la matriz
     */
    public void intercambioDiagonales()
    {
        int[] diagPrin = new int[matriz.length]; //vector con los elementos de la matriz principal
        int[] diagSec = new int[matriz.length]; //vector con los elementos de la matriz secundaria
        int aux=matriz.length; //variable auxiliar
        for (int i=0;i<matriz.length;i++){
            diagPrin[i]=matriz[i][i];
        }
        for (int i=0;i<matriz.length;i++){
            diagSec[i]=matriz[i][aux-1];
            aux--;
        }
        aux = matriz.length;
        for (int i=0;i<matriz.length;i++){
            matriz[i][i]=diagSec[i];
            matriz[i][aux-1]=diagPrin[i];
            aux--;
        }
    }

    /**
     * Metodo que intercambia los elementos de las filas impares (1-3,3-5,..)
     */
    public void intercambioFimpares()
    {
        int aux;
        for (int i=0;i<matriz.length;i++){
            if (i%2==1 && i+2<=(matriz.length-1)){
                for (int j=0;j<matriz.length;j++){
                    aux = matriz[i][j];
                    matriz[i][j]=matriz[i+2][j];
                    matriz[i+2][j]= aux;
                }
            }
        }
    }

    /**
     * Metodo que intercambia los elementos de las columnas pares
     */
    public void intercambioCpares()
    {
        int aux;
        for (int i=0;i<matriz.length;i++){
            for (int j=0;j<matriz.length;j++){
                if ((j%2==0 && j+2<=(matriz.length-1 )|| j==0)){
                    aux = matriz[i][j];
                    matriz[i][j]=matriz[i][j+2];
                    matriz[i][j+2]= aux;
                }
            }
        }
    }

    /**
     * Metodo que rota a la derecha los elementos de la matriz
     */
    public void rotaDerecha()
    {
        //Creo una matriz auxiliar y copio los valores correspondientes a la matriz
        int aux [][] = new int [matriz.length][matriz.length];
        for(int i=0; i< aux.length; i++){
            for(int j=0; j<aux.length; j++){
                aux[i][j] = matriz[i][j];
            }
        }
        for(int i=0; i<matriz.length; i++){
            for(int j=0; j<matriz.length; j++){
                matriz[j][matriz.length-1-i]=aux[i][j];
            }
        }
    }

    /**
     * Metodo que rota a la izquierda los elementos de la matriz
     */
    public void rotaIzquierda()
    {
        // Giro 3 veces a la derecha la matriz para obtener el giro a la izquierda
        for(int i=0;i<3;i++){
            rotaDerecha();
        }
    }

    /**
     * Metodo que desplaza en ziz-zag vertical los elementos de las columnas impares de la matriz
     */
    public void zzVertical()
    {
        int aux;
        for(int i=0;i<matriz.length;i++){
            for(int j=0;j<matriz.length;j++){
                if(j%2!=0 && i<(matriz.length/2)){
                    aux = matriz[i][j];
                    matriz[i][j]=matriz[matriz.length-1-i][j];
                    matriz[matriz.length-1-i][j]=aux;
                }
            }
        }
    }
    
    /**
     * Metodo que desplaza en ziz-zag horizontal los elementos de las filas impares de la matriz
     */
    public void zzHorizontal()
    {
        int aux;
        for(int i=0;i<matriz.length;i++){
            for(int j=0;j<matriz.length;j++){
                if (i%2!=0 && j<(matriz.length/2)){
                    aux = matriz[i][j];
                    matriz[i][j]=matriz[i][matriz.length-1-j];
                    matriz[i][matriz.length-1-j]=aux;
                }
            }
        }
    }
}
