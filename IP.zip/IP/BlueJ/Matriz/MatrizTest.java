

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * Clase de prueba de la clase Matriz
 *
 * @author  (Antonio Paya Gonzalez)
 * @version (12/12/2015)
 */
public class MatrizTest
{
    /**
     * Metodo que prueba el constructor de la matriz
     * y El método fill , que rellena la matriz
     */
    @Test
    public void TestMatriz()
    {
        Matriz m = new Matriz(4);
        //Caso 1: Matriz vacia
        assertFalse(m.comprobarMatriz());
        //Caso 2: Matriz llena:
        m = new Matriz(4);
        m.fill();
        assertTrue(m.comprobarMatriz());
        //Caso 3:Rellenar matriz ya llena
        m.fill();
        assertTrue(m.comprobarMatriz());
    }
    
    /**
     * Metodo que prueba el metodo intercambioDiagonales de la matriz
     */
    @Test
    public void TestCambioDiagonales()
    {
        int[][] mat = new int[3][3];
        int contador =1;
        for (int i=0;i<mat.length;i++){
            for (int j=0;j<mat.length;j++){
                mat[i][j]=contador;
                contador++;
            }
        }
        //Creo la matriz cuyos elementos van del 1 al 9
        Matriz m = new Matriz(mat);
        assertEquals(9,m.getElemMatriz(2,2)); //Compruebo que el ultimo elemento es el 9
        
        m.intercambioDiagonales();
        //Compruebo la diagonal principal
        assertEquals(3,m.getElemMatriz(0,0));
        assertEquals(5,m.getElemMatriz(1,1));
        assertEquals(7,m.getElemMatriz(2,2));
        //Compruebo la diagonal secundaria
        assertEquals(1,m.getElemMatriz(0,2));
        assertEquals(5,m.getElemMatriz(1,1));
        assertEquals(9,m.getElemMatriz(2,0));
    }
    
    /**
     * Metodo que prueba el metodo intercambioFimpares de la matriz
     */
    @Test
    public void TestCambioFimpares()
    {
        int[][] mat = new int[4][4];
        int contador =1;
        for (int i=0;i<mat.length;i++){
            for (int j=0;j<mat.length;j++){
                mat[i][j]=contador;
                contador++;
            }
        }
        //Creo la matriz cuyos elementos van del 1 al 16
        Matriz m = new Matriz(mat);
        contador=1;
        //Compruebo que los elementos de la matriz son correctos
        for (int i=0;i<mat.length;i++){
            for (int j=0;j<mat.length;j++){
                assertEquals(contador,m.getElemMatriz(i,j));
                contador++;
            }
        }
        
        m.intercambioFimpares();
        //Compruebo la primera fila impar
        contador=13;
        for (int j=0;j<mat.length;j++){
            assertEquals(contador,m.getElemMatriz(1,j));
            contador++;
        }
        
        //Compruebo la segunda fila impar
        contador=5;
        for (int j=0;j<mat.length;j++){
            assertEquals(contador,m.getElemMatriz(3,j));
            contador++;
        }
    }
    
    /**
     * Metodo que prueba el metodo intercambioCpares de la matriz
     */
    @Test
    public void TestCambioCpares()
    {
        int[][] mat = new int[4][4];
        int contador =1;
        for (int i=0;i<mat.length;i++){
            for (int j=0;j<mat.length;j++){
                mat[i][j]=contador;
                contador++;
            }
        }
        //Creo la matriz cuyos elementos van del 1 al 16
        Matriz m = new Matriz(mat);
        contador=1;
        //Compruebo que los elementos de la matriz son correctos
        for (int i=0;i<mat.length;i++){
            for (int j=0;j<mat.length;j++){
                assertEquals(contador,m.getElemMatriz(i,j));
                contador++;
            }
        }
        
        m.intercambioCpares();
        //Compruebo la primera columna par
        contador=3;
        for (int i=0;i<mat.length;i++){
            assertEquals(contador,m.getElemMatriz(i,0));
            contador=contador+4;
        }
        
        //Compruebo la segunda columna par
        contador=1;
        for (int i=0;i<mat.length;i++){
            assertEquals(contador,m.getElemMatriz(i,2));
            contador=contador+4;
        }
    }
    
    /**
     * Metodo que prueba el metodo rotaDerecha de la matriz
     */
    @Test
    public void TestRotaDerecha()
    {
        int[][] mat = new int[4][4];
        int contador =1;
        for (int i=0;i<mat.length;i++){
            for (int j=0;j<mat.length;j++){
                mat[i][j]=contador;
                contador++;
            }
        }
        //Creo la matriz cuyos elementos van del 1 al 16
        Matriz m = new Matriz(mat);
        contador=1;
        //Compruebo que los elementos de la matriz son correctos
        for (int i=0;i<mat.length;i++){
            for (int j=0;j<mat.length;j++){
                assertEquals(contador,m.getElemMatriz(i,j));
                contador++;
            }
        }
        m.rotaDerecha();
        
        //Compruebo que los elementos de ma matriz han rotado
        contador = 1;
        for (int i=0; i<mat.length; i++){
            assertEquals(contador,m.getElemMatriz(i,3));
            contador++;
        }
        contador = 5;
        for (int i=0; i<mat.length; i++){
            assertEquals(contador,m.getElemMatriz(i,2));
            contador++;
        }
        contador = 9;
        for (int i=0; i<mat.length; i++){
            assertEquals(contador,m.getElemMatriz(i,1));
            contador++;
        }
        contador = 13;
        for (int i=0; i<mat.length; i++){
            assertEquals(contador,m.getElemMatriz(i,0));
            contador++;
        }
    }
    
    /**
     * Metodo que prueba el metodo rotaIzquierda de la matriz
     */
    @Test
    public void TestRotaIzquierda()
    {
        int[][] mat = new int[4][4];
        int contador =1;
        for (int i=0;i<mat.length;i++){
            for (int j=0;j<mat.length;j++){
                mat[i][j]=contador;
                contador++;
            }
        }
        //Creo la matriz cuyos elementos van del 1 al 16
        Matriz m = new Matriz(mat);
        contador=1;
        //Compruebo que los elementos de la matriz son correctos
        for (int i=0;i<mat.length;i++){
            for (int j=0;j<mat.length;j++){
                assertEquals(contador,m.getElemMatriz(i,j));
                contador++;
            }
        }
        m.rotaIzquierda();
        
        //Compruebo que los elementos de ma matriz han rotado
        contador = 1;
        for (int i=3; i>=0; i--){
            assertEquals(contador,m.getElemMatriz(i,0));
            contador++;
        }
        contador = 5;
        for (int i=3; i>=0; i--){
            assertEquals(contador,m.getElemMatriz(i,1));
            contador++;
        }
        contador = 9;
        for (int i=3; i>=0; i--){
            assertEquals(contador,m.getElemMatriz(i,2));
            contador++;
        }
        contador = 13;
        for (int i=3; i>=0; i--){
            assertEquals(contador,m.getElemMatriz(i,3));
            contador++;
        }
    }
    
    /**
     * Metodo que prueba el metodo zzVertical de la matriz
     */
    @Test
    public void TestzzVertical()
    {
        int[][] mat = new int[4][4];
        int contador =1;
        for (int i=0;i<mat.length;i++){
            for (int j=0;j<mat.length;j++){
                mat[i][j]=contador;
                contador++;
            }
        }
        //Creo la matriz cuyos elementos van del 1 al 16
        Matriz m = new Matriz(mat);
        contador=1;
        //Compruebo que los elementos de la matriz son correctos
        for (int i=0;i<mat.length;i++){
            for (int j=0;j<mat.length;j++){
                assertEquals(contador,m.getElemMatriz(i,j));
                contador++;
            }
        }
        m.zzVertical();
        
        //Compruebo la primera columna impar
        contador=14;
        for (int i=0;i<mat.length;i++){
            assertEquals(contador,m.getElemMatriz(i,1));
            contador=contador-4;
        }
        
        //Compruebo la segunda fila impar
        contador=16;
        for (int i=0;i<mat.length;i++){
            assertEquals(contador,m.getElemMatriz(i,3));
            contador=contador-4;
        }
        
    }
    
    /**
     * Metodo que prueba el metodo zzHorizontal de la matriz
     */
    @Test
    public void TestzzHorizontal()
    {
        int[][] mat = new int[4][4];
        int contador =1;
        for (int i=0;i<mat.length;i++){
            for (int j=0;j<mat.length;j++){
                mat[i][j]=contador;
                contador++;
            }
        }
        //Creo la matriz cuyos elementos van del 1 al 16
        Matriz m = new Matriz(mat);
        contador=1;
        //Compruebo que los elementos de la matriz son correctos
        for (int i=0;i<mat.length;i++){
            for (int j=0;j<mat.length;j++){
                assertEquals(contador,m.getElemMatriz(i,j));
                contador++;
            }
        }
        m.zzHorizontal();
        //Compruebo la primera fila impar
        contador=8;
        for (int j=0;j<mat.length;j++){
            assertEquals(contador,m.getElemMatriz(1,j));
            contador--;
        }
        
        //Compruebo la segunda fila impar
        contador=16;
        for (int j=0;j<mat.length;j++){
            assertEquals(contador,m.getElemMatriz(3,j));
            contador--;
        }
        
    }
}
