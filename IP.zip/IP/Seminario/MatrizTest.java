6
import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;


/**
 * The test class MatrizTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class MatrizTest
{
    /**
     * Default constructor for test class MatrizTest
     */
    public MatrizTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }

    @Test
    public void testConstructor()
    {
        //Metodo auxiliar para comprobar que la matriz se ha creado correctamente con los valores concretos

        //Definimos la matriz que pasaremos como parámetro con unos números concretos del 1 al 50 5X5
        int[][] auxMatrix ={{1,12,13,14,15},{2,22,23,24,25},{3,32,33,34,35},{4,42,43,44,45},{5,47,48,49,50}};

        //Ahora creamos la matriz y pasamos como parámetro la que ya hemos definido        
        Matriz matriz1 = new Matriz(auxMatrix);

        assertArrayEquals(auxMatrix,matriz1.getMatriz());
        
        //Pruebas negativas
        //le pasamos una matriz vacía
        int[][] auxMatrix2 ={{}};
        try 
        {
           Matriz matriz2 = new Matriz(auxMatrix2);
        }
        catch (Exception ex)
        {
            assertEquals("Error: se debe introducir una matriz", ex.getMessage());
        }
    }

    @Test
    public void testReverseDiagonals()
    {
        //Definimos la matriz que pasaremos como parámetro con unos números concretos del 1 al 50 5X5
        int[][] auxMatrix ={{1,12,13,14,15},{2,22,23,24,25},{3,32,33,34,35},{4,42,43,44,45},{5,47,48,49,50}};

        //Ahora creamos la matriz y pasamos como parámetro la que ya hemos definido        
        Matriz matriz1 = new Matriz(auxMatrix);

        //CASO 1
        //Comprobamos llamando al metodo test construcor que se ha creado la matriz correctamente
        this.testConstructor();

        //Lamámos al método reverseDiagonals
        matriz1.reverseDiagonals();

        //Comprobamos que las diagonales se han intercambiado como esperábamos llamando al método getValue
        //nueva diagonal de izquierda a derecha
        assertEquals(50, matriz1.getValue(0, 0));
        assertEquals(44, matriz1.getValue(1, 1));
        assertEquals(33, matriz1.getValue(2, 2));
        assertEquals(22, matriz1.getValue(3, 3));
        assertEquals(1, matriz1.getValue(4, 4));
        //nueva diagonal de derecha a izquierda
        assertEquals(5, matriz1.getValue(0, 4));
        assertEquals(42, matriz1.getValue(1, 3));
        assertEquals(33, matriz1.getValue(2, 2));
        assertEquals(24, matriz1.getValue(3, 1));
        assertEquals(15, matriz1.getValue(4, 0));      

        //Ahora comprobamos que algunos de los valores fuera de las diagonales no han sufrido variaciones.
        assertEquals(12, matriz1.getValue(0, 1));
        assertEquals(34, matriz1.getValue(2, 3));
        assertEquals(48, matriz1.getValue(4, 2));
        assertEquals(43, matriz1.getValue(3, 2));
        assertEquals(49, matriz1.getValue(4, 3));
    }   
    
     @Test
    public void testVectorSum()
    {
        //Definimos la matriz que pasaremos como parámetro con unos números concretos del 1 al 50 5X5
        int[][] auxMatrix ={{1,12,13,14,15},{2,22,23,24,25},{3,32,33,34,35},{4,42,43,44,45},{5,47,48,49,50}};

        //Ahora creamos la matriz y pasamos como parámetro la que ya hemos definido        
        Matriz matriz1 = new Matriz(auxMatrix);
        
        //Comprobamos llamando al metodo test construcor que se ha creado la matriz correctamente
        this.testConstructor();

        //CASO 1 
        //creamos un vector con la suma de nuestra matriz y comprobamos que coincide con el vector llamando al método
        int [] vector = {55,96,137,178,199};        
        for( int i =0; i< vector.length; i++)
        {
          assertEquals(vector[i], matriz1.vectorSum()[i]);
        }
        
        
    }

    @Test
    public void testChangeColumns()
    {
        //Definimos la matriz que pasaremos como parámetro con unos números concretos del 1 al 50 5X5
        int[][] auxMatrix ={{1,12,13,14,15},{2,22,23,24,25},{3,32,33,34,35},{4,42,43,44,45},{5,47,48,49,50}};

        //Ahora creamos la matriz y pasamos como parámetro la que ya hemos definido        
        Matriz matriz1 = new Matriz(auxMatrix);
        
        //Comprobamos llamando al metodo test construcor que se ha creado la matriz correctamente
        this.testConstructor();

        //CASO 1 
        //LLamamos al metodo changeColumns 
        matriz1.changeColumns();

        //Comprobamos que se han intercambiado las columnas
        int[][]caso1={{12,13,14,15,1},{22,23,24,25,2},{32,33,34,35,3},{42,43,44,45,4},{47,48,49,50,5}};
        assertArrayEquals(caso1,matriz1.getMatriz());
        
        //CASO 2
        //LLamamos al metodo changeColumns dos veces
        matriz1.changeColumns();
        matriz1.changeColumns();

        //Comprobamos que las columnas se han cambiado dos veces(en total tres veces desde la original)
        int[][]caso2 ={{14,15,1,12,13},{24,25,2,22,23},{34,35,3,32,33},{44,45,4,42,43},{49,50,5,47,48}};
        assertArrayEquals(caso2,matriz1.getMatriz());
    }   

    @Test
    public void testMaxAdjacentValue()
    {
        //Definimos la matriz que pasaremos como parámetro con unos números concretos del 1 al 50 5X5
        int[][] auxMatrix ={{1,12,13,14,15},{2,22,23,24,25},{3,32,33,34,35},{4,42,43,44,45},{5,47,48,49,50}};

        //Ahora creamos la matriz y pasamos como parámetro la que ya hemos definido        
        Matriz matriz1 = new Matriz(auxMatrix);
        
        //Comprobamos llamando al metodo test construcor que se ha creado la matriz correctamente
        this.testConstructor();

        //Comprobamos todas las posiciones de la matriz

        //Esquinas
        //LLamamos al metodo maxAdjacentValue y le pasamos la posición (0,0)
        assertEquals(22 ,matriz1.maxAdjacentValue(0,0));        
        //LLamamos al metodo maxAdjacentValue y le pasamos la posición (0,4)        
        assertEquals(25 ,matriz1.maxAdjacentValue(0,4));        
        //LLamamos al metodo maxAdjacentValue y le pasamos la posición (4,0)
        assertEquals(47 ,matriz1.maxAdjacentValue(4,0));        
        //LLamamos al metodo maxAdjacentValue y le pasamos la posición (4,4)
        assertEquals(49 ,matriz1.maxAdjacentValue(4,4));

        //Extremos laterales
        //LLamamos al metodo maxAdjacentValue y le pasamos la posición (1,0)
        assertEquals(32 ,matriz1.maxAdjacentValue(1,0));        
        //LLamamos al metodo maxAdjacentValue y le pasamos la posición (2,0)
        assertEquals(42 ,matriz1.maxAdjacentValue(2,0));        
        //LLamamos al metodo maxAdjacentValue y le pasamos la posición (3,0)
        assertEquals(47 ,matriz1.maxAdjacentValue(3,0));        
        //LLamamos al metodo maxAdjacentValue y le pasamos la posición (1,4)
        assertEquals(35 ,matriz1.maxAdjacentValue(1,4));        
        //LLamamos al metodo maxAdjacentValue y le pasamos la posición (2,4)
        assertEquals(45 ,matriz1.maxAdjacentValue(2,4));        
        //LLamamos al metodo maxAdjacentValue y le pasamos la posición (3,4)
        assertEquals(50 ,matriz1.maxAdjacentValue(3,4));

        //Extremos arriba y abajo
        //LLamamos al metodo maxAdjacentValue y le pasamos la posición (0,1)
        assertEquals(23 ,matriz1.maxAdjacentValue(0,1));        
        //LLamamos al metodo maxAdjacentValue y le pasamos la posición (0,2)
        assertEquals(24 ,matriz1.maxAdjacentValue(0,2));        
        //LLamamos al metodo maxAdjacentValue y le pasamos la posición (0,3)
        assertEquals(25 ,matriz1.maxAdjacentValue(0,3));        
        //LLamamos al metodo maxAdjacentValue y le pasamos la posición (4,1)
        assertEquals(48 ,matriz1.maxAdjacentValue(4,1));        
        //LLamamos al metodo maxAdjacentValue y le pasamos la posición (4,2)
        assertEquals(49 ,matriz1.maxAdjacentValue(4,2));        
        //LLamamos al metodo maxAdjacentValue y le pasamos la posición (4,3)
        assertEquals(50 ,matriz1.maxAdjacentValue(4,3));

        //Valores centro        
        //LLamamos al metodo maxAdjacentValue y le pasamos la posición (1,1)
        assertEquals(33 ,matriz1.maxAdjacentValue(1,1));        
        //LLamamos al metodo maxAdjacentValue y le pasamos la posición (1,2)
        assertEquals(34 ,matriz1.maxAdjacentValue(1,2));        
        //LLamamos al metodo maxAdjacentValue y le pasamos la posición (1,3)
        assertEquals(35 ,matriz1.maxAdjacentValue(1,3));        
        //LLamamos al metodo maxAdjacentValue y le pasamos la posición (2,1)
        assertEquals(43 ,matriz1.maxAdjacentValue(2,1));        
        //LLamamos al metodo maxAdjacentValue y le pasamos la posición (2,2)
        assertEquals(44 ,matriz1.maxAdjacentValue(2,2));        
        //LLamamos al metodo maxAdjacentValue y le pasamos la posición (2,3)
        assertEquals(45 ,matriz1.maxAdjacentValue(2,3));        
        //LLamamos al metodo maxAdjacentValue y le pasamos la posición (3,1)
        assertEquals(48 ,matriz1.maxAdjacentValue(3,1));        
        //LLamamos al metodo maxAdjacentValue y le pasamos la posición (3,2)
        assertEquals(49 ,matriz1.maxAdjacentValue(3,2));        
        //LLamamos al metodo maxAdjacentValue y le pasamos la posición (3,3)
        assertEquals(50 ,matriz1.maxAdjacentValue(3,3));
        
        
        
        //Pruebas negativas
        //le pasamos parámetros erróneos
        
        try 
        {
           matriz1.maxAdjacentValue(-1,-10);
        }
        catch (Exception ex)
        {
            assertEquals("Error: parámetros no válidos", ex.getMessage());
        }
         
        
        try 
        {
            matriz1.maxAdjacentValue(9,8);
        }
        catch (Exception ex)
        {
            assertEquals("Error: parámetros no válidos", ex.getMessage());
        }
         
    }

    @Test
    public void testRightRotation()
    {
        //Definimos la matriz que pasaremos como parámetro con unos números concretos del 1 al 50 5X5
        int[][] auxMatrix ={{1,12,13,14,15},{2,22,23,24,25},{3,32,33,34,35},{4,42,43,44,45},{5,47,48,49,50}};

        //Ahora creamos la matriz y pasamos como parámetro la que ya hemos definido        
        Matriz matriz1 = new Matriz(auxMatrix);
        
        //Comprobamos llamando al metodo test construcor que se ha creado la matriz correctamente
        this.testConstructor();
        
        //Llamámos al método rightRotation y comprobamos que la matriz se ha desplazado 90º hacia la derecha(la primera columna será la ultima
        // fila  y la primera fila será la ultima columna..)       
        matriz1.rightRotation();
        int [][]caso1={{5,4,3,2,1},{47,42,32,22,12},{48,43,33,23,13},{49,44,34,24,14},{50,45,35,25,15}};
        assertArrayEquals(caso1,matriz1.getMatriz());
               
    }

    @Test
    public void testVerticalZigZag()
    {
        //Definimos la matriz que pasaremos como parámetro con unos números concretos del 1 al 50 5X5
        int[][] auxMatrix ={{1,12,13,14,15},{2,22,23,24,25},{3,32,33,34,35},{4,42,43,44,45},{5,47,48,49,50}};

        //Ahora creamos la matriz y pasamos como parámetro la que ya hemos definido        
        Matriz matriz1 = new Matriz(auxMatrix);
        
        //Comprobamos llamando al metodo test construcor que se ha creado la matriz correctamente
        this.testConstructor();
        
        //Llamámos al método verticalZigZag y comprobamos que la matriz ha duplicado las columnas pares y las ha colocado en las impares invertidas       
        matriz1.verticalZigZag();
        
        int [][]caso1={{1,5,13,48,15},{2,4,23,43,25},{3,3,33,33,35},{4,2,43,23,45},{5,1,48,13,50}};
        
        assertArrayEquals(caso1,matriz1.getMatriz());
   
    }
    
    @Test
    public void testHorizontalZigZag()
    {
        //Definimos la matriz que pasaremos como parámetro con unos números concretos del 1 al 50 5X5
        int[][] auxMatrix ={{1,12,13,14,15},{2,22,23,24,25},{3,32,33,34,35},{4,42,43,44,45},{5,47,48,49,50}};

        //Ahora creamos la matriz y pasamos como parámetro la que ya hemos definido        
        Matriz matriz1 = new Matriz(auxMatrix);
        
        //Comprobamos llamando al metodo test construcor que se ha creado la matriz correctamente
        this.testConstructor();
        
        //Llamámos al método horizontalZigZag y comprobamos que la matriz ha duplicado las filas pares y las ha colocado en las impares invertidas
       
        matriz1.horizontalZigZag();
        
        int [][]caso1={{1,12,13,14,15},{15,14,13,12,1},{3,32,33,34,35},{35,34,33,32,3},{5,47,48,49,50}};
        
        assertArrayEquals(caso1,matriz1.getMatriz());
   
        
    }
}



