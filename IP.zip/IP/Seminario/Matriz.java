
/**
 * Class Matriz para seminario de IP.
 * 
 * @author Gema Rico Pozas 
 * @version 29/11/2016
 */
import java.util.Random;
public class Matriz
{
    //Constantes de la clase Matriz
    public final static int MIN_ROWS=0;  //número mínimo de filas
    public final static int MAX_ROWS=20; // número máximo de filas

    public final static int MIN_COLUMNS=0; //número mínimo de columnas
    public final static int MAX_COLUMNS=20; //número máximo de columnas

    public final static int MIN_NUMBER=1; // número mínimo del rango de números aleatorios
    public final static int MAX_NUMBER=50; // número máximo del rango de números aleatorios

    // Propiedades 
    private int [][] matrix; // matriz bidimensional de números enteros

    /**
     * Constructor for objects of class Matriz
     */
    public Matriz(int dimension)
    {
        Random random = new Random();
        if (( dimension < MIN_ROWS ) ||(dimension > MAX_ROWS)) //validamos que los parámetros de la dimensión son válidos
            throw new RuntimeException ("Error: la dimension introducida no es válida");
        matrix = new int [dimension][dimension]; //creamos la matriz con la dimension pasada como parámetro
        for (int i=0; i< matrix.length ; i ++) 
        {
            for (int j=0; j < matrix[i].length ; j++)
            {
                matrix[i][j]=(random.nextInt(MAX_NUMBER) + MIN_NUMBER); //generamos los números aleatorios que ocuparán las posiciones de la matriz (1-50 incluidos)
            }
        }
    }

    /**
     * Constructor for objects of class Matriz for unitJtest
     */
    public Matriz(int [][] matrix) //constructor usado para las pruebas unitarias donde le pasamos una matriz con valores concretos
    {
        if (matrix==null) //validamos que se introduce una matriz
            throw new RuntimeException ("Error: se debe introducir una matriz");
        this.matrix=matrix;
    }

    /**
     * Método que consiste en invertir los elementos de las dos diagonales de la matriz.
     *
     *  // invierte las dos diagonales principales (x) de la matriz. 
     */
    public void reverseDiagonals()
    {
        int cont=(matrix.length-1);         
        int auxMatrix[][]=new int[matrix.length][matrix.length];       
        for (int i=0; i< matrix.length ; i ++)
        {
            for (int j=0; j < matrix[i].length ; j++) //primero cambiamos los valores originales ya invertidos a una matriz auxiliar
            {
                if (j==i) 
                    auxMatrix[i][j] = matrix[cont][cont];                     
                if (j==cont)                
                    auxMatrix[i][j] = matrix[j][i];     
            }             
            cont--;
        } 
        for (int i=0; i< auxMatrix.length ; i ++) // ahora donde haya un "0" significa que dejamos la matriz original y donde haya un valor la cambiamos 
        {
            for (int j=0; j < auxMatrix[i].length ; j++)
            {
                if (auxMatrix[i][j] != 0)
                    matrix[i][j]= auxMatrix[i][j];
            }
        }
    }

    /**
     * Método que consiste en sumar los elementos de cada fila almacenándolos en un vector
     *
     * 
     */
    public int[] vectorSum()
    {
        int sum; //variable local de tipo entero
        int auxMatrix[] = new int [matrix.length]; // vector auxiliar local 
        for (int i=0; i< matrix.length ; i ++)
        {
            sum=0;
            for (int j=0; j < matrix[i].length ; j++)
            {
                sum = matrix[i][j]+ sum;
            }
            auxMatrix[i]=sum;
        }
        return auxMatrix; //devuelve el vector con la suma de cada fila en la fila correspondiente
    }

    /**
     * Método que consiste en intercambiar los elementos de las columnas pares .
     *
     * //intercambiar los elementos de las columnas pares (0-1, 1-2, 2-3, …)
     * 
     */
    public void changeColumns()
    {
        int cont; //variable local de tipo int
        int auxMatrix;  //variable local de tipo int
        for (int i=0; i< matrix.length ; i ++)        
        {   
            cont=1;
            for (int j=0; j < (matrix[i].length -1) ; j++)
            {
                auxMatrix = matrix[i][j];
                matrix[i][j] = matrix[i][j+cont];
                matrix[i][j+cont]= auxMatrix;
            }
        }           
    }

    /**
     * Método que muestra por consola la matriz
     *
     *  @return   Muestra por consola el valor de las diferentes posiciones de la matriz.
     *  con el siguiente formato 
     *     0  1  2  3 ... //indice de columnas y filas
     * 0 [26][5][45][6]
     * 1 [12][6][25][10]     // matriz
     * 2 [1][32][23][50]
     *
     */
    public void print()
    {
        System.out.print("    ");
        for (int i=0; i < matrix.length ; i ++)
        {
            if (i<9)
                System.out.print(i + "    ");  
            else
                System.out.print(i + "   ");
        }
        System.out.println();
        for (int i=0; i< matrix.length ; i ++)
        {  
            if (i<=9)
                System.out.print(i + " ");  
            else
                System.out.print(i + "");
            for (int j=0; j < matrix[i].length ; j++)
            {
                if (matrix[i][j]<=9)
                    System.out.print(" ["+ matrix[i][j]+"] " );
                else
                    System.out.print("["+matrix[i][j]+"] ");  
            }
            System.out.println();       
        }
    }

    /**
     * Método que determina el valor mayor adyacente a una posición pasada como parámetro
     *
     * @param  row/fila
     * @param column/columna
     * @return el valor mayor adyacente
     */
    public int maxAdjacentValue(int row, int column)
    {   
        int max=0;//variable local de tipo entero
        if (( row < MIN_ROWS ) ||(row > MAX_ROWS) || (column< MIN_COLUMNS) || (column > MAX_COLUMNS)) //validamos que los parámetros son correctos
            throw new RuntimeException ("Error: parámetros no válidos");

        for (int i=(row-1); i<=(row+1) ; i ++)        
        {   if (i==-1) 
              i=0;
            if ((i+1)==matrix.length)
              i=(matrix.length-1);
            for (int j=(column -1); j <=(column+1) ; j++)
            { 
                if ((j<matrix.length) && (i<matrix.length))
                {
                    if (j==-1) 
                        j=0;
                    if((j+1)==matrix.length)
                        j=(matrix.length-1);
                    if (matrix[i][j]!= matrix[row][column])
                    {
                        if(matrix[i][j]>max)            
                            max=matrix[i][j];                            
                    }
                }                     
            }
        } 
        return max;
    } 

    /**
     * Método que rota la matriz 90º hacia la derecha
     *     
     * 
     */
    public void rightRotation()
    {
        int auxMatrix[][] = new int [matrix.length][matrix.length]; //matriz auxiliar local
        int cont=(matrix.length-1); //variable local de tipo int
        for (int i=0; i< matrix.length ; i ++)
        {
            for (int j=0; j < matrix[i].length ; j++)
            {               
                auxMatrix[j][cont]= matrix[i][j];                     
            } 
            cont--;
        }
        matrix=auxMatrix;
    }

    /**
     * Método que consiste en duplicar los elementos de las filas pares invirtiendo los elementos
     *     
     * 
     */
    public void horizontalZigZag()
    {
        int auxMatrix[][] = new int [matrix.length][matrix.length]; //matriz auxiliar local
        int cont; //variable local de tipo int
        for (int i=0; i< matrix.length ; i ++)
        {
            if ((i%2==0) && (i<(matrix.length -1)))        
            {   cont=(matrix.length-1);
                for (int j=0; j < matrix[i].length ; j++)
                {
                    matrix[i+1][cont]= matrix[i][j];                  
                    cont--;
                }
               }
            }           
        }    

    /**
     * Método que consiste en duplicar los elementos de las columnas pares invirtiendo los elementos
     *     
     * 
     */
    public void verticalZigZag()
    {
        int auxMatrix[][] = new int [matrix.length][matrix.length]; //matriz auxiliar local
        int cont=matrix.length;    //variable local de tipo int     
        for (int i=0; i< matrix.length ; i ++)
        {
            cont--;
            for (int j=0; j < matrix[i].length ; j++)
            {  
                if ((j%2==0) && (j<(matrix.length -1)))
                {                   
                    matrix[cont][j+1]= matrix[i][j];                    
                }
            }
        }
    }    

    //MÉTODOS PARA LAS PRUEBAS UNITARIAS

    /**
     * Método que devuelve el valor de la posición en la matriz pasada como parámetro
     *
     * @param row//fila
     * @param column//columna
     * @return  valor de la posición en la matriz pasada como parámetro
     */
    public int getValue(int row, int column)
    {
        if (( row <MIN_ROWS ) || (row >= matrix.length) || (column < MIN_COLUMNS) || (column >= matrix[row].length))
            throw new RuntimeException("Error: parametro fuera de rango");
        return matrix[row][column];
    }

    /**
     * Método que devuelve la referencia de la matriz de enteros (suponiendo que el atributo es matriz)
     *
     * 
     * @return la matriz de enteros
     */
    public int[][] getMatriz()
    {
        return matrix;
    }    
}
