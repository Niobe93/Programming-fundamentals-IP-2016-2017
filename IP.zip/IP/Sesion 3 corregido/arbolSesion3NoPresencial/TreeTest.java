
import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class TreeTest.
 *
 * @author  Gema Rico Pozas
 * @version 01/10/2016
 */
public class TreeTest
{
    /**
     * Default constructor for test class TreeTest
     */
    public TreeTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }

    @Test
    public void testSetNumberOfFlowers()
    {
        Tree tree1 = new Tree();

        //PRUEBAS POSITIVAS

        //CASO 1 : cambiar el número de flores con el valor del límite inferior
        tree1.setNumberOfFlowers(0);
        assertEquals(0, tree1.getNumberOfFlowers());

        //CASO 2 : cambiar el número de flores con un valor intermedio
        tree1.setNumberOfFlowers(10);
        assertEquals(10, tree1.getNumberOfFlowers());

        //CASO 3 : cambiar el número de flores con el valor del límite superior
        tree1.setNumberOfFlowers(12);
        assertEquals(12, tree1.getNumberOfFlowers());

        //PRUEBAS NEGATIVAS

        //CASO 4 : cambiar el numero de flores con un valor NEGATIVO
        tree1.setNumberOfFlowers(-3);
        assertEquals(12, tree1.getNumberOfFlowers());

        //CASO 5 : cambiar el número de flores con un valor por encima del límite superior
        tree1.setNumberOfFlowers(13);
        assertEquals(12, tree1.getNumberOfFlowers());
        
    }

    @Test
    public void testWater()
    {
        Tree tree1 = new Tree();

        //PRUEBAS POSITIVAS

        //CASO 1 : cambiar el número de flores y de frutos con un valor intermedio al número máximo de flores.
        tree1.setNumberOfFlowers(5);
        tree1.setNumberOfFruits(5);
        tree1.water();
        assertEquals(4, tree1.getNumberOfFlowers());
        assertEquals(6, tree1.getNumberOfFruits());

        //CASO 2 : cambiar el numero de frutos con un valor superior al límite máximo de flores y las flores con un valor intermedio.
        tree1.setNumberOfFlowers(5);
        tree1.setNumberOfFruits(20);
        tree1.getNumberOfFlowers();
        tree1.water();
        assertEquals(6, tree1.getNumberOfFlowers());
        assertEquals(20, tree1.getNumberOfFruits());

        //PRUEBAS NEGATIVAS

        //CASO 3 : cambiar el numero de frutos y de flores con un valor superior al límite máximo de flores.
        tree1.setNumberOfFlowers(20);
        tree1.setNumberOfFruits(20);
        tree1.water();
        assertEquals(20, tree1.getNumberOfFruits());
        assertEquals(7, tree1.getNumberOfFlowers());

        //CASO 4 : cambiar el numero de frutos con un valor intermedio al límite máximo de flores y las flores con un valor superior al límite de flores.
        tree1.setNumberOfFruits(5);
        tree1.setNumberOfFlowers(20);
        tree1.water();
        assertEquals(6, tree1.getNumberOfFruits());
        assertEquals(6, tree1.getNumberOfFlowers());
        
    }

    @Test
    public void testGatherFruit()
    {
        Tree tree1 = new Tree();

        //PRUEBAS POSITIVAS

        //CASO 1 : cambiar el número de frutos con el valor inferior del rango.
        tree1.setNumberOfFruits(0);
        tree1.gatherFruit();
        assertEquals(0, tree1.getNumberOfFruits());

        //CASO 2 : cambiar el número de frutos con un valor intermedio.
        tree1.setNumberOfFruits(10);
        tree1.gatherFruit();
        assertEquals(9, tree1.getNumberOfFruits());

        //CASO 3 : cambiar el número de frutos con un valor intermedio.
        tree1.setNumberOfFruits(120);
        tree1.gatherFruit();
        assertEquals(119, tree1.getNumberOfFruits());

        //PRUEBAS NEGATIVAS

        //CASO 4 : cambiar el valor de el número de frutas con un valor NEGATIVO
        tree1.setNumberOfFruits(-3);
        tree1.gatherFruit();
        assertEquals(118, tree1.getNumberOfFruits());
        
    }

    @Test
    public void testHarvest()
    {
        Tree tree1 = new Tree();

        //PRUEBAS POSITIVAS

        //CASO 1 : cambiar el número de frutos con el valor inferior del rango.
        tree1.setNumberOfFruits(0);
        assertEquals(0, tree1.harvest());
        assertEquals(0, tree1.getNumberOfFruits());

        //CASO 2 : cambiar el número de frutos con un valor intermedio.
        tree1.setNumberOfFruits(10);
        assertEquals(10, tree1.harvest());
        assertEquals(0, tree1.getNumberOfFruits());

        //CASO 3 : cambiar el número de frutos con un valor intermedio.
        tree1.setNumberOfFruits(120);
        assertEquals(120, tree1.harvest());
        assertEquals(0, tree1.getNumberOfFruits());

        //PRUEBAS NEGATIVAS

        //CASO 4 : cambiar el valor de el número de frutas con un valor NEGATIVO
        tree1.setNumberOfFruits(-3);
        assertEquals(0, tree1.harvest());
        assertEquals(0, tree1.getNumberOfFruits());

    }
}


