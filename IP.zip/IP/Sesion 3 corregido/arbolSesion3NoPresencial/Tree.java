
/**
 * Clase Tree, creado para la sesión 2 del laboratorio de IP.
 * 
 * @author Gema Rico Pozas 
 * @version 01 / 10 / 2016
 */
public class Tree
{
    public final static int MAX_NUMBER_OF_FLOWERS = 12;
    public final static String DEFAULT_TYPE_OF_TREE = "Manzano";
    public final static int DEFAULT_NUMBER_OF_FLOWERS = 7;
    public final static int DEFAULT_NUMBER_OF_FRUITS = 3;

    // Atributos de la clase Tree.
    private int maxNumberOfFlowers;
    private String typeOfTree;
    private int numberOfFlowers;
    private int numberOfFruits;

    /**
     * Constructor for objects of class Tree
     */
    public Tree()

    {            
        // Tipo de árbol
        typeOfTree = DEFAULT_TYPE_OF_TREE;
        // Máximo número de flores      
        // maxNumberOfFlowers = MAX_NUMBER_OF_FLOWERS ;
        //Número de flores
        numberOfFlowers = DEFAULT_NUMBER_OF_FLOWERS ;
        //Número de frutos
        numberOfFruits = DEFAULT_NUMBER_OF_FRUITS;

    }  

    /**
     * Método que devuelve el tipo de árbol de la clase Tree.
     * 
     * 
     * @return tipo de árbol del tipo String.   
     */
    public String getTypeOfTree()
    {
        return typeOfTree;
    }

    /**
     * Método que devuelve el número máximo de flores de la clase Tree.
     * 
     *
     * @return número máximo de flores de tipo int.
     */
    public int getMAX_NUMBER_OF_FLOWERS()
    {
        return maxNumberOfFlowers;
    }

    /**
     * Método que devuelve el número de flores de la clase Tree.
     *
     * 
     * @return el número de flores de tipo int.
     */
    public int getNumberOfFlowers()
    {
        return numberOfFlowers;
    }

    /**
     * Método que devuelve el número de frutos de la clase Tree.
     *
     * 
     * @return el número de frutos de tipo int.
     */
    public int getNumberOfFruits()
    {
        return numberOfFruits; 
    }

    /**
     * Método que modifica el valor del atributo typeOfTree.
     *
     * @param nuevo tipo de arbol, del tipo String.
     * 
     */
    public void setTypeOfTree(String typeOfTree)
    {
        this.typeOfTree = typeOfTree;
    }

    /**
     * Método que modifica el valor del atributo numberOfFlowers.
     *
     * @param nuevo número de flores, del tipo int.
     * 
     */
    public void setNumberOfFlowers(int numberOfFlowers)
    {
        if ((numberOfFlowers <= MAX_NUMBER_OF_FLOWERS)&& (numberOfFlowers >= 0))
            this.numberOfFlowers = numberOfFlowers;
    }

    /**
     * Método que modifica el valor del atributo numberOfFruits.
     *
     * @param nuevo número de frutos, del tipo int
     * 
     */
    public void setNumberOfFruits(int numberOfFruits)
    {
        if ( numberOfFruits >=0 )
            this.numberOfFruits = numberOfFruits;
    }

    /**
     * Método que devuelve una cadena de caracteres.
     *
     * @return una cadena con la representación textual del objeto (estado) 
     */

    public String toString ()

    { 
        return this.getTypeOfTree()+ "-" + this.getMAX_NUMBER_OF_FLOWERS()+  "-"  + this.getNumberOfFlowers()+  "-" + this.getNumberOfFruits();

    }

    /**
     * Método que muestra por pantalla una cadena de caracteres con información del estado de un objeto. 
     *
     * @return una cadena con la representación "valores de las propiedades del árbol"
     */
    public void print ()
    {

        System.out.println( "Valores de las propiedades del árbol : "   +  toString() );
    }

    /**
     * Método que añade una flor cuando se riega si las flores no superan el máximo y, 
     *   añade una fruta y resta una flor si el número de frutas es menor que el máximo de flores.
     * 
     * @par incrementa en uno el numero de flores si las flores no superan el máximo y, 
     *    incrementa una fruta y decrementa una flor si el número de frutas es menor que el máximo de flores
     */
    public void water()
    {
        if (numberOfFlowers < MAX_NUMBER_OF_FLOWERS){
            if (numberOfFruits > MAX_NUMBER_OF_FLOWERS){
                setNumberOfFlowers(getNumberOfFlowers() + 1);
            }
            else
            {
                setNumberOfFruits(getNumberOfFruits() + 1);
                setNumberOfFlowers(getNumberOfFlowers() - 1);

            }
        }
    }

    /**
     * Método que disminuye en uno el numero de frutas y devuelve las restantes.
     *
     * @ return devuelve el número de frutas despues de quitarle una unidad
     */
    public int gatherFruit()
    {
        if (numberOfFruits >= 0)
            setNumberOfFruits(getNumberOfFruits() - 1);
            
        return this.numberOfFruits;
    }

    /**
     * Método que devuelve el número de frutas recogidas y pone a cero el valor del número de frutas
     *
     * @return devuelve el número de frutas recolectadas y devuelve el valor del número de frutas a cero.
     */
    public int harvest()
    {
        int harvestFruits;
        harvestFruits = getNumberOfFruits();        
        setNumberOfFruits(0);
        return harvestFruits;  

    }

   
}

