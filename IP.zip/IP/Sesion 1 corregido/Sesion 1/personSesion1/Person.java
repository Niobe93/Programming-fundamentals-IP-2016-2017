
/**
 * Clase Persons con nombre y edad, diseñada en la sesión 1 de IP
 * 
 * @author Gema Rico Pozas
 * @version 13/09/2016
 */
public class Person
{
    // Atributos de la clase Person (propiedades, características, datos o variables instancia) 
    private String name; 
    private int age;
    private String surname;
    private boolean gender;

    /**
     * Constructor for objects of class Person
     */
    public Person()
    {
       name = "Pepe"; 
       surname = "García";
       age = 18;
       gender = true ;
    }

    /**
     * Método que modifica el valor del nombre de la persona.
     * 
     * @param nuevo nombre para la persona, de tipo String
     *
     */
    public void setName(String newName)
    {
        name = newName;
    }
    
    /**
     * Método que devuelve el valor del atributo name
     *
     * 
     * @return  nombre de la persona, de tipo String
     */
    public String getName()
    {
       
        return name;
    }
    
    /**
     * Método que modifica el valor del apellido de la persona.
     *
     * @param  nuevo apellido para la persona, de tipo String
     * 
     */
    public void setSurname(String newSurname)
    {
        surname = newSurname;
    }
    
    /**
     * Método que devuelve el valor del atributo surname
     *
     * 
     * @return apellido de la persona, del tipo String
     */
    public String getSurname()
    {
        
        return surname;
    }
    

    /**
     * Método que modifica el valor del atributo género de la persona
     *
     * @param  cambio de género, de tipo boolean donde true es hombre y false es mujer.
     * 
     */
    public void setGender( boolean newGender )
    {
        gender = newGender;
        
      
    }
    
    /**
     * Método que devuelve el valor del atributo gender.
     *
     * 
     * @return género de la persona, del tipo boolean donde true es hombre y false es mujer.
     */
    public boolean getGender()
    {
        
        return gender;
    }

    /**
     * Método que modifica el valor del atributo age de la persona.
     *
     * @param  cambio de edad del tipo int.
     * 
     */
    public void setAge (int newAge)
    {
        
        age = newAge;
        
    }

    /**
     * Método que devuelve el valor del atributo Age de la persona.
     *
     * 
     * @return  edad de la persona del tipo int.
     */
    public int getAge()
    {
       
        return age;
    }





    
}
