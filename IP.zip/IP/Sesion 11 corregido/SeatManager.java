
/**
 * Class SeatManager. //Gestor de asientos para manejar las reservas del avión
 * 
 * @author Gema Rico Pozas 
 * @version 23/11/2016
 */

public class SeatManager
{   
    //Constantes
    public final static int DEFAULT_FIRST_ROWS = 3;
    public final static int DEFAULT_STANDARD_ROWS = 4;

    public final static int DEFAULT_COLUMNS=6;

    public final static int MIN_FIRST_ROWS=3;
    public final static int MIN_STANDARD_ROWS=4;

    // instance variables 
    private Person [][] seats;
    private int firstRows;
    private int standardRows;

    /**
     * Constructor for objects of class SeatManager
     */
    public SeatManager()
    {
        setFirstRows(DEFAULT_FIRST_ROWS);
        setStandardRows(DEFAULT_STANDARD_ROWS);  
        seats = new Person [getFirstRows() + getStandardRows()][ DEFAULT_COLUMNS];
    }

    /**
     * Constructor for objects of class SeatManager con parametros
     * 
     * @param el numero de filas en primera
     * @param el numero de filas es standard
     * 
     */    
    public SeatManager(int first, int standard)
    {
        this();
        setFirstRows(first);
        setStandardRows(standard); 
        seats = new Person [getFirstRows() + getStandardRows()][ DEFAULT_COLUMNS];
    }

    /**
     * Asigna el numero de filas en primera
     * 
     * @param  numero de filas en primera de tipo int
     * 
     */
    private void setFirstRows(int rows)
    {
        if ( rows < MIN_FIRST_ROWS ) 
            throw new RuntimeException ("Error: el numero de filas en primera no alcanza el minimo");
        this.firstRows= rows; 
    }

    /**
     * Asigna el numero de filas en standard
     * 
     * @param  numero de filas en turista de tipo int
     * 
     */
    private void setStandardRows(int rows)
    {
        if ( rows < MIN_STANDARD_ROWS ) 
            throw new RuntimeException ("Error: el numero de filas en segunda no alcanza el minimo");
        this.standardRows= rows; 
    }

    /**
     * Método que devuelve el valor de las filas de la pimera fila
     *
     * 
     * @return  numero de filas primera
     */
    public int getFirstRows()
    {
        return firstRows;
    }
    
    /**
     * Método que devuelve el valor de las filas de clase turista
     *
     * 
     * @return  numero de filas turista
     */
    public int getStandardRows()
    {
        return standardRows;
    }

    /**
     * Metodo que reserva un asiento para la persona recibida como parametro 
     * en la fila y columna recibida como parametro
     *
     * @param  persona para la reserva de tipo person
     * @param columna de la matriz
     * @param fila de la matriz
     * 
     * @return True si puede sentarse o false si esta ocupado
     */
    public boolean bookSeat(Person person, int column, int row)
    {
        if ((person == null) || (column < 0) || (column >=DEFAULT_COLUMNS) || ( row <0 ) || (row > seats.length))
            throw new RuntimeException("Error: parametros incorrectos");

        if (seats[row][column]==null)
        {
            seats[row][column]=person; 
            return true;
        }     
        return false;        
    }

    /**
     * libera un asiento cuya fila y columna se recibe como parámetro
     *
     * @param fila
     * @param columna
     * 
     * @return persona que ha dejado el asiento de tipo person
     */
    public Person release(int row,int column)
    {
        if ((column < 0) || (column >=DEFAULT_COLUMNS) || ( row <0 ) || (row > seats.length))
            throw new RuntimeException("Error: parametros fuera de rango");

        Person personToRelease = seats[row][column];
        seats[row][column]= null;
        return  personToRelease;

    }

    /**
     * Metodo que imprime el estado de reservas del avion
     *
     * formato X X X C ? X  donde X es una persona, C es un niño, e ? si no hay nadie
     * 
     * @return     the sum of x and y
     */
    public void print()
    {
        for (int i=0; i< seats[i].length ; i ++)
        {
            if(i==0)
            {
                System.out.print(" ");

            }
            System.out.print(i);        
        }
        System.out.println();
        for (int i=0; i< seats.length ; i ++)
        {  System.out.print(i + ""); 
            for (int j=0; j < seats[i].length ; j++)
            {

                if (seats[i][j] == null )
                    System.out.print( "?");
                else if (seats[i][j].getAge() < 18)
                    System.out.print( "C");
                else
                    System.out.print( "X");  
            }
            System.out.println();         
        }
    }

    /**
     * Metodo que devuelve el numero de asientos libres que hay en la fila pasada como parametro
     * 
     * @param numero de fila que se quiere averiguar cuantos asientos libres quedan
     * @return el numero de asientos libres de la fila pasada como parametro
     */
    public int numberOfFreeSeats (int row)
    {
        int contadorAsientos=0;
        if (( row <0 ) || (row >= seats.length))
            throw new RuntimeException("Error: parametro fuera de rango");
        else 
        {

            for (int j=0; j < seats[row].length ; j++)
            { 
                if (seats[row][j] == null )
                {
                    contadorAsientos= contadorAsientos + 1;

                }
            }

        }
        return contadorAsientos;
    }

    /**
     *  Metodo que devuelve el pasajero de más edad sentado en el avión o null si el avión está vacío.
     *
     * 
     * @return   pasajero de mas edad // null si el avión está vacio
     */
    public Person oldestPassenger ()
    {
        boolean oldest=false;
        Person oldestPassenger= new Person(0);        
        for (int i=0; i< seats.length ; i ++)
        {
            for (int j=0; j < seats[i].length ; j++)
            {  
                if(seats[i][j]!=null)
                {
                    oldest = true;
                    if (oldestPassenger.getAge()< seats[i][j].getAge())                       
                         oldestPassenger=seats[i][j];
                     
                }
            } 
        } 
        if (oldest==false)
           oldestPassenger=null;
        return oldestPassenger;
    }   
    
    
    
    // Metodos para hacer las pruebas
    
    /**
     * Método que devuelve el valor de la persona
     *
     * 
     * @return persona
     */
    public Person getPerson(int column, int row)
    {
        return seats[row][column];
    }
    
}

