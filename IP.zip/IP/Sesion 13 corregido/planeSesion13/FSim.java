
/**
 * Class FSim .
 * 
 * @author Gema Rico Pozas 
 * @version 02/12/2016
 */
import java.util.ArrayList;
public class FSim
{
    private static final String IDS="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    // instance variables 
    private ArrayList<Plane> planes; //almacena objetos de la clase plane
    private char [][] map; //array para emular el mapa del espacio aéreo

    /**
     * Constructor for objects of class FSim
     */
    public FSim()
    {
        map = new char [(Plane.MAX_X_Y +1)][(Plane.MAX_X_Y + 1)];
        planes= new ArrayList();        
    }

    /**
     * Constructor for objects of class FSim with parameters
     */
    public FSim(int planeNumber)
    {
        this();
        if ((planeNumber<=0) || (planeNumber>IDS.length()))
            throw new RuntimeException ("Error: el numero de aviones es erróneo");

        for(int i =0; i< planeNumber; i++)
        {
            planes.add(new Plane(IDS.charAt(i)));
        }

    }
    
    /**
     * Método que añade un avión a la colección
     *
     * @param  plane de la clase Plane
     * 
     */
    public void addPlane(Plane plane)
    {
        if (plane==null)
            throw new RuntimeException ("Error: el avión no existe");
        planes.add(plane);
    }
    
    /**
     * Método que indica si se produce una colisión
     *
     * 
     * @return   
     */
    public boolean simulate()
    {
        this.clearMap();
        for (Plane plane : planes)
        {
           plane.fly();
           if(map[plane.getXPos()][plane.getYPos()] == '.')            
              map[plane.getXPos()][plane.getYPos()] = plane.getIdentifier();           
           else 
            {
             System.out.println("Colisión --> Aviones implicados");
             System.out.println(map[plane.getXPos()][plane.getYPos()]);
             System.out.println(plane.getIdentifier());
             return false;
            }
        }
        paint();
        return true;
    }
    
    /**
     * Metodo que limpia la matriz de caracteres colocando puntos
     *
     * 
     */
    private void clearMap()
    {
     for(int i =0; i< map.length; i++)   
     {
        for(int j =0; j< map[i].length; j++) 
        {
          map[i][j]='.';                  
        }     
     }
    }
    
    /**
     * Metodo que muestra por pantalla la matriz
     *
     * 
     */
    private void paint()
    {
     for(int i =0; i< map.length; i++)   
     {
        System.out.println();
        for(int j =0; j< map[i].length; j++) 
        {
          System.out.print(map[i][j] + " " );                 
        }     
     }
     System.out.println();
     System.out.println();
    }
    




}
