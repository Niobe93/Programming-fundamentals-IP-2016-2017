

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class SeatManagerTest.
 *
 * @author  Gema Rico
 * @version (a version number or a date)
 */
public class SeatManagerTest
{
    /**
     * Default constructor for test class SeatManagerTest
     */
    public SeatManagerTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }
    
    @Test
    public void testConstructor()
    { 
         //PRUEBAS POSITIVAS
        
         //CASO 1 creamos un objeto con 5 filas primera y  y 5 en standard
        
         SeatManager seatManager = new SeatManager(5,5);
         assertEquals(5,seatManager.getStandardRows());
         assertEquals(5,seatManager.getFirstRows());
                  
         //CASO 2 creamos un objeto con 3 filas en primera y 4 en standar (limites del rango)         
         
         SeatManager seatManager3 = new SeatManager(3,4);
         assertEquals(4,seatManager3.getStandardRows());
         assertEquals(3,seatManager3.getFirstRows());
         
         //PRUEBAS NEGATIVAS
        
         //CASO 3 se crea un seatmanager con menos columnas en turista del minimo establecido
        
         try 
         {
           SeatManager seatManager1 = new SeatManager(5,0);
         }
         catch (Exception ex)
         {
            assertEquals("Error: el numero de filas en segunda no alcanza el minimo", ex.getMessage());
         }
        
        
         //CASO 4 se crea un seatmanager con menos columnas en primera del minimo establecido
        
         try 
         {
           SeatManager seatManager2 = new SeatManager(0,5);
         }
         catch (Exception ex)
         {
            assertEquals("Error: el numero de filas en primera no alcanza el minimo", ex.getMessage());
         }
         
    }    

    @Test
    public void testOldestPassenger()
    {
        //PRUEBAS POSITIVAS
        
        //CASO 1 creamos un objeto seatManager y creamos 3 personas de diferentes edades
        SeatManager seatManager = new SeatManager();
        Person person1= new Person(18);
        Person person2= new Person(45);
        Person person3= new Person(29);
        
        // asignamos un asiento a cada persona con el metod bookseat y comprobamos que se pueden sentar
        assertEquals(true, seatManager.bookSeat(person1, 1, 2));
        assertEquals(true, seatManager.bookSeat(person2, 4, 2));
        assertEquals(true, seatManager.bookSeat(person3, 3, 4)); 
        
        //Llamamos al metodo OLDESTPASSENGER y comprobamos que nos devuelve la persona de mayor edad
        assertEquals(seatManager.getPerson(4,2),seatManager.oldestPassenger());
        
        //creamos otras tres personas mas con diferentes edades
        Person person4= new Person(21);
        Person person5= new Person(39);
        Person person6= new Person(69);
        
        //asignamos un asiento a cada persona con el metod bookseat y comprobamos que se pueden sentar
        assertEquals(true, seatManager.bookSeat(person4, 2, 1));
        assertEquals(true, seatManager.bookSeat(person5, 2, 4));
        assertEquals(true, seatManager.bookSeat(person6, 4, 3));   
        
        //Llamamos al metodo OLDESTPASSENGER y comprobamos que nos devuelve la persona de mayor edad
        assertEquals(seatManager.getPerson(4,3),seatManager.oldestPassenger());
        
        
        //CASO 2 creamos un objeto seatManager y lo dejamos sin pasajeros, asi nos tendra que devolver null
        SeatManager seatManager1 = new SeatManager();
        assertEquals(null,seatManager1.oldestPassenger());
        
        
        
    }

    @Test
    public void testNumberOfFreeSeats()
    {
        //PRUEBAS POSITIVAS
        
        //CASO 1 creamos un objeto seatManager y 2 objeto persona        
        SeatManager seatMana1 = new SeatManager();
        Person person1 = new Person();
        Person person2 = new Person();
        
        //Asignamos un asiento a la persona en la fila 4
        assertEquals(true, seatMana1.bookSeat(person1, 5, 4));
        //Comprobamos que el numero de asientos de la fila 4 (6) ha descendido en una unidad al haberse sentado una persona (5)
        assertEquals(5, seatMana1.numberOfFreeSeats(4));
        
        //Asignamos un asiento a la persona en la fila 4 
        assertEquals(true, seatMana1.bookSeat(person2, 1, 4));
        //Comprobamos que el numero de asientos de la fila 4 (5) ha descendido OTRA una unidad al haberse sentado otra persona (4)
        assertEquals(4, seatMana1.numberOfFreeSeats(4));
        
        //Comprobamos que el resto de filas tienen todos los asientos libres (6)
        assertEquals(6, seatMana1.numberOfFreeSeats(0));
        assertEquals(6, seatMana1.numberOfFreeSeats(1));
        assertEquals(6, seatMana1.numberOfFreeSeats(2));
        assertEquals(6, seatMana1.numberOfFreeSeats(3));
        assertEquals(6, seatMana1.numberOfFreeSeats(5));
        assertEquals(6, seatMana1.numberOfFreeSeats(6));
        
        
        //PRUEBAS NEGATIVAS
        
        //Intentamos llamar al metodo con un numero de fila erroneo
         try 
        {
           seatMana1.numberOfFreeSeats(7);
        }
        catch (Exception ex)
        {
            assertEquals("Error: parametro fuera de rango", ex.getMessage());
        }
        
    }

    @Test
    public void testRelease()
    {
        //PRUEBAS POSITIVAS
        
        //CASO 1 creamos un objeto seatManager y  varias personas a las que con el metodo bookSeat iremos asignando un asiento comprobando que se pueden sentar
        SeatManager seatManager = new SeatManager();
        
        Person person1 = new Person();
        assertEquals(true, seatManager.bookSeat(person1, 0, 2));
        
        Person person2 = new Person();
        assertEquals(true, seatManager.bookSeat(person2, 3, 5));
        
        Person person3 = new Person();
        assertEquals(true, seatManager.bookSeat(person3, 3, 0));
        
        Person person4 = new Person();
        assertEquals(true, seatManager.bookSeat(person4, 1, 1));        
        
        Person person5 = new Person();
        assertEquals(true, seatManager.bookSeat(person5, 5, 3));
        
        //LLamamos al metodo release y eliminamos a las persona que hemos sentado antes 
        assertEquals(seatManager.getPerson(3,5), seatManager.release(5, 3));        
        //Comprobamos que la persona ya no esta sentada y que nos devuelve un null
        assertEquals(null,seatManager.getPerson(3,5));
        
        //LLamamos al metodo release y eliminamos a las persona que hemos sentado antes 
        assertEquals(seatManager.getPerson(1,1), seatManager.release(1, 1));
        //Comprobamos que la persona ya no esta sentada y que nos devuelve un null
        assertEquals(null,seatManager.getPerson(1,1));
        
        //LLamamos al metodo release y eliminamos a las persona que hemos sentado antes 
        assertEquals(seatManager.getPerson(0,3), seatManager.release(3, 0));
        //Comprobamos que la persona ya no esta sentada y que nos devuelve un null
        assertEquals(null,seatManager.getPerson(0,3));
        
        //LLamamos al metodo release y eliminamos a las persona que hemos sentado antes 
        assertEquals(seatManager.getPerson(5,3), seatManager.release(3, 5));
        //Comprobamos que la persona ya no esta sentada y que nos devuelve un null
        assertEquals(null,seatManager.getPerson(5,3));
        
        //LLamamos al metodo release y eliminamos a las persona que hemos sentado antes 
        assertEquals(seatManager.getPerson(2,0), seatManager.release(0, 2));
        //Comprobamos que la persona ya no esta sentada y que nos devuelve un null
        assertEquals(null,seatManager.getPerson(2,0));
        
        
        //LLamamos al metodo release en una posicion de fila/columna vacia y comprobamos que al no haber nadie devuelve null
        assertEquals(null,seatManager.release(4,2));
        //LLamamos al metodo release en una posicion de fila/columna vacia y comprobamos que al no haber nadie devuelve null
        assertEquals(null,seatManager.release(5,5));
        
        
        //PRUEBAS NEGATIVAS
        
        //CASO 3 Llamamos al metodo release con una posicion de fila y de columna erronea por encima del limite
         try 
        {
           seatManager.release(7,6);
        }
        catch (Exception ex)
        {
            assertEquals("Error: parametros fuera de rango", ex.getMessage());
        }
        
        // CASO 4 Llamamos al metodo release con una posicion de fila y de columna erronea por debajo del limite
         try 
        {
           seatManager.release(-1,-1);
        }
        catch (Exception ex)
        {
            assertEquals("Error: parametros fuera de rango", ex.getMessage());
        }
        
    }

    @Test
    public void testBookSeat()
    {
        //PRUEBAS POSITIVAS 
        
        //CASO 1 creamos un objeto seatManager
        SeatManager seatManager = new SeatManager();
        
        //creamos a una persona y la sentamos con el metodo bookSeat comprobando que se le ha asignado el asiento correctamente
        Person person1 = new Person();
        assertEquals(true, seatManager.bookSeat(person1, 0, 2));
        assertNotNull(seatManager.getPerson(0,2));
        
        //creamos a una persona y la sentamos con el metodo bookSeat comprobando que se le ha asignado el asiento correctamente
        Person person2 = new Person();
        assertEquals(true, seatManager.bookSeat(person2, 3, 5));
        assertNotNull(seatManager.getPerson(3,5));
        
        //creamos a una persona y la sentamos con el metodo bookSeat comprobando que se le ha asignado el asiento correctamente
        Person person3 = new Person();
        assertEquals(true, seatManager.bookSeat(person3, 3, 0));
        assertNotNull(seatManager.getPerson(3,0));
        
        //creamos a una persona y la sentamos con el metodo bookSeat comprobando que se le ha asignado el asiento correctamente
        Person person4 = new Person();
        assertEquals(true, seatManager.bookSeat(person4, 1, 1));
        assertNotNull(seatManager.getPerson(1,1));
        
        //creamos a una persona y la sentamos con el metodo bookSeat comprobando que se le ha asignado el asiento correctamente
        Person person5 = new Person();
        assertEquals(true, seatManager.bookSeat(person5, 5, 3));
        assertNotNull(seatManager.getPerson(5,3));
        
        
        //PRUEBAS NEGATVAS
        
        //CASO 1 creamos a una persona y la intentamos sentar en un sitio ocupado, pero no nos deja y nos devuelve false
        Person person6 = new Person();
        assertEquals(false, seatManager.bookSeat(person6, 5, 3));
        
        // CASO 2 Llamamos al metodo bookSeat con una posicion de fila y de columna erronea por encima del limite
        try 
        {
           seatManager.bookSeat(person1,7,6);
        }
        catch (Exception ex)
        {
            assertEquals("Error: parametros incorrectos", ex.getMessage());
        }
        
        // CASO 3 Llamamos al metodo bookSeat con una posicion de fila y de columna correcta pero sin asignar una persona
         try 
        {
           seatManager.bookSeat(null,0,1);
        }
        catch (Exception ex)
        {
            assertEquals("Error: parametros incorrectos", ex.getMessage());
        }
        
        // CASO 4 Llamamos al metodo bookSeat con una posicion de fila correcta y de columna erronea por encima del limite
         try 
        {
           seatManager.bookSeat(person1,0,-5);
        }
        catch (Exception ex)
        {
            assertEquals("Error: parametros incorrectos", ex.getMessage());
        }
        
        // CASO 5 Llamamos al metodo bookSeat con una posicion de columna correcta pero de fila erronea  
         try 
        {
           seatManager.bookSeat(person1,-1,0);
        }
        catch (Exception ex)
        {
            assertEquals("Error: parametros incorrectos", ex.getMessage());
        }
    }

    @Test
    public void testGetSize()
    {
        //CASO 1 creamos un objeto seatManager con ningun pasajero sentado
        SeatManager seatMana1 = new SeatManager();
        
        //llamamos al método getSize y comprobamos que no hay ningun pasajero sentado
        assertEquals(0, seatMana1.getSize());
        
        //CASO 2 creamos un objeto persona y lo sentamos. 
        Person person1 = new Person();
        assertEquals(true, seatMana1.bookSeat(person1, 4, 2));
        
        //llamamos al metodo getSize y comprobamos que nos devuelve 1 persona sentada
        assertEquals(1, seatMana1.getSize());
        
        //CASO 3 sentamos a varias personas y comprobamos que se ha aumentado el numero llamando al metodo get size               
        assertEquals(true, seatMana1.bookSeat(person1, 5, 3));
        assertEquals(true, seatMana1.bookSeat(person1, 3, 3));
        assertEquals(true, seatMana1.bookSeat(person1, 2, 3));
        assertEquals(true, seatMana1.bookSeat(person1, 0, 3));
        
        //y comprobamos que se ha aumentado el numero llamando al metodo get size 
        assertEquals(5, seatMana1.getSize());
        
        //CASO 4 eliminamos un pasajero y comprobamos que se reduce en una unidad llamando al metodo getSize
        assertEquals(seatMana1.getPerson(3,3), seatMana1.release(3, 3));
        assertEquals(4, seatMana1.getSize());  
                        
    }
    
    @Test
    public void testGetYoungPeople()
    {
      //PRUEBAS POSITIVAS
        
      //CASO 1 creamos un objeto seatManager y creamos varias personas de diferentes edades
      SeatManager seatManager = new SeatManager();
      Person person1= new Person(18);
      Person person2= new Person(45);
      Person person3= new Person(29);
      Person person4= new Person(25);
      Person person5= new Person(25);
      Person person6= new Person(50);
        
      // asignamos un asiento a cada persona con el metod bookseat y comprobamos que se pueden sentar
      assertEquals(true, seatManager.bookSeat(person1, 1, 2));
      assertEquals(true, seatManager.bookSeat(person2, 4, 2));
      assertEquals(true, seatManager.bookSeat(person3, 3, 4));
      assertEquals(true, seatManager.bookSeat(person3, 3, 4)); 
      assertEquals(true, seatManager.bookSeat(person3, 3, 4)); 
      
      //Llamamos al método getYoungPeople y comprobamos que nos devuelve un arrayList con las personas de menor edad 
        
         assertEquals( 2 , seatManager.getYoungestPeople().size());
         
          assertEquals( 25 , seatManager.getYoungestPeople().get(0).getAge());
        
        
        
        
        
    }
}






