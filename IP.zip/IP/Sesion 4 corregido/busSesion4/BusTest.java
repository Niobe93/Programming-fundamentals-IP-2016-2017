
import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class BusTest.
 *
 * @author  Gema Rico Pozas
 * @version 04/10/2016
 */
public class BusTest
{
    /**
     * Default constructor for test class BusTest
     */
    public BusTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }


    @Test
    public void testSetDriverPresent()
    {
        Bus bus1 = new Bus();

        //CASO 1 : cambiar el valor boolean a true.
        bus1.setDriverPresent(true);
        assertEquals(true, bus1.getDriverPresent());

        //CASO 2 : cambiar el valor boolean a false.
        bus1.setDriverPresent(false);
        assertEquals(false, bus1.getDriverPresent());
    }

    @Test
    public void testSetAvailableSeats()
    {
        Bus bus1 = new Bus();  
        
        //PRUEBAS POSITIVAS

        //CASO 1:  crear el objeto con valor superior límite
        assertEquals(60, bus1.getAvailableSeats());
        
        //CASO 2: cambiar los asientos disponibles al valor inferior del rango
        bus1.setAvailableSeats(0);
        assertEquals(0, bus1.getAvailableSeats());
        
        //CASO 3: cambiar los asientos disponibles a un valor intermedio
        bus1.setAvailableSeats(20);
        assertEquals(20, bus1.getAvailableSeats());
        
        //CASO 4: cambiar los asientos disponibles a un valor intermedio
        bus1.setAvailableSeats(50);
        assertEquals(50, bus1.getAvailableSeats());
        
        //PRUEBAS NEGATIVAS
        
        //CASO 5: cambiar los asientos disponibles a un valor superior al limite 
        bus1.setAvailableSeats(70);
        assertEquals(50, bus1.getAvailableSeats());
        
        //CASO 6: cambiar los asientos disponibles a un valor negativo
        bus1.setAvailableSeats(-3);
        assertEquals(50, bus1.getAvailableSeats());
    }

    @Test
    public void testGetDriverPresent()
    {
        
        //CASO 1: crear un objeto bus con un conductor no presente (false)
        Bus bus1 = new Bus();
        assertEquals(false, bus1.getDriverPresent());
        
        //CASO 2: cambiar el valor boolean a true para el conductor presente        
        bus1.setDriverPresent(true);
        assertEquals(true, bus1.getDriverPresent());
    }

    @Test
    public void testSitDriver()
    {
        // CASO 1 : crear un objeto bus y sentar al conductor que por defecto no está presente
        Bus bus1 = new Bus();
        bus1.sitDriver();
        assertEquals(true, bus1.getDriverPresent());
    }

    @Test
    public void testGetOn()
    {
        
        //CASO 1 : crear un objeto bus donde por defecto hay 60 sitios disponibles, no hay conductor y subimos a 25 personas
        Bus bus1 = new Bus();
        assertEquals(false, bus1.getOn(25));
        
        //CASO 2 : hacer el conductor presente (true) y subir a 25 personas. 
        bus1.setDriverPresent(true);
        assertEquals(true, bus1.getOn(25));
        assertEquals(35, bus1.getAvailableSeats());
    }

    @Test
    public void testToString()
    {
        //CASO 1: crear un objeto bus sin el conductor presente (false)
        Bus bus1 = new Bus();
        assertEquals("OUT OF SERVICE-60", bus1.toString());
        
        //CASO 2: hacer el conductor presente (true).
        bus1.sitDriver();
        assertEquals("ON DUTY-60", bus1.toString());
        
        //CASO 3: con el conductor presente subir a 25 personas, nos devuelve el numero de asientos libres
        assertEquals(true, bus1.getOn(25));
        assertEquals("ON DUTY-35", bus1.toString());
    }
}




