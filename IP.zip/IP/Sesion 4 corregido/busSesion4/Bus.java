
/**
 * Clase Bus creada para la sesión 4 del laboratorio IP.
 * 
 * @author Gema Rico Pozas 
 * @version 04/10/2016
 */
public class Bus
{
    //Constantes de la clase Bus 
    public final static int MAX_AVAILABLE_SEATS=60;
    public final static int MIN_AVAILABLE_SEATS=0;

    // Atributos de la clase Bus
    private boolean driverPresent; //true indica que el conductor está presente, false indica que no está el conductor
    private int availableSeats; //número de asientos libres del autobús

    /**
     * Constructor for objects of class Bus sin parámetros
     */
    public Bus()
    {
        driverPresent = false;
        availableSeats = MAX_AVAILABLE_SEATS;
    }

    /**
     * Constructor for objects of class Bus
     */
    public Bus(boolean driverPresent,int availableSeats)
    {
        this();
        setDriverPresent(driverPresent);
        setAvailableSeats(availableSeats);       
    }

    /**
     * Método que devuelve el valor del atributo driverPresent
     * 
     * 
     * @return devuelve si el conductor está presente (true) o si no está (false)
     */
    public boolean getDriverPresent()
    {
        return driverPresent;
    }

    /**
     * Método que devuelve el valor del atributo availableSeats
     * 
     * 
     * @return devuelve el número de asientos libres en el autobús
     */
    public int getAvailableSeats()
    {
        return availableSeats ;
    }

    /**
     *  Método que modifica el valor del atributo driverPresent
     *
     * @param modifica el valor del atributo que indica si el conductor está presente
     * 
     */
    public void setDriverPresent (boolean driverPresent)
    {
        this.driverPresent = driverPresent;
    }

    /**
     *  Método que modifica el valor del atributo availableSeats
     *
     * @param modifica el valor del atributo que indica cuantos asientos libres hay en el bus
     * 
     */
    public void setAvailableSeats (int availableSeats)
    {
        if ((availableSeats >= MIN_AVAILABLE_SEATS) && (availableSeats <=MAX_AVAILABLE_SEATS))
        this.availableSeats = availableSeats;
    }

    /**
     *  Método que modifica la presencia del conductor en el bus
     *
     * @param modifica el valor del atributo driverPresent a true 
     * 
     */
    public void sitDriver ()
    {
        this.driverPresent = true;
    }

    /**
     *  Método que asigna asientos libres a los pasajeros e informa de la presencia del conductor.
     *
     * @param recibe el número de personas que quieren subirse al bus. Si el conductor está y hay sitios libres para los pasajeros devuelve true y decrementa el 
     * número de asientos correspondientes. De lo contrario devuelve false.
     * 
     */
    public boolean getOn (int numberOfPassagers)
    {
        if (( driverPresent == true) &&( availableSeats <= MAX_AVAILABLE_SEATS))

        { 
            setAvailableSeats(getAvailableSeats() - numberOfPassagers);
            return true;
        }
        else
        {
            return false;
        }

    }

    /**
     * Método que devuelve la información sobre el estado del autobus.
     *
     * 
     * @return devuelve: si el conductor está presente "ON DUTY" y el número libre de asientos, y si no está "OUT OF SERVICE" y el número de asientos libres
     */

    public String toString()
    {
        if ( getDriverPresent() == true )

            return ("ON DUTY" + "-" + this.getAvailableSeats());

        else
            return ("OUT OF SERVICE" + "-" + this.getAvailableSeats());
    }
}
