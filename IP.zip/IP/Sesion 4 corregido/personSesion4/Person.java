
/**
 * Clase Persons con nombre y edad, diseñada en la sesión 2 de IP
 * 
 * @author Gema Rico Pozas
 * @version 20/09/2016
 */
public class Person
{
    public final static int MIN_AGE = 0;
    public final static int MAX_AGE = 120;
    public final static int ADULTHOOD_AGE = 18;
    public final static int RETIREMENT_AGE = 65;
    public final static boolean GENDER_FEMALE = false;
    public final static boolean GENDER_MALE = true;

    // Atributos de la clase Person (propiedades, características, datos o variables instancia) 
    private String name; 
    private int age;
    private String surname;
    private boolean gender;      // true indicará Masculino, false Femenino

    /**
     * Constructor for objects of class Person
     */
    public Person()
    {
        setName("Pepe");
        setSurname("García");
        setAge (18);
        setGender (true );
    }

    /**
     * Constructor for objects of class Person
     */
    public Person(int age)
    {
        this();
        setAge (age);        
    }

    /**
     * Método que modifica el valor del nombre de la persona.
     * 
     * @param nuevo nombre para la persona, de tipo String
     *
     */
    public void setName(String name)
    {
        this.name = name;
    }

    /**
     * Método que devuelve el valor del atributo name
     *
     * 
     * @return  nombre de la persona, de tipo String
     */
    public String getName()
    {

        return name;
    }

    /**
     * Método que modifica el valor del apellido de la persona.
     *
     * @param  nuevo apellido para la persona, de tipo String
     * 
     */
    public void setSurname(String surname)
    {
        this.surname = surname;
    }

    /**
     * Método que devuelve el valor del atributo surname
     *
     * 
     * @return apellido de la persona, del tipo String
     */
    public String getSurname()
    {

        return surname;
    }

    /**
     * Método que modifica el valor del atributo género de la persona
     *
     * @param  cambio de género, de tipo boolean donde true es masculino y false es femenino.
     * 
     */
    public void setGender( boolean gender )
    {
        this.gender = gender;

    }

    /**
     * Método que devuelve el valor del atributo gender.
     *
     * 
     * @return género de la persona, del tipo boolean donde true es masculino y false es femenino.
     */
    public boolean getGender()
    {
        return gender;
    }

    /**
     * Método que modifica el valor del atributo age de la persona.
     *
     * @param  cambio de edad del tipo int, DEBE ser mayor que 0.
     * 
     */
    public void setAge (int age)
    {

        if ((age >= MIN_AGE) && (age < MAX_AGE))
            this.age = age;

    }

    /**
     * Método que devuelve el valor del atributo Age de la persona.
     *
     * 
     * @return  edad de la persona del tipo int.
     */
    public int getAge()
    {

        return age;
    }

    /**
     * Método que muestra por pantalla (salida estándar) una cadena de caracteres con información del estado de un objeto. 
     *
     */
    public void print ()
    {
        //        System.out.println(" Mi edad es " + getAge() + " pero el año que viene tendré " + (getAge() + 1) + " años ");

        System.out.println(toString());
    }

    /**
     * Método que devuelve una cadena de caracteres.
     *
     * @return una cadena con la representación textual del objeto (estado) 
     */

    public String toString ()

    { 
        return " Edad: " + this.getAge() + " Nombre: " + this.getName() + " Apellidos: " + this.getSurname() + " Género: " + this.getGender();

    }

    /**
     * Método que devuelve los años que le quedan a la persona para alcanzar diferentes etapas.
     *
     * @return devuelve según la edad : si es menor de edad devuelve los años hasta la mayoría de edad (18); si es adulto, los años que le faltan hasta
    la edad de jubilación (65); y si está jubilado los años transcurridos desde la edad de jubilación.
     */

    public int getCriticalAge()     

    { 

        { if (getAge () < ADULTHOOD_AGE) 
                return (ADULTHOOD_AGE - getAge ());       

            else if (getAge () < RETIREMENT_AGE)
                return (RETIREMENT_AGE - getAge ());

            else 
                return (getAge () - RETIREMENT_AGE);
        } 

    }

    /**
     * Método que devuelve si el género es femenino.
     *
     * @return devuelve el valor del atributo género femenino
     */

    public boolean isGirl ()

    {
        if (getGender() == GENDER_FEMALE )
            return true;
        else 
            return false;
    }

    //     /**
    //      * Método que devuelve una cadena de carácteres.
    //      *
    //      * 
    //      * @return  una cadena con la representación en mayúsculas de el nombre y el apellido y la longitud de ambos y la edad de la persona.
    //      */
    //     public String getHashCode()
    //     {
    // 
    //         return this.getAge() + "-" + this.name.toUpperCase() + "-" + this.name.length() + "-" +  this.surname.toUpperCase() + "-" + this.surname.length();
    //     }

    /**
     * Método que devuelve una cadena de carácteres.
     *
     * @return  una cadena con la representación en mayúsculas de el nombre y el apellido y la longitud de ambos y la edad de la persona
     */
    public String getHashCode()
    {

        return this.getAge() + "-" + this.getName().substring(0,2).toUpperCase() + "-"  +  this.getSurname().substring(0,4).toUpperCase() + "-" + this.getState();
    }

    private String getState()
    { 
        if (getAge () < ADULTHOOD_AGE) 
            return "CHILD";
        else if (getAge () < RETIREMENT_AGE)
            return "ADULT";
        else 
            return "RETIRED";

    }
}
