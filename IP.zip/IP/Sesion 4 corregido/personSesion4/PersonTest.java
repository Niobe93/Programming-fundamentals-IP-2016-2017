
import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class PersonTest.
 *
 * @author  Gema Rico Pozas
 * @version 01/10/2016
 */
public class PersonTest
{
    /**
     * Default constructor for test class PersonTest
     */
    public PersonTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }

    @Test
    public void testSetAge()
    {
        Person person1 = new Person();
        assertEquals(18, person1.getAge());

        //PRUEBAS POSITIVAS
        
        //CASO 1: Cambiar edad con un valor intermedio
        person1.setAge(60);
        assertEquals(60, person1.getAge());

        //CASO 2: Cambio edad con el valor inferior del rango
        person1.setAge(Person.MIN_AGE);
        assertEquals(Person.MIN_AGE, person1.getAge());

        //CASO 3: Cambio edad con el valor superior del rango
        person1.setAge(Person.MAX_AGE-1);
        assertEquals(Person.MAX_AGE-1, person1.getAge());

        //PRUEBAS NEGATIVAS
        
        //CASO 4: Cambio edad con un valor NEGATIVO
        person1.setAge(-10);
        assertEquals(119, person1.getAge());

        //CASO 5: Cambio edad con un valor mayor del límite superior
        person1.setAge(120);
        assertEquals(119, person1.getAge());
    }

    @Test
    public void testGetCriticalAge()
    {
        Person person1 = new Person();
        assertEquals(47, person1.getCriticalAge());
        
        //PRUEBAS POSITIVAS
        
        //CASO 1: Cambio edad con el valor del límite inferior
        person1.setAge(0);
        assertEquals(18, person1.getCriticalAge());
        
        //CASO 2: Cambio edad con un valor intermedio de la edad adulta
        person1.setAge(50);
        assertEquals(15, person1.getCriticalAge());
        
        //CASO 3: Cambio edad con el valor de jubilación
        person1.setAge(65);
        assertEquals(0, person1.getCriticalAge());
        
        //CASO 4: Cambio edad con un valor mayor de la edad de jubilación
        person1.setAge(85);
        assertEquals(20, person1.getCriticalAge());
        
       
    }

//     @Test
//     public void testGetHashCode()
//     {
//         Person person1 = new Person();
//         assertEquals("18-PEPE-4-GARCÍA-6", person1.getHashCode());
//         
// PRUEBAS POSITIVAS
//         
// CASO 1: Cambio de edad a un valor intermedio, cambio de nombre y de apellido
//         person1.setAge(50);
//         person1.setName("Gema");        
//         person1.setSurname("Rico");
//         assertEquals("50-GEMA-4-RICO-4", person1.getHashCode());
//        
// CASO 2 : Cambio de edad con el valor del límite inferior
//         person1.setAge(0);
//         assertEquals("0-GEMA-4-RICO-4", person1.getHashCode());
//         
// PRUEBAS NEGATIVAS
//         
// CASO 3 : Cambio de edad con un valor del límite superior
//         person1.setAge(120);
//         assertEquals("50-GEMA-4-RICO-4", person1.getHashCode());
//         
// CASO 4 : Cambio de edad con un valor NEGATIVO
//         person1.setAge(-3);
//         assertEquals("0-GEMA-4-RICO-4", person1.getHashCode());
//     }

    

    @Test
    public void testGetHashCode()
    {
        Person person1 = new Person();
        
        //CASO 1: cambio edad con un valor correspondiente a menoría de edad y cambio de nombre y apellido.
        person1.setAge(0);
        person1.setName("Gema");
        person1.setSurname("Fernández");
        assertEquals("0-GE-FERN-CHILD", person1.getHashCode());
        
        //CASO 2: cambio de edad con un valor correspondiente a la edad adulta
        person1.setAge(40);
        assertEquals("40-GE-FERN-ADULT", person1.getHashCode());
        
        //CASO 3: cambio de edad con el valor de jubilación.
        person1.setAge(65);
        assertEquals("65-GE-FERN-RETIRED", person1.getHashCode());
        
        //CASO 4: cambio de edad con el valor de mayoría de edad.
        person1.setAge(18);
        assertEquals("18-GE-FERN-ADULT", person1.getHashCode());
    }
}





