
/**
 *  class WheelStrut para laboratorio deIP.
 * 
 * @author Gema Rico Pozas
 * @version 25/10/2016
 */

public class WheelStrut
{
    public final static double  DEFAULT_PREASSURE_BOEING_737=1739;
    public final static boolean IS_DEPLOYED=true; //esta desplegado
    public final static boolean IS_RETRACTED=false;// esta retraido
    // instance variables 
    private  Wheel[] wheels; //coleccion de ruedas
    private boolean deployed; // puntal 

    /**
     * Constructor for objects of class WheelStrut
     */
    public WheelStrut()
    {
        this(2);

    }

    /**
     * Constructor for objects of class WheelStrut con parámetros
     * 
     * @param numero de ruedas que queremos para el puntal
     * 
     */

    public WheelStrut(int numberWheels)
    {
       if( numberWheels <= 0)
         throw new RuntimeException("Error: el parámetro es negativo o cero");
        deployed=IS_DEPLOYED;
        setWheels(numberWheels);             

    }
    
    /**
     * Método que añade el numero de ruedas a la colección 
     *
     * @param numero de ruedas que queremos para el puntal
     * 
     */
    private void setWheels(int numberWheels)
    {
       wheels = new Wheel[numberWheels];
        for(int i =0; i< numberWheels; i++)
       {
         wheels[i] = new Wheel(DEFAULT_PREASSURE_BOEING_737,DEFAULT_PREASSURE_BOEING_737);
       }
    }

    /**
     * Método que devuelve el valor del atributo deployed
     *
     * @return devuelve el valor del atributo is deployed
     */
    public boolean isDeployed()
    { 
        return deployed ;
    }    

    /**
     * Método test que devuelve true si ambas ruedas pasan el test y false si no lo pasan
     *
     * 
     * @return true si todas las ruedas pasan el test y false si no lo pasan
     */
    public boolean test()
    {
        for(Wheel wheel : wheels)
        {
            if (!wheel.test())
             return false;
        }
        return true;
    }

    /**
     * Método toString que devuelve el estado del puntal
     *
     * 
     * @return devuelve el estado puntual del puntal con el siguiente formato :
     *      Deployed: true - Test: true [Wheel 1: true]
     */
    public String toString()
    {
        String string = ("Deployed:" + this.isDeployed() + "-" + "Test:" + this.test());
        for(int i =0; i< wheels.length; i++)
        {
             string += "[Wheel:" + (i+1) + wheels[i].test()+ "]";
        }
        return string;
    }    

    /**
     * Método que muestra por pantalla el estado del objeto de la clase WheelStrut
     *
     * @return El valor de la propiedad deployed
     *         El valor de retorno del método test()
     *         El resultado de la ejecución del método print() sobre cada rueda
     */
    public void print ()
    {
        if ( this.isDeployed() == true)
            System.out.println("DEPLOYED");  
        else if (this.isDeployed() == false)
            System.out.println("RETRACTED");
            
        if (this.test() == true)
            System.out.println("Test.......... OK");
        else if(this.test() == false)
            System.out.println("Test.......... FAIL");    
          
        for(int i =0; i< wheels.length; i++)
        {
            System.out.println( " Wheel " + (i+1));
            wheels[i].print();
            System.out.println();
        }
        
    }
    
    /**
     *  Método que modifica el valor del atributo DEPLOYED
     *  
     * @param cambia el valor del atributo deployed del tipo boolean
     * 
     */
    private void setDeployed (boolean deployed)
    {
        this.deployed = deployed;
    }
    
    /**
     * Método que cambia el valor del puntal a retracted
     *
     * @param  cambia el valor del puntal a retracted, false
     * 
     */
    public void retract()
    {
        this.setDeployed(IS_RETRACTED);
    }
    
    /**
     * Método que cambia el valor del puntal a deployed
     *
     * @param cambia el valor del puntal a deployed, true
     * 
     */
    public void deployed()
    {
        setDeployed(IS_DEPLOYED);
    }
    
    //Metodos para las pruebas unitarias
    
    /**
     * Método que devuelve el tamaño de la colección
     *
     * 
     * @return  tamaño de la colección
     */
    public int getSize()
    {
        return wheels.length;
    }
    
    /**
     * Método que devuelve la posición de la colección
     *
     * 
     * @return  el objeto que está en la posicion index
     */
    public Wheel getWheels(int index)
    {
        return wheels[index];
    }


}
   
    
    
    
    
    
    
    
    
    
    
