

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class ConcertTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class ConcertTest
{
    /**
     * Default constructor for test class ConcertTest
     */
    public ConcertTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }

    @Test
    public void testConstructor()
    {
        //creamos un objeto concierto con las siguientes propiedades, 10 price, 1/1/1 date, Jazz name y comprobamos que los valores se han creado bien
        Concert concert1 = new Concert(0, new Date(1,1,1), "Jazz");
        assertEquals(1, concert1.getDate().getDay());
        assertEquals(1, concert1.getDate().getMonth());
        assertEquals(1, concert1.getDate().getYear());
        assertEquals("Jazz", concert1.getName());
        assertEquals(0.0, concert1.getPrice(), 0.1);
        assertEquals(0.0, concert1.getVipPrice(), 0.1);
        
        //creamos un objeto concierto con las siguientes propiedades, 50 price, 20/11/2016 date, Blues name y comprobamos que los valores se han creado bien
        Concert concert2 = new Concert(50, new Date(20,11,2016), "Blues");
        assertEquals(20, concert2.getDate().getDay());
        assertEquals(11, concert2.getDate().getMonth());
        assertEquals(2016, concert2.getDate().getYear());
        assertEquals("Blues", concert2.getName());
        assertEquals(50.0, concert2.getPrice(), 0.1);
        assertEquals(100.0, concert2.getVipPrice(), 0.1);
        
        //creamos un objeto concierto con las siguientes propiedades, 10000 price, 31/12/2100 date, Jazz name y comprobamos que los valores se han creado bien
        Concert concert3 = new Concert(10000, new Date(31,12,2100), "Jazz");
        assertEquals(31, concert3.getDate().getDay());
        assertEquals(12, concert3.getDate().getMonth());
        assertEquals(2100, concert3.getDate().getYear());
        assertEquals("Jazz", concert3.getName());
        assertEquals(10000.0, concert3.getPrice(), 0.1);
        assertEquals(20000.0, concert3.getVipPrice(), 0.1);
        
        //PRUEBAS NEGATIVAS
        //creamos un objeto concierto con propiedades por debajo del limite inferior
        Concert concert4 = new Concert(-1, new Date(-1,-1,-1), "");
        assertEquals(0, concert4.getDate().getDay());
        assertEquals(0, concert4.getDate().getMonth());
        assertEquals(0, concert4.getDate().getYear());
        assertEquals("", concert4.getName());
        assertEquals(0.0, concert4.getPrice(), 0.1);
        assertEquals(0.0, concert4.getVipPrice(), 0.1);
        
        //creamos un objeto concierto con propiedades por encima del limite superior
        Concert concert5 = new Concert(152452150, new Date(41,21,5542154), "");
        assertEquals(0, concert5.getDate().getDay());
        assertEquals(0, concert5.getDate().getMonth());
        assertEquals(0, concert5.getDate().getYear());
        assertEquals("", concert5.getName());
        assertEquals(0.0, concert5.getPrice(), 0.1);
        assertEquals(0.0, concert5.getVipPrice(), 0.1);
        
        
    }
}

