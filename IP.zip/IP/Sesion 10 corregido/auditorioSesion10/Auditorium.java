
/**
 * Class Auditorium.
 * 
 * @author Gema Rico Pozas
 * @version 20/11/2016
 */
import java.util.ArrayList;
public class Auditorium
{
    // instance variables 
    private  ArrayList<Concert> concerts; //coleccion de conciertos

    /**
     * Constructor for objects of class Auditorium
     */
    public Auditorium(int numberOfConcerts)
    {
        {
            if( numberOfConcerts < 0)
                throw new RuntimeException("Error: tiene que haber al menos un concierto");
            setConcerts(numberOfConcerts);
        }

    }

    /**
     * Método que añade el numero de conciertos a la colección 
     *
     * @param numero de conciertos
     * 
     */
    private void setConcerts(int numberOfConcerts)
    {
        concerts = new ArrayList<Concert>();
        for(int i=1; i<= numberOfConcerts; i++)
        {
            concerts.add(new Concert(Concert.DEFAULT_PRICE,Concert.DEFAULT_DATE,Concert.DEFAULT_NAME));
        }
    }

    /**
     * Método que devuelve el concierto que tenga el nombre pasado como parámetro
     * 
     * @return Devuelve el concierto si existe o null en caso contrario.
     */
    public Concert seekConcert(String concertName)
    {
        for(int i=0; i<concerts.size() ; i++)
        { 
            while(concertName==getConcerts(i).getName())
                return getConcerts(i);
        } 
        return null;
    } 

    /**
     * Método que añade 1 concierto a la colección 
     * 
     */
    public void addConcert (String concertName, Date fecha, double price)
    {
        for(int i=0; i<concerts.size() ; i++)
        { 
            while((fecha.getYear()==getConcerts(i).getDate().getYear())&& (fecha.getMonth()==getConcerts(i).getDate().getMonth()) 
            && (fecha.getDay()== getConcerts(i).getDate().getDay()))
                throw new RuntimeException("Error:fecha repetida");
        }           
        concerts.add(new Concert(price,fecha,concertName));             

    } 

    /**
     * Método que borra todos los conciertos de la lista que se hayan celebrado en el año indicado en el parámetro.
     *
     * @param  año
     * 
     */
    public void removeConcerts (int year)
    {
        int i=0;
        while (i<concerts.size())
        {  
          if (concerts.get(i).getDate().getYear() == year)  

            concerts.remove(i);
          else 
            i ++;
        }
    }   

    //Metodos para el constructor

    /**
     * Método que devuelve el tamaño de la colección
     *
     * 
     * @return  tamaño de la colección
     */
    public int getSize()
    {
        return concerts.size();
    }

    /**
     * Método que devuelve la posición de la colección
     *
     * 
     * @return  el objeto que está en la posicion index
     */
    public Concert getConcerts(int index)
    {
        return concerts.get(index);
    }   

}
