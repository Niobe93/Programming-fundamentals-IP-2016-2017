
/**
 * Class Date.
 * 
 * @author Gema Rico Pozas 
 * @version (20/11/2016)
 */
public class Date
{
    //Constantes
    public final static int MIN_DAY=1;
    public final static int MAX_DAY=31;
    
    public final static int MIN_MONTH=1;
    public final static int MAX_MONTH=12;
    
    public final static int MIN_YEAR=0;
    public final static int MAX_YEAR=2100;
    public final static int ACTUAL_YEAR=2016;
    
    // instance variables 
    private int day;
    private int month;
    private int year;
    

    /**
     * Constructor for objects of class Date
     */
    public Date(int day,int month, int year)
    {
        setDay(day);
        setMonth(month);
        setYear(year);
    }

     /**
     * Método que modifica el atributo day
     * 
     * @param  nuevo day
     * 
     */
    private void setDay(int day)
    {
       if (day>=MIN_DAY && day<=MAX_DAY)
        this.day=day;       
    }
    
     /**
     * Método que modifica el atributo month
     * 
     * @param  nuevo month
     * 
     */
    private void setMonth(int month)
    {
       if (month>=MIN_MONTH && month<=MAX_MONTH)
        this.month=month;       
    }
    
     /**
     * Método que modifica el atributo year
     * 
     * @param  nuevo year
     * 
     */
    private void setYear(int year)
    {
       if (year>=MIN_YEAR && year<=MAX_YEAR)
        this.year=year;       
    }
    
    /**
     * Método que devuelve el valor del atributo day
     * 
     * @return day
     * 
     */
    public int getDay()
    {
        return this.day;       
    }
    
    /**
     * Método que devuelve el valor del atributo month
     * 
     * @return month
     * 
     */
    public int getMonth()
    {
        return this.month;       
    }
    
    /**
     * Método que devuelve el valor del atributo year
     * 
     * @return year
     * 
     */
    public int getYear()
    {
        return this.year;       
    }
}
