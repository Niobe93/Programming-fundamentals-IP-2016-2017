
/**
 * Class Concert.
 * 
 * @author Gema Rico Pozas
 * @version 20/11/2016
 */
public class Concert
{
    //Constantes
    
    public final static double MIN_PRICE=0.0;
    public final static double MAX_PRICE=10000.0;  
    
    
    
    public final static double DEFAULT_PRICE=5.0; 
    public final static String DEFAULT_NAME="Concierto.."; 
    public final static Date DEFAULT_DATE=new Date(1,1,2016); 
   
        
    
    // instance variables 
    private String name;
    private double price;
    private double vipPrice;
    private Date date;
    

    /**
     * Constructor for objects of class Concert
     */
    public Concert(double price, Date date, String name)
    {
        setName(name);
        setPrice(price);
        setDate(date);
        vipPrice=(getPrice()*2);
    }
    
     /**
     * Método que modifica el atributo price
     * 
     * @param  nuevo precio
     * 
     */
    private void setPrice(double price)
    {
       if (price>=MIN_PRICE && price<=MAX_PRICE)
        this.price=price;       
    }
    
     /**
     * Método que modifica el atributo name
     * 
     * @param  nuevo nombre
     * 
     */
    private void setName(String name)
    {
        this.name=name;       
    } 
    
    /**
     * Método que modifica el atributo date
     * 
     * @param  nueva fecha
     * 
     */
    private void setDate(Date date)
    {
        this.date=date;       
    }    
    
    /**
     * Método que devuelve el valor del atributo date
     * 
     * 
     * @return fecha
     */
    public Date getDate()
    {
        return date;
    }    
       
    /**
     * Método que devuelve el valor del atributo name
     * 
     * 
     * @return  nombre del concierto
     */
    public String getName()
    {
        return name;
    }

    /**
     * Método que devuelve el valor del atributo price
     * 
     * 
     * @return  precio de la butaca
     */
    public double getPrice()
    {
        return price;
    }
    
    /**
     * Método que devuelve el valor del atributo price vip
     * 
     * 
     * @return  precio de la butaca vip
     */
    public double getVipPrice()
    {
        return vipPrice;
    }
    
    
    
}
