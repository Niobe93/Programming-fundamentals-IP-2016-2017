

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class DateTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class DateTest
{
    /**
     * Default constructor for test class DateTest
     */
    public DateTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }    

    @Test
    public void testConstructor()
    {
        //PRUEBAS POSITIVAS
        //creamos un objeto date con dia/mes/año 1/1/1 y comprobamos los valores
        Date date1 = new Date(1, 1, 1);
        assertEquals(1, date1.getDay());
        assertEquals(1, date1.getMonth());
        assertEquals(1, date1.getYear());
        
        //creamos un objeto date con dia/mes/año 30/11/200 y comprobamos los valores
        Date date2 = new Date(30,11, 200);
        assertEquals(30, date2.getDay());
        assertEquals(11, date2.getMonth());
        assertEquals(200, date2.getYear());
        
        
        //creamos un objeto date con dia/mes/año 31/12/2100 y comprobamos los valores
        Date date3 = new Date(31, 12, 2100);
        assertEquals(31, date3.getDay());
        assertEquals(12, date3.getMonth());
        assertEquals(2100, date3.getYear());
        
        //PRUEBAS NEGATIVAS
        //creamos un objeto date con dia/mes/año -1/13/5000 y comprobamos los valores
        Date date4 = new Date(-1, 13, 5000);
        assertEquals(0, date4.getDay());
        assertEquals(0, date4.getMonth());
        assertEquals(0, date4.getYear());
        
        
        //creamos un objeto date con dia/mes/año 41/-1/-1 y comprobamos los valores
        Date date5 = new Date(41, -1, -1);
        assertEquals(0, date5.getDay());
        assertEquals(0, date5.getMonth());
        assertEquals(0, date5.getYear());
    }
}




