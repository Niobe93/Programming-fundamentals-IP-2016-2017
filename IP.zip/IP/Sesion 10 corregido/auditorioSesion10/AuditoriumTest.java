

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class AuditoriumTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class AuditoriumTest
{
    /**
     * Default constructor for test class AuditoriumTest
     */
    public AuditoriumTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }
    
    @Test
    public void testSeekConcert()
    {
        //PRUEBAS POSITIVAS
        //CASO 1creamos una coleccion de 2 conciertos
        Auditorium auditorium1 = new Auditorium(2);
        
        //añadimos 3 conciertos con diferentes nombres
        auditorium1.addConcert("musica",new Date(2,2,2016),10.0);
        
        auditorium1.addConcert("rap",new Date(20,3,2016),10.0);
        
        auditorium1.addConcert("jazz",new Date(5,8,2015),10.0);       
        
        //Comprobamos que llamando al método seekconcert nos devuelve el concierto que tiene el nombre pasado como parametro
        auditorium1.seekConcert("musica");          
         for(int i=0; i<auditorium1.getSize() ; i++)
        { 
            if ("musica"==auditorium1.getConcerts(i).getName())
             assertEquals("musica", auditorium1.getConcerts(i).getName()); 
        } 
       
        //Comprobamos que llamando al método seekconcert nos devuelve el concierto que tiene el nombre pasado como parametro
        auditorium1.seekConcert("jazz");          
         for(int i=0; i<auditorium1.getSize() ; i++)
        { 
            if ("jazz"==auditorium1.getConcerts(i).getName())
             assertEquals("jazz", auditorium1.getConcerts(i).getName()); 
        } 
      
            
        //PRUEBAS NEGATIVAS
        
        //Comprobamos que cuando buscamos por un nombre de un concierto que no existe nos devuelve null
        
        assertEquals(null, auditorium1.seekConcert("holahola"));
        
        //Eliminamos un concierto y lo buscamos para comprobar que nos devuelve null
        auditorium1.removeConcerts(2016);
        assertEquals(null, auditorium1.seekConcert("rap"));
        
   
        
    }    
    
    @Test
    public void testRemoveConcerts()
    {
        //CASO 1 Creamos un objeto auditorium con 1 concierto con fecha 1,1,2016
        Auditorium auditorium1 = new Auditorium(1);
        
        //añadimos varios conciertos con diferentes años como fecha
        
        auditorium1.addConcert("musica",new Date(2,2,2015),10.0);
        
        auditorium1.addConcert("musica",new Date(2,5,2015),10.0);
        
        auditorium1.addConcert("rap",new Date(20,3,2013),10.0);
        
        auditorium1.addConcert("jazz",new Date(5,8,1993),10.0); 
        
        //comprobamos el tamaño de la colección
        assertEquals(5,auditorium1.getSize());
        
        //llamamos al método removeConcerts y eliminamos el concierto del 2016
        auditorium1.removeConcerts(2016);
        
        //Comprobamos que el tamaño de la colección ahora es 4
        assertEquals(4,auditorium1.getSize());
               
         //volvemos a llamar al método removeConcerts y eliminamos otra vez el año 2016 y debe permanecer igual
        auditorium1.removeConcerts(2016);
        assertEquals(4,auditorium1.getSize());
        
        //llamamos al método removeConcerts y eliminamos el concierto del 2016
        auditorium1.removeConcerts(2015);
        
        //Comprobamos que el tamaño de la colección ahora es 2
        assertEquals(2,auditorium1.getSize());   
    
    }
    @Test
    public void testAddConcert()
    {
        //PRUEBAS POSITIVAS
        //CASO 1 creamos una coleccion de 2 conciertos y comprobamos el tamaño de la colección        
        Auditorium auditorium1 = new Auditorium(2);
        assertEquals(2,auditorium1.getSize());
        
         //añadimos 3 conciertos con diferentes nombres
        auditorium1.addConcert("musica",new Date(2,2,2016),10.0);
               
        auditorium1.addConcert("rap",new Date(20,3,2016),10.0);
                
        auditorium1.addConcert("jazz",new Date(5,8,2015),10.0);  
        
         //comprobamos que se han creado correctamente los conciertos
        
         //primero comprobamos que la colección ha aumentado en 3 conciertos
        assertEquals(5,auditorium1.getSize());
         //ahora comprobamos que al buscar con el metodo seekConcert nos aparecen los nombres de los conciertos como creados
         assertNotNull(auditorium1.seekConcert("rap")); 
         assertNotNull(auditorium1.seekConcert("jazz")); 
         assertNotNull(auditorium1.seekConcert("musica")); 
         
         
        //PRUEBAS NEGATIVAS 
        
        //añadimos un concierto con la misma fecha que uno ya creado
        
        
        try 
        {
           auditorium1.addConcert("jazz",new Date(5,8,2015),10.0); 
        }
        catch (Exception ex)
        {
            assertEquals("Error:fecha repetida", ex.getMessage());
        }
    
    }
}
