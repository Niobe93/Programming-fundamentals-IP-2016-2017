
/**
 * class LandingGear here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class LandingGear
{
    public final static boolean LEVER_UP=true;
    public final static boolean LEVER_DOWN=false;    
    public final static boolean ON=true;
    public final static boolean OFF=false;
    // instance variables
    private boolean lever; //representa la posicion de la palanca en el panel
    private WheelStrut nose; //puntal de la parte delantera
    private WheelStrut left; //puntal de la parte izquierda
    private WheelStrut right; //puntal de la parte derecha
    /**
     * Constructor for objects of class LandingGear
     */
    public LandingGear()
    {
        lever= LEVER_DOWN;
        nose = new WheelStrut();
        left = new WheelStrut();
        right = new WheelStrut();
    }

    /**
     * Método que devuelve el valor del atributo lever
     * 
     * 
     * @return  el valor del atributo lever   
     */
    public boolean isLever()
    {
        return lever;
    }

    /**
     * Método que devuelve el valor del atributo nose
     * 
     * 
     * @return valor del atributo nose    
     */
    public WheelStrut getNose()
    {
        return nose;
    }

    /**
     * Método que devuelve el valor del atributo wheelstrut left
     * 
     * 
     * @return valor del atributo wheelstrut left    
     */
    public WheelStrut getLeft()
    {
        return left;
    }

    /**
     * Método que devuelve el valor del atributo wheelstrut right
     * 
     *
     * @return el valor del atributo wheelstrut right    
     */
    public WheelStrut getRight()
    {
        return right;
    }

    /**
     * Método que permite mover la palanca
     *
     * @param action = LEVER_UP se debe elevar la palanca y replegar puntales
     *        action = LEVER_DOWN se debe bajar la palanca y desplegar puntales
     * 
     */
    public void moveLever(boolean action)
    {
        if (action == LEVER_UP)       
        {         
            right.retract();
            nose.retract();
            left.retract();
        }
        else 
        {        
            right.deployed();
            nose.deployed();
            left.deployed();
        }
        lever=action;
    }   

    /**
     * Metodo que devuelve el estado de la palanca
     *
     * 
     * @return devuelve el estado de la palanca UP /DOWN
     */
    public String getLeverStatus()
    {
        if (this.isLever()== LEVER_UP)
            return ("UP");
        else 
            return ("DOWN");
       
    }

    /**
     *  Metodo que devuelve el estado del tren de aterrizaje
     *
     * 
     * @return  devuelve el estado del tren de aterrizaje , OK 
     */
    public String getLandingGear()
    {
        if ((right.isDeployed()== ON) && (nose.isDeployed()==ON) && (left.isDeployed()==ON))
            return ("OK");
        else if ((right.isDeployed()== OFF) | (nose.isDeployed()==OFF) | (left.isDeployed()==OFF))
            return ("FAILURE");
        else 
           return "ERROR";
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y
     */
    public String getRightStatus()
    {
        if(right.isDeployed()== ON)
            return ("ON");
        else 
            return ("OFF");
        
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y
     */
    public String getLeftStatus()
    {
        if(left.isDeployed()==ON)
            return ("ON");
        else 
            return ("OFF"); 
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y
     */
    public String getNoseStatus()
    {
        if(nose.isDeployed()==ON)
            return ("ON");
        else 
            return ("OFF");
    }

    /**
     * Método que  devuelva el estado de todo el sistema
     *
     * 
     * @return  devuelva el estado de todo el sistema con el siguiente formato:
     *                          Estado de la palanca (DOWN / UP)
     *                          Estado del tren de aterrizaje (OK / FAILURE)
     *                          Estado de cada puntal (strut) (ON = deployed / OFF = retracted 
     */
    public String toString()
    {
        return ("Lever:   "+this.getLeverStatus()+"      Status:"+this.getLandingGear()+"       Left:"+this.getLeftStatus()+
        "       Nose"+this.getNoseStatus()+"          Right:"+  this.getRightStatus());

    }

    /**
     * Método que muestra por pantalla el estado del objeto de la clase WheelStrut
     *
     * @return Posición de la palanca
     *         Resultado de ejecutar el test sobre el tren de aterrizaje
     *         FAIL, si el método test() del puntal devuelve false; ON si el puntal está desplegado;
                    OFF, en otro caso (para cada puntal).
     */
    public void print ()
    {
        System.out.println("Lever........"    +     this.getLeverStatus());  
        System.out.println("Test........."    +     this.getLandingGear());
        if (right.test() == OFF)
            System.out.println("                FAIL");
        else 
            System.out.println("              "+this.getRightStatus());
        if (left.test() == OFF)
            System.out.print("FAIL");
        else 
            System.out.print(this.getLeftStatus());
        if (nose.test() == OFF)
            System.out.println("                             FAIL");
        else 
            System.out.println("                           "+this.getNoseStatus());       
    } 
}
