

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class WheelStrutTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class WheelStrutTest
{
    /**
     * Default constructor for test class WheelStrutTest
     */
    public WheelStrutTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }   

    @Test
    public void testTest()
    {
        //PRUEBAS POSITIVAS
        
        //CASO 1, creamos un objeto WheelStrut
        WheelStrut wheelStr1 = new WheelStrut();
        assertEquals(true, wheelStr1.test());
        //CASO 2, creamos un objeto WheelStrut con 4 ruedas
        WheelStrut wheelStr2 = new WheelStrut(4);
        assertEquals(true, wheelStr2.test());
        //CASO 3, creamos un objeto WheelStrut con 6 ruedas
        WheelStrut wheelStr3 = new WheelStrut(6);
        assertEquals(true, wheelStr3.test());
        
        //PRUEBAS NEGATIVAS
        
        //CASO 4, creamos un objeto WheelStrut y cambio la presion de una rueda a un valor incorrecto
        WheelStrut wheelStr4 = new WheelStrut(4);
        wheelStr4.getWheels(1).changePressure(1000);
        assertEquals(false, wheelStr4.test());
        
        //CASO 5, creamos un objeto WheelStrut y cambio la presion de todas las ruedas a un valor incorrecto
        WheelStrut wheelStr5 = new WheelStrut(4);
        for (int i=0; i<wheelStr1.getSize();i++)
          {
              wheelStr5.getWheels(1).changePressure(1000);
          }
    }
    
    
    @Test
    public void testConstructor()
    { 
        //Pruebas positivas, creamos un objeto con 4 ruedas y desplegado
        
        WheelStrut wheelStr1 = new WheelStrut(4);
         assertEquals(WheelStrut.IS_DEPLOYED,wheelStr1.isDeployed());
         assertEquals(4, wheelStr1.getSize());
         for (int i=0; i<wheelStr1.getSize();i++)
         {
              assertEquals(WheelStrut.DEFAULT_PREASSURE_BOEING_737,wheelStr1.getWheels(i).getPressure(),0.1);
         }
         
        //Pruebas negativas
        //se crea un puntal con cero ruedas
        
        try 
        {
           WheelStrut wheelStr2 = new WheelStrut(0);
        }
        catch (Exception ex)
        {
            assertEquals("Error: el parámetro es negativo o cero", ex.getMessage());
        }
         
    }
}




   