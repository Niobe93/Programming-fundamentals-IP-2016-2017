

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class LandingGearTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class LandingGearTest
{
    /**
     * Default constructor for test class LandingGearTest
     */
    public LandingGearTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }    

    @Test
    public void testMoveLever()
    {
       // CASO 1 creamos tren de aterrizaje inicialmente leverdown
        LandingGear landingGear = new LandingGear();
        assertEquals(LandingGear.LEVER_DOWN,landingGear.isLever());
        assertEquals(WheelStrut.IS_DEPLOYED, landingGear.getLeft().isDeployed());
        assertEquals(WheelStrut.IS_DEPLOYED, landingGear.getRight().isDeployed());
        assertEquals(WheelStrut.IS_DEPLOYED, landingGear.getNose().isDeployed());
        
       // CASO 2 estando la palanca hacia abajo movemos hacia arriba
        landingGear.moveLever(LandingGear.LEVER_UP);
        assertEquals(LandingGear.LEVER_UP,landingGear.isLever());
        assertEquals(WheelStrut.IS_RETRACTED, landingGear.getLeft().isDeployed());
        assertEquals(WheelStrut.IS_RETRACTED, landingGear.getRight().isDeployed());
        assertEquals(WheelStrut.IS_RETRACTED, landingGear.getNose().isDeployed());
        
    }
}


