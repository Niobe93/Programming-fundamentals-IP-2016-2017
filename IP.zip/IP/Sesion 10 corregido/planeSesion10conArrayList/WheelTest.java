

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class WheelTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class WheelTest
{
    /**
     * Default constructor for test class WheelTest
     */
    public WheelTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }    

    @Test
    public void testToString()
    {
       //crear un objeto de la clase Wheel y asignarle un valor intermedio y positivo al test        
        Wheel wheel1 = new Wheel(5000, 5000);
        assertEquals(" MaxP: 5000.0 Mb  -  Pressure: 5000.0 Mb  -  Percentage:  (100,00 %)  -  Test: true", wheel1.toString());
       
       // crear un objeto de la clase Wheel y asignarle un valor intermedio y positivo al test
        Wheel wheel2 = new Wheel(5000, 4850);
        assertEquals(" MaxP: 5000.0 Mb  -  Pressure: 4850.0 Mb  -  Percentage:  (97,00 %)  -  Test: true", wheel2.toString());
        
        //crear un objeto de la clase Wheel y asignarle un valor intermedio y positivo al test
        Wheel wheel3 = new Wheel(0, 0);
        assertEquals(" MaxP: 0.0 Mb  -  Pressure: 0.0 Mb  -  Percentage:  (NaN %)  -  Test: true", wheel3.toString());
        
        //crear un objeto de la clase Wheel y asignarle un valor de presion actual no suficiente al 85% y negativo al test
        Wheel wheel4 = new Wheel(5000, 200);
        assertEquals(" MaxP: 5000.0 Mb  -  Pressure: 200.0 Mb  -  Percentage:  (4,00 %)  -  Test: false", wheel4.toString());
    }
}




