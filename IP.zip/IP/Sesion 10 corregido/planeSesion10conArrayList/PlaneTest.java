

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class PlaneTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class PlaneTest
{
    /**
     * Default constructor for test class PlaneTest
     */
    public PlaneTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }

    @Test
    public void testTravelCost()
    {
        //Crear objeto clase Plane
        Plane plane1 = new Plane();
        
        //PRUEBAS POSITIVAS
        
        //CASO 1: valor del precio del ticket con un valor positivo y el peso con un valor superior del rango.
        assertEquals(112.0, plane1.travelCost(100, 60), 0.1);
        
        //CASO 2: valor del precio del ticket con un valor positivo y el peso con el valor del limite superior.
        assertEquals(106.0, plane1.travelCost(100, 50), 0.1);
        
        //CASO 3: valor del precio del ticket con un valor positivo y el peso con el valor inferior del rango intermedio.
        assertEquals(105.0, plane1.travelCost(100, 20), 0.1);
        
        //CASO 4: valor del precio del ticket con un valor positivo y el peso con un valor del rango intermedio.
        assertEquals(106.0, plane1.travelCost(100, 30), 0.1);
        
        //CASO 5: valor del precio del ticket con un valor positivo y el peso con un valor inferior del rango intermedio.
        assertEquals(105.0, plane1.travelCost(100, 10), 0.1);       
        
        //PRUEBAS NEGATIVAS
        
        //CASO 6: valor del precio del ticket con de valor 0 y el peso con el valor inferior del rango intermedio (positivo).
        assertEquals(0.0, plane1.travelCost(0, 20), 0.1);
        
        //CASO 7: valor del precio del ticket con un valor positivo y el peso con el valor 0.
        assertEquals(0.0, plane1.travelCost(100, 0), 0.1);
        
        //CASO 8: valor del precio del ticket con un valor NEGATIVO y el peso con un valor inferior del rango intermedio (positivo).
        assertEquals(0.0, plane1.travelCost(-3, 10), 0.1);
        
        //CASO 9: valor del precio del ticket con un valor positivo y el peso con un valor NEGATIVO.
        assertEquals(0.0, plane1.travelCost(100, -3), 0.1);
    }

    @Test
    public void testAccelerate()
    {
        //Crear objeto clase Plane
        Plane plane1 = new Plane();
        
        //PRUEBAS POSITIVAS
        
        //CASO 1: valores de XSPeed e YSpeed con valor 0.
        plane1.accelerate(0, 0);
        assertEquals(0, plane1.getXSpeed());
        assertEquals(0, plane1.getYSpeed());
        
        //CASO 2: valores de XSPeed e YSpeed con valor 1.
        plane1.accelerate(1, 1);
        assertEquals(1, plane1.getYSpeed());
        assertEquals(1, plane1.getXSpeed());
        
        //CASO 3: valores de XSPeed e YSpeed con valor -1.
        plane1.accelerate(-1, 1);
        assertEquals(-1, plane1.getXSpeed());
        assertEquals(1, plane1.getYSpeed());
        
        //CASO 4: valor de Xspeed a 0 e Yspeed a 1.
        plane1.accelerate(0, 1);
        assertEquals(0, plane1.getXSpeed());
        assertEquals(1, plane1.getYSpeed());
        
        //CASO 5: valor de Xspeed a -1 e Yspeed a 0.
        plane1.accelerate(-1, 0);
        assertEquals(-1, plane1.getXSpeed());
        assertEquals(0, plane1.getYSpeed());
        
        //PRUEBAS NEGATIVAS
        
        //CASO 6: valor de Xspeed con un valor inferior al limite.
        plane1.accelerate(-2, 0);
        assertEquals(-1, plane1.getXSpeed());
        assertEquals(0, plane1.getYSpeed());
        //CASO 7: valor de Yspeed con un valor inferior al limite y Xspeed con un valor superior al limite.
        plane1.accelerate(3, -2);
        assertEquals(-1, plane1.getXSpeed());
        assertEquals(0, plane1.getYSpeed());
        //CASO 8: valor de Yspeed con un valor inferior al limite.
        plane1.accelerate(0, -5);
        assertEquals(-1, plane1.getXSpeed());
        assertEquals(0, plane1.getYSpeed());

    }
    @Test
    public void testFly()
    {
      
        
        //CASO 1
        //Creamos un objeto plane con valores inciales Xpos(5),Xspeed(5),YPos(0),YSpeed(0),Fuel(5000)
        Plane plane1 = new Plane();
        //llamamos al metodo accelerate y cambiamos la velocidad de X e Y a 1 y -1
        plane1.accelerate(1, -1);
        assertEquals(true, plane1.fly());
        assertEquals(6, plane1.getXPos());
        assertEquals(4, plane1.getYPos());
        assertEquals(4999, plane1.getFuel());
        
        //CASO 2
        //Creamos un objeto plane con valores inciales Xpos(5),Xspeed(5),YPos(0),YSpeed(0),Fuel(5000)
        Plane plane2 = new Plane();
        //llamamos al metodo accelerate y cambiamos la velocidad de X e Y a 0
        plane2.accelerate(0, 0);
        assertEquals(true, plane2.fly());
        assertEquals(5, plane2.getXPos());
        assertEquals(5, plane2.getYPos());
        assertEquals(4999, plane2.getFuel());
        
        //CASO 3
        //Creamos un objeto plane con valores inciales Xpos(5),Xspeed(5),YPos(0),YSpeed(0),Fuel(5000)
        Plane plane3 = new Plane();
        //llamamos al metodo accelerate y cambiamos la velocidad de X e Y a -1
        plane3.accelerate(-1, -1);
        assertEquals(true, plane3.fly());
        assertEquals(4, plane3.getXPos());
        assertEquals(4, plane3.getYPos());
        assertEquals(4999, plane3.getFuel());
        
        
       
        
    }
}


   

