

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class NunchukTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class NunchukTest
{
    /**
     * Default constructor for test class NunchukTest
     */
    public NunchukTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }    

   

    @Test
    public void testAvanzar()
    {
        //creamos un objeto nunckuck con valores iniciales de (0,0) de X e Y, llamamos a avanzar y movemos un step a la derecha
        Nunchuk nunchuk1 = new Nunchuk();
        nunchuk1.avanzar('R');
        assertEquals(10,nunchuk1.getFigure().getXPos());
        assertEquals(Figure.Y_LOWER_EDGE,nunchuk1.getFigure().getYPos());
        
        //llamamos a avanzar y movemos un step a la derecha y queda otra vez el valor en 0
        nunchuk1.avanzar('L');
         assertEquals(Figure.X_LOWER_EDGE,nunchuk1.getFigure().getXPos());
        assertEquals(Figure.Y_LOWER_EDGE,nunchuk1.getFigure().getYPos());
        
        //llamamos a avanzar y movemos un step hacia arriba y quedaría el valor de Y en 10
        nunchuk1.avanzar('U');
         assertEquals(Figure.X_LOWER_EDGE,nunchuk1.getFigure().getXPos());
        assertEquals(10,nunchuk1.getFigure().getYPos());
        
        //llamamos a avanzar y movemos un step hacia abajo y quedaría el valor de Y en 0
        nunchuk1.avanzar('D');
         assertEquals(Figure.X_LOWER_EDGE,nunchuk1.getFigure().getXPos());
        assertEquals(Figure.Y_LOWER_EDGE,nunchuk1.getFigure().getYPos());
        
        //llamamos a avanzar y movemos un step hacia abajo y como es el limite del valor no se modifica
        nunchuk1.avanzar('D');
         assertEquals(Figure.X_LOWER_EDGE,nunchuk1.getFigure().getXPos());
        assertEquals(Figure.Y_LOWER_EDGE,nunchuk1.getFigure().getYPos());
        
        
        
    }    

    @Test
    public void testMidleAdvance()
    {
        //creamos un objeto nunckuck con valores iniciales de (0,0) de X e Y, llamamos a avanzar y movemos 2 step a la derecha
        Nunchuk nunchuk1 = new Nunchuk();
        nunchuk1.midleAdvance('R');
        assertEquals(20,nunchuk1.getFigure().getXPos());
        assertEquals(Figure.Y_LOWER_EDGE,nunchuk1.getFigure().getYPos());
        
        //llamamos a avanzar y movemos 2 step a la derecha y queda otra vez el valor en 0
        nunchuk1.midleAdvance('L');
         assertEquals(Figure.X_LOWER_EDGE,nunchuk1.getFigure().getXPos());
        assertEquals(Figure.Y_LOWER_EDGE,nunchuk1.getFigure().getYPos());
        
        //llamamos a avanzar y movemos 2 step hacia arriba y quedaría el valor de Y en 10
        nunchuk1.midleAdvance('U');
         assertEquals(Figure.X_LOWER_EDGE,nunchuk1.getFigure().getXPos());
        assertEquals(20,nunchuk1.getFigure().getYPos());
        
        //llamamos a avanzar y movemos 2 step hacia abajo y quedaría el valor de Y en 0
        nunchuk1.midleAdvance('D');
         assertEquals(Figure.X_LOWER_EDGE,nunchuk1.getFigure().getXPos());
        assertEquals(Figure.Y_LOWER_EDGE,nunchuk1.getFigure().getYPos());
        
        //llamamos a avanzar y movemos 2 step hacia abajo y como es el limite del valor no se modifica
        nunchuk1.midleAdvance('D');
         assertEquals(Figure.X_LOWER_EDGE,nunchuk1.getFigure().getXPos());
        assertEquals(Figure.Y_LOWER_EDGE,nunchuk1.getFigure().getYPos());
        
        
    }
    
    @Test
    public void testMuchAdvance()
    {
        //creamos un objeto nunckuck con valores iniciales de (0,0) de X e Y, llamamos a avanzar y movemos 5 step a la derecha
        Nunchuk nunchuk1 = new Nunchuk();
        nunchuk1.muchAdvance('R');
        assertEquals(50,nunchuk1.getFigure().getXPos());
        assertEquals(Figure.Y_LOWER_EDGE,nunchuk1.getFigure().getYPos());
        
        //llamamos a avanzar y movemos 2 step a la derecha y queda otra vez el valor en 0
        nunchuk1.muchAdvance('L');
         assertEquals(Figure.X_LOWER_EDGE,nunchuk1.getFigure().getXPos());
        assertEquals(Figure.Y_LOWER_EDGE,nunchuk1.getFigure().getYPos());
        
        //llamamos a avanzar y movemos 2 step hacia arriba y quedaría el valor de Y en 10
        nunchuk1.muchAdvance('U');
         assertEquals(Figure.X_LOWER_EDGE,nunchuk1.getFigure().getXPos());
        assertEquals(50,nunchuk1.getFigure().getYPos());
        
        //llamamos a avanzar y movemos 2 step hacia abajo y quedaría el valor de Y en 0
        nunchuk1.muchAdvance('D');
         assertEquals(Figure.X_LOWER_EDGE,nunchuk1.getFigure().getXPos());
        assertEquals(Figure.Y_LOWER_EDGE,nunchuk1.getFigure().getYPos());
        
        //llamamos a avanzar y movemos 2 step hacia abajo y como es el limite del valor no se modifica
        nunchuk1.muchAdvance('D');
         assertEquals(Figure.X_LOWER_EDGE,nunchuk1.getFigure().getXPos());
        assertEquals(Figure.Y_LOWER_EDGE,nunchuk1.getFigure().getYPos());
        
        
    }
    
    @Test
    public void testShootWeapon()
    {
        //creamos un objeto nunckuck con valores iniciales de municion 200 y disparamos rafaga ( 5 disparos )
        Nunchuk nunchuk1 = new Nunchuk();
        nunchuk1.shootWeapon(true);
        assertEquals(195,nunchuk1.getWeapon().getAmmunition());
        
        //ejecutamos un solo disparo con false y solo se produce un disparo
        nunchuk1.shootWeapon(false);
        assertEquals(194,nunchuk1.getWeapon().getAmmunition());
        
         //disparamos rafaga ( 5 disparos )       
        nunchuk1.shootWeapon(true);
        assertEquals(189,nunchuk1.getWeapon().getAmmunition());
        
        
    }

    @Test
    public void testShootForward()
    {
        //creamos un objeto nunckuk con valores de posicion (0,0) y municion 200
        Nunchuk nunchuk1 = new Nunchuk();
        
        //llamamos al metodo y avanza un paso a la derecha y dispara una vez
        nunchuk1.shootForward('R');
        assertEquals(10,nunchuk1.getFigure().getXPos());
        assertEquals(Figure.Y_LOWER_EDGE,nunchuk1.getFigure().getYPos());
        assertEquals(199,nunchuk1.getWeapon().getAmmunition());
        
        //llamamos al metodo y avanza un paso a la derecha y dispara una vez 
        nunchuk1.shootForward('R');
        assertEquals(20,nunchuk1.getFigure().getXPos());
        assertEquals(Figure.Y_LOWER_EDGE,nunchuk1.getFigure().getYPos());
        assertEquals(198,nunchuk1.getWeapon().getAmmunition());
        
        //llamamos al metodo y avanza un paso a  hacia abajo y no cambia la posicion ya que es el limite pero dispara una vez
        nunchuk1.shootForward('D');
        assertEquals(20,nunchuk1.getFigure().getXPos());
        assertEquals(Figure.Y_LOWER_EDGE,nunchuk1.getFigure().getYPos());
        assertEquals(197,nunchuk1.getWeapon().getAmmunition());
        
       
        
    }
}





 
    
    

  