
/**
 *Class Figure para laboratorio de IP sesion 7
 * 
 * @author GemaRicoPozas 
 * @version 29/10/2016
 */
public class Figure
{
    //Constantes de la clase figure

    public static final int X_LOWER_EDGE=0; //minima posicion de x
    public static final int Y_LOWER_EDGE=0; //minima posicion de y

    public static final int X_UPPER_EDGE=640; //maxima posicion de x
    public static final int Y_UPPER_EDGE=320; //maxima posicion de y

    public static final char LEFT='L'; // constantes tipo char para movimiento izquierda
    public static final char RIGHT='R'; // constantes tipo char para movimiento derecha
    public static final char UP='U'; // constantes tipo char para movimiento arriba
    public static final char DOWN='D'; // constantes tipo char para movimiento abajo

    public static final int STEP=10; //representa la distancia en pixels

    // instance variables 
    private String name;
    private int xPos;
    private int yPos;

    /**
     * Constructor for objects of class Figure
     */
    public Figure()
    {
        setName("Player");
        setXPos(X_LOWER_EDGE);
        setYPos(Y_LOWER_EDGE);

    }

    /**
     * Constructor for objects of class Figure con parámetros ( nombre y posiciones)
     */
    public Figure(String name, int xPos, int yPos)
    {
        setName(name);
        setXPos(xPos);
        setYPos(yPos);

    }

    /**
     *  Método que modifica el valor del atributo name
     *
     * @param cambia el valor del atributo name del tipo String
     * 
     */
    private void setName (String name)
    {
        this.name = name;
    }

    /**
     *  Método que modifica el valor del atributo xPos
     *
     * @param cambia el valor del atributo xPos del tipo int rango entre 0 y 640
     * 
     */
    private void setXPos (int xPos)
    {
        if ((xPos >=X_LOWER_EDGE ) && (xPos <=X_UPPER_EDGE))
            this.xPos = xPos;
    }

    /**
     *  Método que modifica el valor del atributo yPos
     *
     * @param cambia el valor del atributo yPos del tipo int rango entre 0 y 320
     * 
     */
    private void setYPos (int yPos)
    {
        if ((yPos >=Y_LOWER_EDGE ) && (yPos <=Y_UPPER_EDGE))
            this.yPos = yPos;
    }

    /**
     * Método que devuelve el valor del atributo name
     *
     * @return devuelve el valor del atributo name del tipo String
     */
    public String getName()
    { 
        return name ;
    }

    /**
     * Método que devuelve el valor del atributo xPos
     *
     * @return devuelve el valor del atributo xPos del tipo int
     */
    public int getXPos()
    { 
        return xPos ;
    }

    /**
     * Método que devuelve el valor del atributo yPos
     *
     * @return devuelve el valor del atributo yPos del tipo int
     */
    public int getYPos()
    { 
        return yPos ;
    }

    /**
     * Método que permite el movimiento del personaje
     *
     * @param  indica la dirección de movimiento del personaje 
     *          Si recibe 'L' se mueve un paso a la izquierda 
     *          si recibe 'R' se mueve un paso a la derecha
     *          si recibe 'U' se mueve un paso adelante
     *          si recibe 'D' se mueve un paso hacia atrás
     *          Si al moverse se pasa del borde de la pantalla no se ejecuta el movimiento (no cambia la posición).
     */
    public void move(char movement )
    {
        if ((movement == LEFT) && (xPos > X_LOWER_EDGE))
            setXPos(getXPos() - STEP);
        if ((movement == RIGHT) && (xPos < X_UPPER_EDGE))
            setXPos(getXPos() + STEP);
        if ((movement == UP) && (yPos < Y_UPPER_EDGE))
            setYPos(getYPos() + STEP);
        if ((movement == DOWN) && (yPos > Y_LOWER_EDGE))
            setYPos(getYPos() - STEP);

    }

    /**
     * Método que devuelve la información del personaje, su nombre y su posición
     *
     * 
     * @return devuelve una cadena con el nombre del personaje y su posición X e Y
     */

    public String toString()
    { 
        return (this.getName() + "(" + this.getXPos() + "," + this.getYPos() + ")");   
    
    }
    
    
    }
