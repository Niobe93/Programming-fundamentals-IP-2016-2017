
/**
 * Class Nunchuck para laboratorio de Ip sesion 7
 * 
 * @author GemaRicoPozas 
 * @version 29/10/2016
 */
public class Nunchuk
{
    // instance variables 
    private Figure personaje;
    private Weapon arma;

    /**
     * Constructor for objects of class Nunchuk
     */
    public Nunchuk()
    {
        arma = new Weapon();
        personaje = new Figure();
    }
    
     /**
     * Constructor for objects of class Nunchuk con parámetros
     */
    public Nunchuk(Figure personaje, Weapon arma)
    {
       this();
       arma = new Weapon(arma.getName(),arma.getAmmunition());
       personaje = new Figure(personaje.getName(),personaje.getXPos(),personaje.getYPos());
    }
    
    /**
     * Método que devuelve el valor del atributo weapon
     *
     * @return devuelve el valor del atributo arma
     */
    public Weapon getWeapon()
    { 
        return arma;
    }
    
    /**
     * Método que devuelve el valor del atributo figure
     *
     * @return devuelve el valor del atributo personaje
     */
    public Figure getFigure()
    { 
        return personaje;
    }
    
    /**
     * Método avanzar
     *
     * @param  indica la dirección de movimiento del personaje de un paso
     *          Si recibe 'L' se mueve un paso a la izquierda -  si recibe 'R' se mueve un paso a la derecha
     *          si recibe 'U' se mueve un paso adelante -  si recibe 'D' se mueve un paso hacia atrás
     *          Si al moverse se pasa del borde de la pantalla no se ejecuta el movimiento (no cambia la posición).
     */
    public void avanzar(char movimiento)
    {
        personaje.move(movimiento);
    }
    
    /**
     * Método avanzar (medio)
     *
     * @param  indica la dirección de movimiento del personaje de 2 pasos
     *          Si recibe 'L' se mueve 2 pasos a la izquierda -  si recibe 'R' se mueve 2 pasos a la derecha
     *          si recibe 'U' se mueve 2 pasos adelante -   si recibe 'D' se mueve 2 pasos hacia atrás
     *          Si al moverse se pasa del borde de la pantalla no se ejecuta el movimiento (no cambia la posición).
     */
    public void midleAdvance(char movimiento)
    {
       int counter=1;
       while(counter<=2)
       {
        personaje.move(movimiento);
        counter++;
       }
    }
    
    /**
     * Método avanzar (mucho)
     *
     * @param  indica la dirección de movimiento del personaje de 5 pasos
     *          Si recibe 'L' se mueve 5 pasos a la izquierda -  si recibe 'R' se mueve 5 pasos a la derecha
     *          si recibe 'U' se mueve 5 pasos adelante -   si recibe 'D' se mueve 5 pasos hacia atrás
     *          Si al moverse se pasa del borde de la pantalla no se ejecuta el movimiento (no cambia la posición).
     */
    public void muchAdvance(char movimiento)
    {
        int counter=1;
       while(counter<=5)
       {
        personaje.move(movimiento);
        counter++;
       }
    }     

    /**
     * Método shootWeapon (disparar arma).
     *
     *
     * @param tiene como parámetro un valor booleano que indica 
     *     false el arma se dispara una vez
     *     true el arma se dispara 5 veces (ráfaga).
     */
    public void shootWeapon (boolean shoot)
    {
       int counter=1;
        
        if (shoot == true)
      { 
        while(counter<=5)
        {
        arma.shoot();
        counter ++;
       }
       }
      else 
        arma.shoot();
    
   }    
    
    /**
     * Método shootForward (disparar avanzar).
     *
     * @param  Tiene como parámetro la dirección hacia donde se debe desplazar el personaje.El personaje se moverá y disparará una vez.
     * 
     */
    public void shootForward (char movement)
    {
       personaje.move(movement);
       arma.shoot();
    }
    
    /**
     * Método print que imprime el estado de los atributos
     *
     * 
     * @return imprime el estado de los atributos por la pantalla
     */
    public void print()
    {
       System.out.println(personaje.toString());
       System.out.println(arma.toString());
    }


}
