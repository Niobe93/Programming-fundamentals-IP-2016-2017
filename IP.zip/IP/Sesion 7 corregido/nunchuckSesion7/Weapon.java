
/**
 * Class Weapon para laboratorio de IP.
 * 
 * @author GemaRicoPozas
 * @version 29/10/2016
 */
public class Weapon
{
    //constantes de la calse Weapon
    public final static int MIN_AMMUNITION=0; //minimo de munición
    public final static int MAX_AMMUNITION=200; //maximo de munición    
    // instance variables 
    private String name; //nombre del arma
    private int ammunition; //cantidad de munición

    /**
     * Constructor for objects of class Weapon
     */
    public Weapon()
    {
        setName("Pistol");
        setAmmunition(MAX_AMMUNITION);

    }
    
    /**
     * Constructor for objects of class Weapon con parámetros 
     */
    public Weapon(String name, int ammunition)
    {
        setName(name);
        setAmmunition(ammunition);

    }

    /**
     *  Método que modifica el valor del atributo name
     *
     * @param cambia el valor del atributo name del tipo String
     * 
     */
    private void setName (String name)
    {
        this.name = name;
    }

    /**
     *  Método que modifica el valor del atributo ammunition
     *
     * @param cambia el valor del atributo ammunition del tipo int
     * 
     */
    private void setAmmunition (int ammunition)
    {
        if ((ammunition >=  MIN_AMMUNITION) && (ammunition <= MAX_AMMUNITION))
            this.ammunition = ammunition;
    }

    /**
     * Método que devuelve el valor del atributo ammunition
     *
     * @return devuelve el valor del atributo ammunition del tipo int
     */
    public int getAmmunition()
    { 
        return ammunition ;
    }

    /**
     * Método que devuelve el valor del atributo name
     *
     * @return devuelve el valor del atributo name del tipo String
     */
    public String getName()
    { 
        return name ;
    }

    /**
     * Método shoot para disparar
     *
     * 
     * @return Si tiene munición imprime por pantalla “BANG” y disminuye una unidad la munición. Si no tiene munición no hace nada.
     */
    public void shoot()
    {
        if (getAmmunition() > MIN_AMMUNITION )
        {
            System.out.println("BANG");
            setAmmunition(getAmmunition() - 1);      
        }
    }
    
     /**
     * Método que devuelve la información del arma, su nombre y la cantidad de municion que tiene
     *
     * 
     * @return devuelve una cadena con el nombre del arma y la cantidad de munición
     */

    public String toString()
    { 
        return (this.getName() + "(" + this.getAmmunition() + ")");   
    
    }
}
