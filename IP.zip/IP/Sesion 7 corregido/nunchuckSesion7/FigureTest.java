

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class FigureTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class FigureTest
{
    /**
     * Default constructor for test class FigureTest
     */
    public FigureTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }

    @Test
    public void testSetName()
    {
        //Caso 1: creamos objeto figure con un nombre Gema
        Figure figure1 = new Figure("Gema", 0, 0);
        assertEquals("Gema", figure1.getName());
        //Caso 2: creamos objeto figure con un nombre Nuria
        Figure figure2 = new Figure("Nuria", 0, 0);
        assertEquals("Nuria", figure2.getName());        
        
    }

    @Test
    public void testSetXPos()
    {
        //PRUEBAS POSITIVAS
        
        //Caso 1: creamos objeto figure con un valor intermedio de XPos
        Figure figure1 = new Figure("name", 300, 0);
        assertEquals(300, figure1.getXPos());
        
        //Caso 2: creamos objeto figure con el valor minimo de XPos
        Figure figure2 = new Figure("name", 0, 0);
        assertEquals(0, figure2.getXPos());
        
        //Caso 3: creamos objeto figure con el valor maximo de XPos
        Figure figure3 = new Figure("name", 640, 0);
        assertEquals(640, figure3.getXPos());
        
        //PRUEBAS NEGATIVAS
        
        //Caso 4: creamos objeto figure con un valor NEGATIVO
        Figure figure4 = new Figure("name", -2, 0);
        assertEquals(0, figure4.getXPos());
        
        //Caso 5: creamos objeto figure con un valor superior al rango
        Figure figure5 = new Figure("name", 641, 0);
        assertEquals(0, figure5.getXPos());
    }

    @Test
    public void testSetYPos()
    {
        //PRUEBAS POSITIVAS
        
        //Caso 1: creamos objeto figure con el valor minimo de YPos        
        Figure figure1 = new Figure("name", 0, 0);
        assertEquals(0, figure1.getYPos());
        
        //Caso 1: creamos objeto figure con el valor maximo de YPos   
        Figure figure2 = new Figure("name", 0, 320);
        assertEquals(320, figure2.getYPos());
        
        //Caso 1: creamos objeto figure con un valor intermedio de YPos   
        Figure figure3 = new Figure("name", 0, 130);
        assertEquals(130, figure3.getYPos());
        
        //PRUEBAS NEGATIVAS
        
        //Caso 1: creamos objeto figure con un valor NEGATIVO   
        Figure figure4 = new Figure("name", 0, -2);
        assertEquals(0, figure4.getYPos());
        
        //Caso 1: creamos objeto figure con un valor superior al rango   
        Figure figure5 = new Figure("name", 0, 321);
        assertEquals(0, figure5.getYPos());
    }

    @Test
    public void testMove()
    {
        //PRUEBAS POSITIVAS
        
        //Caso 1: creamos objeto figure con YPos  y Xpos a 0        
        Figure figure1 = new Figure();
         //ejecutamos el metodo move y se mueve un STEP (10) a la derecha
        figure1.move('R');
        assertEquals(10, figure1.getXPos());
        //Caso 2: ejecutamos el metodo move y se mueve un STEP (10) a la iquierda
        figure1.move('L');
        assertEquals(0, figure1.getXPos());
        //Caso 3: ejecutamos el metodo move y se mueve un STEP (10) hacia arriba
        figure1.move('U');
        assertEquals(10, figure1.getYPos());
        //Caso 4: ejecutamos el metodo move y se mueve un STEP (10) hacia abajo
        figure1.move('D');
        assertEquals(0, figure1.getYPos());
        
        //PRUEBAS NEGATIVAS
        
        //Caso 5: ejecutamos el metodo move y se mueve un STEP (10) hacia abajo pero como partimos del minimo no se mueve
        figure1.move('D');
        assertEquals(0, figure1.getYPos());
        //Caso 6: ejecutamos el metodo move y se mueve un STEP (10) a la iquierda pero como partimos de cero no se mueve
        figure1.move('L');
        assertEquals(0, figure1.getXPos());
    }

    @Test
    public void testToString()
    {
        //Caso 1: creamos objeto figure con un valor minimo de posiciones y nombre Player
        Figure figure1 = new Figure();
        assertEquals("Player(0,0)", figure1.toString());
        //Caso 2: creamos objeto weapon con un valor maximo de posiciones y nombre Gema
        Figure figure2 = new Figure("Gema", 640,320);
        assertEquals("Gema(640,320)", figure2.toString());
    }
}



