

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class WeaponTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class WeaponTest
{
    /**
     * Default constructor for test class WeaponTest
     */
    public WeaponTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }
    
    @Test
    public void testSetName()
    {
        //Caso 1: creamos un objeto weapon con nombre pistol
        Weapon weapon1 = new Weapon("Pistol", 0);
        assertEquals("Pistol", weapon1.getName());
        //Caso 2: creamo un objeto weapon con el nombre shotgun
        Weapon weapon2 = new Weapon("Shotgun", 0);
        assertEquals("Shotgun", weapon2.getName());        
        
    }    

    @Test
    public void testSetAmmunition()
    {
        //PRUEBAS POSITIVAS
        
        //Caso 1: creamos objeto weapon con un valor intermedio de municion
        Weapon weapon1 = new Weapon("pistol", 50);
        assertEquals(50, weapon1.getAmmunition());
        //Caso 2: creamos objeto weapon con un valor intermedio de municion
        Weapon weapon2 = new Weapon("pistol", 100);
        assertEquals(100, weapon2.getAmmunition());
        //Caso 3: creamos objeto weapon con el minimo del rango
        Weapon weapon3 = new Weapon("pistol", 0);
        assertEquals(0, weapon3.getAmmunition());
        //Caso 4: creamos objeto weapon con el valor superior del rango
        Weapon weapon4 = new Weapon("pistol", 200);
        assertEquals(200, weapon4.getAmmunition());
        
        //PRUEBAS NEGATIVAS
        
        //Caso 5: creamos objeto weapon con un valor superior al rango
        Weapon weapon5 = new Weapon("pistol", 201);
        assertEquals(0, weapon5.getAmmunition());
        //Caso 6: creamos objeto weapon con un valor NEGATIVO
        Weapon weapon6 = new Weapon("pistol", -3);
        assertEquals(0, weapon6.getAmmunition());
    }

    @Test
    public void testShoot()
    {
        //Caso 1: creamos objeto weapon con un valor intermedio de municion
        Weapon weapon1 = new Weapon("gema", 50);
        weapon1.shoot();
        assertEquals(49, weapon1.getAmmunition());
        
        //Caso 2: creamos objeto weapon con un valor minimo del rango
        Weapon weapon2 = new Weapon("gema", 0);
        weapon1.shoot();
        assertEquals(0, weapon2.getAmmunition());
    }    

    @Test
    public void testToString()
    {
        //Caso 1: creamos objeto weapon con un valor maximo de municion y nombre pistol
        Weapon weapon1 = new Weapon();
        assertEquals("Pistol(200)", weapon1.toString());
        
        //Caso 2: creamos objeto weapon con un valor intermedio de municion y nombre shotgun
        Weapon weapon2 = new Weapon("Pistol",50);
        assertEquals("Pistol(50)", weapon2.toString());
    }
}




