

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class WheelStrutTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class WheelStrutTest
{
    /**
     * Default constructor for test class WheelStrutTest
     */
    public WheelStrutTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }   

    @Test
    public void testTest()
    {
        //PRUEBAS POSITIVAS
        
        //CASO 1, creamos un objeto WheelStrut y asignamos 100 de presión max e minima
        WheelStrut wheelStr1 = new WheelStrut(100, 100);
        assertEquals(true, wheelStr1.test());
        //CASO 2, creamos un objeto WheelStrut y asignamos 200 de presión max  y 185 de minima
        WheelStrut wheelStr2 = new WheelStrut(200, 185);
        assertEquals(true, wheelStr2.test());
        //CASO 3, creamos un objeto WheelStrut y asignamos 0 de presión max y 100 minima
        WheelStrut wheelStr3 = new WheelStrut(0, 100);
        assertEquals(true, wheelStr3.test());
        
        //PRUEBAS NEGATIVAS
        
        //CASO 4, creamos un objeto WheelStrut y asignamos 100 de presión max y 0 minima
        WheelStrut wheelStr4 = new WheelStrut(100, 0);
        assertEquals(false, wheelStr4.test());
        //CASO 5, creamos un objeto WheelStrut y asignamos 500 de presión max y 100 minima
        WheelStrut wheelStr5 = new WheelStrut(500, 100);
        assertEquals(false, wheelStr5.test());
        
        WheelStrut wheelStr6 = new WheelStrut();
         wheelStr6.getLeftWheel().changePressure(900); 
         assertEquals(false, wheelStr6.test());
    }

    @Test
    public void testToString()
    {
        //CASO 1, creamos un objeto WheelStrut y asignamos 200 de presión max e minima
        WheelStrut wheelStr1 = new WheelStrut(200, 200);
        assertEquals("Deployed:true-Test:true[L:true][R:true]", wheelStr1.toString());
        //CASO 2, creamos un objeto WheelStrut y asignamos 200 de presión max y 185 de presion minima
        WheelStrut wheelStr2 = new WheelStrut(200, 185);
        assertEquals("Deployed:true-Test:true[L:true][R:true]", wheelStr2.toString());
        //CASO 3, creamos un objeto WheelStrut y asignamos 200 de presión max y 0 de presion minima
        WheelStrut wheelStr3 = new WheelStrut(200, 0);
        assertEquals("Deployed:true-Test:false[L:false][R:false]", wheelStr3.toString());
        
        
    }
    
    @Test
    public void testConstructor()
    { 
        WheelStrut wheelStr1 = new WheelStrut(3000, 2800);
         assertEquals(WheelStrut.IS_DEPLOYED,wheelStr1.isDeployed());
         assertEquals(2800, wheelStr1.getLeftWheel().getPressure(), 0.1);
         assertEquals(2800, wheelStr1.getRightWheel().getPressure(), 0.1);
    }
}




   