
/**
 *  class WheelStrut para laboratorio deIP.
 * 
 * @author Gema Rico Pozas
 * @version 25/10/2016
 */
public class WheelStrut
{
    public final static double  DEFAULT_PREASSURE_BOEING_737=1739;
    public final static boolean IS_DEPLOYED=true; //esta desplegado
    public final static boolean IS_RETRACTED=false;// esta retraido
    // instance variables 
    private Wheel leftWheel; //rueda iquierda
    private Wheel rightWheel; //rueda derecha
    private boolean deployed; // puntal 

    /**
     * Constructor for objects of class WheelStrut
     */
    public WheelStrut()
    {
        deployed=IS_DEPLOYED;
        leftWheel= (new Wheel(DEFAULT_PREASSURE_BOEING_737,DEFAULT_PREASSURE_BOEING_737));
        rightWheel= (new Wheel(DEFAULT_PREASSURE_BOEING_737,DEFAULT_PREASSURE_BOEING_737));

    }

    /**
     * Constructor for objects of class WheelStrut con parámetros
     * 
     * @param maxPressure la presion maxima
     * @param pressure la presion actual
     */

    public WheelStrut(double maxPressure, double pressure )
    {
        deployed=IS_DEPLOYED;
        leftWheel=(new Wheel(maxPressure, pressure));
        rightWheel=(new Wheel(maxPressure, pressure));        

    }

    /**
     * Método que devuelve el valor del atributo deployed
     *
     * @return devuelve el valor del atributo is deployed
     */
    public boolean isDeployed()
    { 
        return deployed ;
    }

    /**
     * Método que devuelve el valor del atributo leftWheel
     *
     * @return devuelve el valor del atributo leftWheel
     */
    public Wheel getLeftWheel()
    { 
        return leftWheel ;
    }

    /**
     * Método que devuelve el valor del atributo rightWheel
     *
     * @return devuelve el valor del atributo rightWheel
     */
    public Wheel getRightWheel()
    { 
        return rightWheel ;
    }

    /**
     * Método test que devuelve true si ambas ruedas pasan el test y false si no lo pasan
     *
     * 
     * @return true si ambas ruedas pasan el test y false si no lo pasan
     */
    public boolean test()
    {
        if (( this.leftWheel.test() == true ) && ( this.rightWheel.test() == true))
            return true;
        else
            return false;
    }

    /**
     * Método toString que devuelve el estado del puntal
     *
     * 
     * @return devuelve el estado puntual del puntal con el siguiente formato :
     *      Deployed: true - Test: true [L: true] [R: true]
     */
    public String toString()
    {
        return ("Deployed:" + this.isDeployed() + "-" + "Test:" + this.test() + "[L:" + leftWheel.test()+ "]" + "[R:" + rightWheel.test() + "]");
    }    

    /**
     * Método que muestra por pantalla el estado del objeto de la clase WheelStrut
     *
     * @return El valor de la propiedad deployed
     *         El valor de retorno del método test()
     *         El resultado de la ejecución del método print() sobre cada rueda
     */
    public void print ()
    {
        if ( this.isDeployed() == true)
            System.out.println("DEPLOYED");  
        else if (this.isDeployed() == false)
            System.out.println("RETRACTED");
        if (this.test() == true)
            System.out.println("Test.......... OK");
        else if(this.test() == false)
            System.out.println("Test.......... FAIL");        
        System.out.println("LEFT Wheel");
        leftWheel.print();
        System.out.println("RIGHT Wheel");
        rightWheel.print();
    }
    
    /**
     *  Método que modifica el valor del atributo DEPLOYED
     *  
     * @param cambia el valor del atributo deployed del tipo boolean
     * 
     */
    private void setDeployed (boolean deployed)
    {
        this.deployed = deployed;
    }
    
    /**
     * Método que cambia el valor del puntal a retracted
     *
     * @param  cambia el valor del puntal a retracted, false
     * 
     */
    public void retract()
    {
        this.setDeployed(IS_RETRACTED);
    }
    
    /**
     * Método que cambia el valor del puntal a deployed
     *
     * @param cambia el valor del puntal a deployed, true
     * 
     */
    public void deployed()
    {
        setDeployed(IS_DEPLOYED);
    }

}
   
    
    
    
    
    
    
    
    
    
    
