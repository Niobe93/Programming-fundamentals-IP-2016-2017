

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class BridgeControllerTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class BridgeControllerTest
{
    /**
     * Default constructor for test class BridgeControllerTest
     */
    public BridgeControllerTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }    

    @Test
    public void testSetLever()
    {
        //PRUEBAS POSITIVAS
        //Creamos un objeto bridgecontroller
        BridgeController bridgeCo1 = new BridgeController();
        //comprobamos que los valores inciales de la palanca es 0
        assertEquals(BridgeController.LEVER_DOWN, bridgeCo1.getLever());
        //CASO 1 activamos el embrague y cambiamos el valor de la palanca a 1
        bridgeCo1.changeClutch();
        bridgeCo1.changeLever(BridgeController.LEVER_MIDLE);
        assertEquals(BridgeController.LEVER_MIDLE, bridgeCo1.getLever());
        //CASO 2cambiamos el valor de la palanca a 2
        bridgeCo1.changeLever(BridgeController.LEVER_UP);
        assertEquals(BridgeController.LEVER_UP, bridgeCo1.getLever());
        
        //PRUEBAS NEGATIVAS
        //CASO 3 cambiamos el valor de la palanca a 3 pero como no es un valor correcto no se modifica        
        bridgeCo1.changeLever(3);
        assertEquals(BridgeController.LEVER_UP, bridgeCo1.getLever());        
        //CASO 4 cambiamos el valor de la palanca a -3 pero como no es un valor correcto no se modifica
        bridgeCo1.changeLever(-3);
        assertEquals(BridgeController.LEVER_UP, bridgeCo1.getLever());
    }

    @Test
    public void testSetClutch()
    {
        //PRUEBAS POSITIVAS
        //CASO 1 creamos un objeto bridgecontroller
        BridgeController bridgeCo1 = new BridgeController();
        //comprobamos que los valores incial del embrague es no presionado
        assertEquals(BridgeController.NO_PRESSED, bridgeCo1.getClutch());
        //activamos el embrague y cambia a presionado
        bridgeCo1.changeClutch();
        assertEquals(BridgeController.PRESSED, bridgeCo1.getClutch());
        //CASO 2 activamos el embrague y cambia a no presionado
        bridgeCo1.changeClutch();
        assertEquals(BridgeController.NO_PRESSED, bridgeCo1.getClutch());
        //CASO 3 llamamos dos veces al metodo y comprobamos que cambia de estado dos veces(no presionado-presionado-no presionado)
        bridgeCo1.changeClutch();
        bridgeCo1.changeClutch();
        assertEquals(BridgeController.NO_PRESSED, bridgeCo1.getClutch());
    }

    @Test
    public void testChangeClutch()
    {
        //PRUEBAS POSITIVAS
        //CASO 1 creamos un objeto bridgecontroller
        BridgeController bridgeCo1 = new BridgeController();
        //comprobamos que los valores incial del embrague es no presionado
        assertEquals(BridgeController.NO_PRESSED, bridgeCo1.getClutch());
        //CASO 2activamos el embrague y cambia a presionado
        bridgeCo1.changeClutch();
        assertEquals(BridgeController.PRESSED, bridgeCo1.getClutch());
        //CASO 3llamamos dos veces al metodo y comprobamos que cambia de estado dos veces(presionado-no presionado-presionado)
        bridgeCo1.changeClutch();
        bridgeCo1.changeClutch();
        assertEquals(BridgeController.PRESSED, bridgeCo1.getClutch());
    }

    @Test
    public void testChangeLever()
    {
        //PRUEBAS POSITIVAS
        //Creamos un objeto bridgecontroller
        BridgeController bridgeCo1 = new BridgeController();
        //comprobamos que los valores inciales de la palanca es 0
        assertEquals(BridgeController.LEVER_DOWN, bridgeCo1.getLever());
        //activamos el embrague y cambiamos el valor de la palanca a 1 y comprobamos que el grado del puente cambia a 30
        bridgeCo1.changeClutch();
        bridgeCo1.changeLever(BridgeController.LEVER_MIDLE);
        assertEquals(BridgeController.LEVER_MIDLE, bridgeCo1.getLever());        
        assertEquals(30, bridgeCo1.getSlope());
        
        //CASO 2cambiamos el valor de la palanca a 2 y comprobamos que el grado del puente cambia a 60
        bridgeCo1.changeLever(BridgeController.LEVER_UP);
        assertEquals(BridgeController.LEVER_UP, bridgeCo1.getLever());        
        assertEquals(60, bridgeCo1.getSlope());
        
        //CASO 3cambiamos el valor de la palanca a 1 y comprobamos que el grado del puente cambia a 30
        bridgeCo1.changeLever(BridgeController.LEVER_MIDLE);
        assertEquals(BridgeController.LEVER_MIDLE, bridgeCo1.getLever());        
        assertEquals(30, bridgeCo1.getSlope());
        
        //CASO 4cambiamos el valor de la palanca a 0 y comprobamos que el grado del puente cambia a 0
        bridgeCo1.changeLever(BridgeController.LEVER_DOWN);
        assertEquals(BridgeController.LEVER_DOWN, bridgeCo1.getLever());        
        assertEquals(BridgeController.LEVER_DOWN, bridgeCo1.getSlope());
        
        //PRUEBAS NEGATIVAS
        //CASO 5 cambiamos el valor de la palanca a 3 y comprobamos que no cambia ya que es un valor de palanca no valido
         bridgeCo1.changeLever(3);
        assertEquals(BridgeController.LEVER_DOWN, bridgeCo1.getLever());        
        assertEquals(BridgeController.LEVER_DOWN, bridgeCo1.getSlope());
         //CASO 6 activamos el embrague y cambiamos la palanca a 2 pero como el embrague no esta presionado no se modifican los valores
        bridgeCo1.changeClutch();
         bridgeCo1.changeLever(BridgeController.LEVER_UP);
        assertEquals(BridgeController.LEVER_DOWN, bridgeCo1.getLever());        
        assertEquals(BridgeController.LEVER_DOWN, bridgeCo1.getSlope());
    }
}





