
/**
 * Class BridgeController fo IP laboratory.
 * 
 * @author Gema Rico Pozas 
 * @version 05/11/2016
 */
public class BridgeController
{
    public static final int LEVER_UP=2;
    public static final int LEVER_DOWN=0;
    public static final int LEVER_MIDLE=1;
    public static final boolean PRESSED=true;
    public static final boolean NO_PRESSED=false;

    // instance variables 
    private int lever; //3 posiciones: 0 ( puente bajado) 1 (el puente tiene una apertura de 30 grados) y 2 (el puente tiene una apertura de 60 grados). 
    private boolean clutch;
    private BasculeBridge bridge; 

    /**
     * Constructor for objects of class BridgeController
     */
    public BridgeController()
    {
        lever=LEVER_DOWN;
        clutch=NO_PRESSED;
        bridge=new BasculeBridge(0);
    }    

    /**
     * Constructor for objects of class BridgeController with parameters
     * //  Palanca con 3 posiciones: 0 (el puente estará completamente bajado) 1 (30 grados) y 2 ( 60 grados). 
     */
    public BridgeController(int leverPosition)
    {
        this();
        setLever(leverPosition);
        clutch=NO_PRESSED;
        bridge=new BasculeBridge(getLever()*30);
    }    

    /**
     * Método que modifica el valor de la palanca
     * 
     * @param nuevo valor de la palanca
     * 
     */
    private void setLever(int lever)
    {
        if((lever >= LEVER_DOWN) && (lever <= LEVER_UP))
            this.lever=lever;
    }

    /**
     * Método que devuelve el valor de la palanca
     *
     * 
     * @return   valor de la palanca
     */
    public int getLever()
    {
        return lever;
    }

    /**
     * Método que devuelve el valor de la inclinacion
     *
     * 
     * @return   valor de la inclinacion
     */
    public int getSlope()
    {
        return bridge.getSlope();
    }

    /**
     * Método que modifica el valor del embrague
     * 
     * @param nuevo valor del embrague
     * 
     */
    private void setClutch(boolean clutch)
    {
        this.clutch=clutch;
    }

    /**
     * Método que devuelve el valor del embrague
     * 
     * @return valor del embrague
     * 
     */
    public boolean getClutch()
    {
        return clutch;
    }

    /**
     * Método que presiona el embrague
     *
     * //cambia la presión del embrague (si estaba presionado deja de estarlo y viceversa). 
     */
    public void changeClutch()
    {
        if (clutch == PRESSED)
            setClutch(NO_PRESSED);
        else
            setClutch(PRESSED);
    }

    /**
     * Método que cambiando el valor de la palanca modifica la inclinacion del puente levadizo
     *
     * @param  recibe como parámetro la nueva posición de la palanca, que deberá ser (0,1 o 2).
     *       En caso de que el embrague esté presionado comprueba si debe levantar o bajar el puente y calcula los grados para hacer que el puente
    modifique su inclinación. Si el embrague no está presionado o la nueva posición de la palanca no es correcta, no modifica el valor de la palanca
     * 
     */
    public void changeLever (int leverPosition)
    {

        if( clutch==PRESSED) 
        { 
            if (getLever() < leverPosition)
                bridge.raiseBridge((leverPosition - getLever())*30);

            else
                bridge.dropBridge((getLever() - leverPosition)*30);            
            setLever(leverPosition);   
        }
    }
}
