
/**
 * Class BasculeBridge para laboratorio de IP.
 * 
 * @author Gema Rico Pozas
 * @version (05/11/2016)
 */
public class BasculeBridge
{
    public final static int MAX_SLOPE=60; //maximo valor de inclinacion
    public final static int MIN_SLOPE=0;  //minimo valor de inclinacion

    // instance variables 
    private int slope;

    /**
     * Constructor for objects of class BasculeBridge
     */
    public BasculeBridge(int slope)
    {
        setSlope(slope);

    }

    /**
     * Método que modifica el valor del atributo slope
     * 
     * @param nuevo valor de slope del tipo int
     * 
     */
    private void setSlope(int slope)
    {
        if((slope<=MAX_SLOPE) && (slope>=MIN_SLOPE))
            this.slope=slope;
    }

    /**
     * Método que devuelve el valor del atributo slope
     *
     * 
     * @return  devuelve el valor del atributo slope
     */
    public int getSlope()
    {
        return slope;
    }
    
    /**
     * Método que modifica la posicion del puente incrementándola
     *
     * @param  modifica la posición del puente, incrementándola en la cantidad que recibe como parámetro. Sólo podrá recibir valores positivos. 
     * 
     */
    public void raiseBridge(int newSlope)
    {
        if (newSlope >0)
          setSlope(getSlope() + newSlope);
    }
    
    /**
     * Método que modifica la posición del puente decrementándola 
     *
     * @param  modifica la posición del puente decrementándola en la cantidad que recibe como parámetro. Sólo podrá recibir valores positivos. 
     * 
     */
    public void dropBridge(int newSlope)
    {
        if (newSlope >0)
          setSlope(getSlope() - newSlope);
    }



}
