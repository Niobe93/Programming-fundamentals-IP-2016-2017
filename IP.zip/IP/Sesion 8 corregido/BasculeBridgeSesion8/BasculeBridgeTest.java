

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class BasculeBridgeTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class BasculeBridgeTest
{
    /**
     * Default constructor for test class BasculeBridgeTest
     */
    public BasculeBridgeTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }
    

    @Test
    public void testSetSlope()
    {
        //PRUEBAS POSITIVAS
        //CASO 1 creamos un objeto BasculeBridge y comprobamos que los valores inciales de slope es 0
        BasculeBridge basculeB1 = new BasculeBridge(BasculeBridge.MIN_SLOPE);
        assertEquals(BasculeBridge.MIN_SLOPE, basculeB1.getSlope());
        //CASO 2 creamos un objeto BasculeBridge con un valor 20 de slope
        BasculeBridge basculeB2 = new BasculeBridge(20);
        assertEquals(20, basculeB2.getSlope());
        //CASO 3 creamos un objeto BasculeBridge con un valor 50 de slope
        BasculeBridge basculeB3 = new BasculeBridge(50);
        assertEquals(50, basculeB3.getSlope());
        //CASO 4 creamos un objeto BasculeBridge con un valor 60 de slope
        BasculeBridge basculeB4 = new BasculeBridge(BasculeBridge.MAX_SLOPE);
        assertEquals(BasculeBridge.MAX_SLOPE, basculeB4.getSlope());
        
        //PRUEBAS NEGATIVAS
        //CASO 5 creamos un objeto BasculeBridge con un valor NEGATIVO de slope
        BasculeBridge basculeB5 = new BasculeBridge(-3);
        assertEquals(BasculeBridge.MIN_SLOPE, basculeB5.getSlope());
        //CASO 6 creamos un objeto BasculeBridge con un valor SUPERIOR al rango de slope
        BasculeBridge basculeB6 = new BasculeBridge(61);
        assertEquals(BasculeBridge.MIN_SLOPE, basculeB6.getSlope());
        
    }

    @Test
    public void testRaiseBridge()
    {
        //PRUEBAS POSITIVAS
        //CASO 1 creamos un objeto BasculeBridge con un valor inicial de 20 slope, llamamos al metodo e incrementamos 10, comprobamos que resulta 30
        BasculeBridge basculeB1 = new BasculeBridge(20);
        basculeB1.raiseBridge(10);
        assertEquals(30, basculeB1.getSlope());
        //CASO 2 llamamos al metodo e incrementamos 30, comprobamos que resulta 60 o el maximo
         basculeB1.raiseBridge(30);
        assertEquals(BasculeBridge.MAX_SLOPE, basculeB1.getSlope());
        
        //PRUEBAS NEGATIVAS
        //CASO 3 llamamos al metodo e incrementamos en 10, pero como ya estaba en el maximo el valor no cambia
         basculeB1.raiseBridge(10);
        assertEquals(BasculeBridge.MAX_SLOPE, basculeB1.getSlope());          
        
    }

    @Test
    public void testDropBridge()
    {
        //PRUEBAS POSITIVAS
        //CASO 1 creamos un objeto BasculeBridge con un valor inicial de 50 slope, llamamos al metodo y reducimos 10, comprobamos que resulta 40
        BasculeBridge basculeB1 = new BasculeBridge(50);
        basculeB1.dropBridge(10);
        assertEquals(40, basculeB1.getSlope());
        //CASO 2 llamamos al metodo y reducimos 30 y comprobamos que resulta 10
         basculeB1.dropBridge(30);
        assertEquals(10, basculeB1.getSlope());
        //CASO 2 llamamos al metodo y reducimos 10 y comprobamos que queda en el limite inferior 0
         basculeB1.dropBridge(10);
        assertEquals(BasculeBridge.MIN_SLOPE, basculeB1.getSlope());
        
        //PRUEBAS NEGATIVAS
        //CASO 3 llamamos al metodo y reducimos 10 pero como estaba en el minimo el valor no cambia
         basculeB1.dropBridge(10);
        assertEquals(BasculeBridge.MIN_SLOPE, basculeB1.getSlope());
        
        
    }
}



