

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class TeamTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class TeamTest
{
    /**
     * Default constructor for test class TeamTest
     */
    public TeamTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }

    @Test
    public void testAddPlayer()
    {
        // creamos un equipo con 5 jugadores
        Team team1 = new Team(5);
        //añadimos un nuevo jugador y comprobamos que se añade a la colección
        team1.add(new Player());
        assertEquals(6, team1.getSize());
        //añadimos un nuevo jugador y comprobamos que se añade a la colección
        team1.add(new Player("Gema",2));
        assertEquals(7, team1.getSize());
        // creamos un equipo con 0 jugadores y nos da error porque al menos tiene que haber un jugador
        try 
        {
           Team team2 = new Team(0);
        }
        catch (Exception ex)
        {
            assertEquals("Error: tiene que haber al menos un jugador", ex.getMessage());
        }
    }    

    @Test
    public void testAddPlayerIndex()
    {
        //PRUEBAS POSITIVAS
        // CASO 1 creamos un equipo con 10 jugadores y añadimos 5 jugadores con diferentes posiciones y comprobamos que están en las posiciones indicadas
        Team team1 = new Team(10);
        //posicion 0
        assertEquals(0, team1.add(new Player("Gema",1), 0));
        
        //posicion 1
        assertEquals(1, team1.add(new Player("Gema",1), 1));
        
        //posicion 3
        assertEquals(3, team1.add(new Player("Gema",1), 3));
        
        //posicion 5
        assertEquals(5, team1.add(new Player("Gema",1), 5));
        
        //posicion 9
        assertEquals(9, team1.add(new Player("Gema",1), 9));
        
        
        //PRUEBAS NEGATIVAS
        //creamos un equipo de 1 jugador y añadimos otro a la posición 10, y nos da error porque la posición que introducimos es mayor que el tamaño de la colección
        try 
        {
           Team team2 = new Team(1);
           team2.add(new Player("Gema",1),10);
        }
        catch (Exception ex)
        {
            assertEquals("Error: posición mayor que el tamaño de la colección", ex.getMessage());
        }
           
    }   

    @Test
    public void testSeekNumber()
    {
        //PRUEBAS POSITIVAS
        //CASO 1creamos un equipo de 5 jugadores
        Team team1 = new Team(5);
        
        //añadimos 3 jugadores con diferentes numeros
        team1.add(new Player("Ana",2));
        
        team1.add(new Player("Pedro",10));
        
        team1.add(new Player("Gema",25));
        
        //Comprobamos que llamando al método seeknumber nos devuelven los jugadores que tienen ese número
        
        assertEquals("Player:Gema,Number:25", team1.seekPlayer(25));
        
        assertEquals("Player:Pedro,Number:10", team1.seekPlayer(10));
        
        assertEquals("Player:Ana,Number:2", team1.seekPlayer(2));
        
        //PRUEBAS NEGATIVAS
        
        //Comprobamos que cuando buscamos por el jugador de un número que no tiene nadie nos devuelve null
        
        assertEquals(null, team1.seekPlayer(3));
        
        assertEquals(null, team1.seekPlayer(50));
    }    

    @Test
    public void testTrainPlayers()
    {
        //PRUEBAS POSITIVAS
        
        //CASO 1Creamos un equipo con un jugador numero 1, y añadimos varios jugadores con diferentes numeros(pares e impares)
        Team team1 = new Team(1);
        
        team1.add(new Player("Gema",2));
        
        team1.add(new Player("Maria",3));
        
        team1.add(new Player("Ana",4));
        
        team1.add(new Player("Jorge",5));   
        
           //comprobamos que imprime solo los jugadores impares
        assertEquals("[Player:jugador,Number:1, Player:Maria,Number:3, Player:Jorge,Number:5]",team1.trainPlayers().toString());
        
        
        //CASO 2Creamos un equipo con un jugador numero 1, y añadimos varios jugadores solo con numeros pares
        Team team2 = new Team(1);
        
        team2.add(new Player("Gema",2));
        
        team2.add(new Player("Maria",2));
        
        team2.add(new Player("Ana",4));
        
        team2.add(new Player("Jorge",4));   
        
          //comprobamos que imprime solo  el jugador 1 porque el resto no tiene numero impar 
        assertEquals("[Player:jugador,Number:1]",team2.trainPlayers().toString());
        
        //PRUEBAS NEGATIVAS
        //CASO 3Creamos un equipo con un jugador numero 1, lo borramos y añadimos solo jugadores con numeros pares
        Team team3 = new Team(1);
        
        team3.add(new Player("Gema",2));
        
        team3.add(new Player("Maria",2));
        
        team3.add(new Player("Ana",4));
        
        team3.add(new Player("Jorge",4));  
        
        team3.removePlayer(1);
          //comprobamos que la colección está vacía porque no hay jugadores con número impar
        assertEquals("[]",team3.trainPlayers().toString());
        
    }

    @Test
    public void testRemovePlayers()
    {
        //CASO 1 Creamos un equipo con un jugador numero 1, y añadimos varios jugadores con diferentes numeros
        Team team1 = new Team(1);
        
        team1.add(new Player("Gema",2));
        
        team1.add(new Player("Maria",3));
        
        team1.add(new Player("Ana",4));
        
        team1.add(new Player("Jorge",5));   
        
        //comprobamos el tamaño de la colección
        assertEquals(5,team1.getSize());
        
        //llamamos al método removePlayers y eliminamos al jugador con número 3
        team1.removePlayer(3);
        
        //Comprobamos que el tamaño de la colección ahora es 4
        assertEquals(4,team1.getSize());
        
        //comprobamos que se ha eliminado al jugador con el número 3
        assertEquals(null ,team1.seekPlayer(3));
        
        //CASO 2 eliminamos al jugador con el número 5
        team1.removePlayer(5);
        
        //Comprobamos que el tamaño de la colección ahora es 3
        assertEquals(3,team1.getSize());
        
        //comprobamos que se ha eliminado al jugador con el número 5
        assertEquals(null ,team1.seekPlayer(5));
        
        
        //PRUEBAS NEGATIVAS
        
        //CASO 3 eliminamos al jugador con un número que está en la colección
        team1.removePlayer(5);
        
        //Comprobamos que el tamaño de la colección no cambia puesto que no existía tal jugador
        assertEquals(3,team1.getSize());
        
    }
}









