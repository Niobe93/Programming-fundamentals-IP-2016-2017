

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class PlayerTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class PlayerTest
{
    /**
     * Default constructor for test class PlayerTest
     */
    public PlayerTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }

    @Test
    public void testConstructor()
    {
        //CASO 1 creamos un objeto jugador con un nombre y un numero correctos
        Player player = new Player("Gema", 1);
        assertEquals("Gema", player.getName());
        assertEquals(1, player.getNumber());
        //CASO 2 creamos un objeto jugador con un nombre y un numero correctos
        Player player2 = new Player("Gema", 10);
        assertEquals("Gema", player2.getName());
        assertEquals(10, player2.getNumber());
        //CASO 3 creamos un objeto jugador con un nombre y un numero correctos
        Player player3 = new Player("Gema", 50);
        assertEquals("Gema", player3.getName());
        assertEquals(50, player3.getNumber());
        
        //PRUEBAS NEGATIVAS
        //CASO 4 creamos un objeto jugador con un numero superior al maximo
        Player player4 = new Player("Gema", 55);
        assertEquals("Gema", player4.getName());
        assertEquals(1, player4.getNumber());
        //CASO 5 creamos un objeto jugador con un  numero inferior al minimo
        Player player5 = new Player("Gema", 0);
        assertEquals("Gema", player5.getName());
        assertEquals(1, player5.getNumber());
        
        
    }

    @Test
    public void testToString()
    {
        //CASO 1 creamos un objeto jugador con un nombre y un numero correctos
        Player jugador = new Player("Gema", 1);
        assertEquals("Player:Gema,Number:1", jugador.toString());
        //CASO 2 creamos un objeto jugador con un nombre y un numero correctos
        Player jugador1 = new Player("Mario", 10);
        assertEquals("Player:Mario,Number:10", jugador1.toString());
        //CASO 3 creamos un objeto jugador sin nombre e y un numero correctos
        Player jugador2 = new Player("", 1);
        assertEquals("Player:,Number:1", jugador2.toString());
         //CASO 4 creamos un objeto jugador con un nombre y un numero incorrecto por lo que no se cambia
        Player jugador3 = new Player("Gema", 100);
        assertEquals("Player:Gema,Number:1", jugador3.toString());
    }
}


