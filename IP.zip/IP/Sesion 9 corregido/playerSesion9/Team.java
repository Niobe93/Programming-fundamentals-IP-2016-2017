
/**
 * Class Team para laboratorio de IP.
 * 
 * @author GemaRicoPozas
 * @version 11/11/2016
 */
import java.util.ArrayList;
public class Team
{
    // instance variables 
     private  ArrayList<Player> players; //coleccion de jugadores

    /**
     * Constructor for objects of class Team
     */
    public Team(int numberOfPlayers)
    {
        if( numberOfPlayers <= 0)
         throw new RuntimeException("Error: tiene que haber al menos un jugador");
        setPlayers(numberOfPlayers);
    }

    /**
     * Método que añade el numero de jugadores a la colección 
     *
     * @param numero de jugadores
     * 
     */
    private void setPlayers(int numberOfPlayers)
    {
       players = new ArrayList<Player>();
        for(int i=0; i< numberOfPlayers; i++)
       {
         players.add(new Player(Player.DEFAULT_NAME,Player.MIN_NUMBER_OF_PLAYERS));
       }
    }
    
    /**
     * Método que añade 1 jugador a la colección 
     * 
     */
    public void add(Player player)
    {
        players.add(player);      
    }    
    
     /**
     * Método que añade 1 jugador a la colección 
     * 
     */
    public int add(Player player, int index)
    {
        if(( index >= 0) && (index <= getSize()))           
          players.add(index, player); 
        else
         throw new RuntimeException("Error: posición mayor que el tamaño de la colección");         
        return players.indexOf(player);

    }
    
    /**
     * Método que devuelve el jugador que tenga el número pasado como parámetro
     * 
     * @return devuelve el jugador que tenga el número pasado como parámetro o null si no hay jugador con ese número
     */
    public String seekPlayer(int number)
    {
        for(int i=0; i<players.size() ; i++)
        { 
          while(number==getPlayers(i).getNumber())
            return getPlayers(i).toString();
        } 
        return null;
    } 
    
    /**
     * Método que elimina de la colección el jugador cuyo número se pasa como parámetro.
     *
     * @param  número del jugador
     * 
     */
    public void removePlayer(int number) 
    {
        for(int i=0; i< players.size(); i++)
         {
         if(getPlayers(i).getNumber()==number)
           players.remove(i);
        }        
    }
    
    /**
     * Método que devuelve un ArrayList con los jugadores que tienen un número impar.
     *
     * 
     * @return devuelve un ArrayList con los jugadores que tienen un número impar.
     */
    public ArrayList<Player> trainPlayers()
    {
       ArrayList<Player> impares = new ArrayList<Player>();         
       for(int i=0; i< players.size(); i++)
         {
         if(getPlayers(i).getNumber()%2!=0)
          impares.add(getPlayers(i));
        }         
       return impares;
    }
    
    /**
     * Método que muestra los jugadores por consola.
     *
     * 
     * @return  muestra los jugadores por consola
     */
    public void seeContacts()
    {
         for(int i =0; i< players.size(); i++)
        {
             System.out.println (getPlayers(i).toString());
        }
    }
    
    //Metodos para el constructor
    
    /**
     * Método que devuelve el tamaño de la colección
     *
     * 
     * @return  tamaño de la colección
     */
    public int getSize()
    {
        return players.size();
    }
    
    /**
     * Método que devuelve la posición de la colección
     *
     * 
     * @return  el objeto que está en la posicion index
     */
    public Player getPlayers(int index)
    {
        return players.get(index);
    }   
    
}
