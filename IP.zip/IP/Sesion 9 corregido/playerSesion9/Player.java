
/**
 * Class Player para laboratorio de IP
 * 
 * @author GemaRicoPozas 
 * @version 11/11/2016
 */
public class Player
{
    public final static int MAX_NUMBER_OF_PLAYERS=50;
    public final static int MIN_NUMBER_OF_PLAYERS=1;
    public final static String DEFAULT_NAME="jugador";
    // instance variables
    private int number;
    private String name;

    /**
     * Constructor for objects of class Player with parameters
     */
    public Player(String name,int number)
    {
        this();
        setName(name);
        setNumber(number);
    }
    
     /**
     * Constructor for objects of class Player
     */
    public Player()
    {
        setName(DEFAULT_NAME);
        setNumber(MIN_NUMBER_OF_PLAYERS);
    }

    /**
     * Método que modifica el atributo name
     * 
     * @param  nuevo nombre
     * 
     */
    private void setName(String name)
    {
        this.name=name;       
    }
    
     /**
     * Método que modifica el atributo number
     * 
     * @param  nuevo numero de jugador
     * 
     */
    private void setNumber(int number)
    {
       if (number>=MIN_NUMBER_OF_PLAYERS && number<=MAX_NUMBER_OF_PLAYERS)
        this.number=number;       
    }
    
    /**
     * Método que devuelve el valor del atributo name
     * 
     * @return name
     * 
     */
    public String getName()
    {
        return this.name;       
    }
    
    /**
     * Método que devuelve el valor del atributo number
     * 
     * @return number
     * 
     */
    public int getNumber()
    {
        return this.number;       
    }
    
    /**
     * Método que devuelve el valor de los atributos name y number 
     * 
     * @return name y number con este formato " Player: Gema, Number: 2 "
     * 
     */
    public String toString()
    {
        return ("Player:"  +  this.getName()  +  ","  +  "Number:"  +  this.getNumber());    
    }
    
    
}
