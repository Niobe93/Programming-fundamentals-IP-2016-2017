
/**
 * Class SeatManager. 
 * 
 * @author Gema Rico Pozas 
 * @version 6/2/2017
 */
import java.util.ArrayList;
import java.util.Random;
public class SeatManager
{   
    //CONSTANTES
    public final static int DEFAULT_ROWS = 4;
    public final static int DEFAULT_COLUMNS=4;

    public final static int MAX_ROWS=10;    
    public final static int MAX_COLUMNS=4;
  
    // ATRIBUTOS
    private Person [][] seats;    

    /**
     * Constructor for objects of class SeatManager
     */
    public SeatManager()
    {
        setFirstRows(DEFAULT_FIRST_ROWS);
        setStandardRows(DEFAULT_STANDARD_ROWS);  
        seats = new Person [getFirstRows() + getStandardRows()][ DEFAULT_COLUMNS];
    }

    /**
     * Constructor for objects of class SeatManager con parametros
     * 
     * @param el numero de filas en primera
     * @param el numero de filas es standard
     * 
     */    
    public SeatManager(int first, int standard)
    {
        this();
        setFirstRows(first);
        setStandardRows(standard); 
        seats = new Person [getFirstRows() + getStandardRows()][ DEFAULT_COLUMNS];
    }

    /**
     * Asigna el numero de filas en primera
     * 
     * @param  numero de filas en primera de tipo int
     * 
     */
    private void setFirstRows(int rows)
    {
        if ( rows < MIN_FIRST_ROWS ) 
            throw new RuntimeException ("Error: el numero de filas en primera no alcanza el minimo");
        this.firstRows= rows; 
    }

    /**
     * Asigna el numero de filas en standard
     * 
     * @param  numero de filas en turista de tipo int
     * 
     */
    private void setStandardRows(int rows)
    {
        if ( rows < MIN_STANDARD_ROWS ) 
            throw new RuntimeException ("Error: el numero de filas en segunda no alcanza el minimo");
        this.standardRows= rows; 
    }

    /**
     * Método que devuelve el valor de las filas de la pimera fila
     *
     * 
     * @return  numero de filas primera
     */
    public int getFirstRows()
    {
        return firstRows;
    }

    /**
     * Método que devuelve el valor de las filas de clase turista
     *
     * 
     * @return  numero de filas turista
     */
    public int getStandardRows()
    {
        return standardRows;
    }

    /**
     * Metodo que reserva un asiento para la persona recibida como parametro 
     * en la fila y columna recibida como parametro
     *
     * @param  persona para la reserva de tipo person
     * @param columna de la matriz
     * @param fila de la matriz
     * 
     * @return True si puede sentarse o false si esta ocupado
     */
    public boolean bookSeat(Person person, int column, int row)
    {
        if ((person == null) || (column < 0) || (column >=DEFAULT_COLUMNS) || ( row <0 ) || (row > seats.length))
            throw new RuntimeException("Error: parametros incorrectos");
        if (seats[row][column]==null)
        {
            seats[row][column]=person; 
            return true;
        }     
        return false;        
    }

    /**
     * libera un asiento cuya fila y columna se recibe como parámetro
     *
     * @param fila
     * @param columna
     * 
     * @return persona que ha dejado el asiento de tipo person
     */
    public Person release(int row,int column)
    {
        if ((column < 0) || (column >=DEFAULT_COLUMNS) || ( row <0 ) || (row > seats.length))
            throw new RuntimeException("Error: parametros fuera de rango");

        Person personToRelease = seats[row][column];
        seats[row][column]= null;
        return  personToRelease;

    }

    /**
     * Metodo que imprime el estado de reservas del avion
     *
     * formato X X X C ? X  donde X es una persona, C es un niño, e ? si no hay nadie
     * 
     * 
     */
    public void print()
    {
        for (int i=0; i< DEFAULT_COLUMNS ; i ++)
        {
            if(i==0)            
                System.out.print("   ");
            if(i==3)
                System.out.print("  ");
            System.out.print(I.charAt(i)+" ");        
        }
        System.out.println();
        for (int i=0; i< seats.length ; i ++)
        {  
           if (i==this.getFirstRows())
                System.out.println("----------------");
           if (i<=9)
                System.out.print(i + "  ");  
           else
                System.out.print(i + " ");     
                
           for (int j=0; j < seats[i].length ; j++)
            {
                
                if (j==3)
                  System.out.print("  ");
                             
                if (seats[i][j] == null )
                    System.out.print( "? ");
                else if (seats[i][j].getAge() < 18)
                    System.out.print( "C ");
                else 
                    System.out.print( "X "); 
            }
            System.out.println();         
        }
    }

    /**
     * Metodo que devuelve el numero de asientos libres que hay en la fila pasada como parametro
     * 
     * @param numero de fila que se quiere averiguar cuantos asientos libres quedan
     * @return el numero de asientos libres de la fila pasada como parametro
     */
    public int numberOfFreeSeats (int row)
    {
        int contadorAsientos=0;
        if (( row <0 ) || (row >= seats.length))
            throw new RuntimeException("Error: parametro fuera de rango");
        else 
        {

            for (int j=0; j < seats[row].length ; j++)
            { 
                if (seats[row][j] == null )
                {
                    contadorAsientos= contadorAsientos + 1;

                }
            }

        }
        return contadorAsientos;
    }

    /**
     *  Metodo que devuelve el pasajero de más edad sentado en el avión o null si el avión está vacío.
     *
     * 
     * @return   pasajero de mas edad // null si el avión está vacio
     */
    public Person oldestPassenger ()
    {
        boolean oldest=false;
        Person oldestPassenger= new Person(0);        
        for (int i=0; i< seats.length ; i ++)
        {
            for (int j=0; j < seats[i].length ; j++)
            {  
                if(seats[i][j]!=null)
                {
                    oldest = true;
                    if (oldestPassenger.getAge()< seats[i][j].getAge())                       
                        oldestPassenger=seats[i][j];

                }
            } 
        } 
        if (oldest==false)
            oldestPassenger=null;
        return oldestPassenger;
    }   

    /**
     *  Metodo que devuelve el pasajero de menor edad sentadas en el avión 
     *
     * 
     * @return   pasajero de menor edad
     */
    private int getMinAge ()
    {
        int minAge=121;        
        for (int i=0; i< seats.length ; i ++)
        {
            for (int j=0; j < seats[i].length ; j++)
            {  
                if(seats[i][j]!=null)
                {
                    if ( seats[i][j].getAge()<= minAge)                       

                        minAge= seats[i][j].getAge();               
                }
            }
        }        
        return minAge;
    }   

    /**
     * Método que devuelve una colección con los pasajeros de menor edad  
     * 
     * 
     * @return arrayList con los pasajeros de menor edad
     */
    public ArrayList<Person> getYoungestPeople()
    {
        ArrayList<Person> youngest =new ArrayList<Person>();
        int minAge=getMinAge();
        for (int i=0; i< seats.length ; i ++)
        {
            for (int j=0; j < seats[i].length ; j++)
            {  
                if(seats[i][j]!=null)
                {
                    if ( seats[i][j].getAge()<= minAge)    
                        youngest.add(seats[i][j]);            
                }
            }
        }        
        return youngest;
    } 

    /**
     * Método que retorna un ArrayList con todos los pasajeros que son niños.
     *
     * 
     * @return  el arraylist con los pasajeros niños (<18)montados en el avión
     */
    public ArrayList<Person> childrenPassengers ()
    {
        ArrayList<Person> children =new ArrayList<Person>();
        for (int i=0; i< seats.length ; i ++)
        {
            for (int j=0; j < seats[i].length ; j++)
            { 
                if(seats[i][j]!=null)
                {
                    if(seats[i][j].getAge()<18)              
                      children.add(seats[i][j]);    
                }                            
            }
        }        
        return children;
    }

    /**
     * Método que devuelve el numero de pasajeros sentados en un área del avión 
     *
     * @param  area del avión de tipo byte.
     *     //area es definido como:
     *     // FIRST_CLASS = 1
     *     // STANDARD_CLASS = 2
     *     // ALL_CLASS = 0
     * @return  el numero de pasajeros sentados en ese area
     */
    public int getNumPax(byte area)
    {
        if ((area<ALL_CLASS) || (area>STANDARD_CLASS))
            throw new RuntimeException ("Error: parámetros incorrectos");
        int contador=0;
        if (area==0)
            contador=this.getSize();    
        if(area==1)
        { 
            for (int i=0; i < getFirstRows() ; i ++)
            {
                contador=(DEFAULT_COLUMNS -(this.numberOfFreeSeats(i)))+contador;
            }  
        }
        if (area==2)
        {  
            for (int i=getFirstRows(); i< seats.length ; i ++)
            {
                contador=(DEFAULT_COLUMNS-(this.numberOfFreeSeats(i)))+contador;
            } 
        }
        return contador;
    }  

    /**
     * Método que devuelve el número de pasajeros sentados en una sección del avión.
     * Una sección se representa mediante la primera posición de una fila y la última posición de una fila.
     * 
     * @param  row 1 de tipo int (primera fila)
     * @param  row 2 de tipo int (ultima fila)
     * @param  column 1 de tipo int (primera columna)
     * @param  column  de tipo int (ultima columna)
     * @return  devuelve el número de pasajeros sentados en la sección pasada como parámetro
     */
    public int getNumPaxBySection (int row1, int column1, int row2, int column2)
    {
        if ((row1<0) || (row2<0) || (column1<0) || (column2<0) ||(row1> seats.length) 
        ||(row2> seats.length) || (column1> DEFAULT_COLUMNS)|| (column2> DEFAULT_COLUMNS))
            throw new RuntimeException ("Error: parámetros incorrectos");

        int contador=0; 
        for (int i=row1; i<=row2 ; i ++)
        {
            for (int j=column1; j <=column2 ; j++)
            {  
                if(seats[i][j]!=null)                
                    contador ++;                 
            }
        }  
        return contador;
    }

    /**
     * Método para sentar en el avión a un número dado de pasajeros. 
     * Se irán sentando en los asientos libres desde las primeras filas del avión.
     *
     * @param numero de pasajeros de tipo int
     * 
     */
    public void loadPax (int paxNumber)
    {
        if ((paxNumber<0) || (paxNumber>(this.getFirstRows() + this.getStandardRows())*DEFAULT_COLUMNS))
            throw new RuntimeException ("Error: parámetros incorrectos");
        int contador=0;
        for (int i=0; i<seats.length ; i ++)
        {
            for (int j=0; j <DEFAULT_COLUMNS ; j++)
            {  
                if (contador<paxNumber)
                { 
                    if(seats[i][j]== null)  
                    {
                        seats[i][j]=new Person();   
                        contador++;
                    }
                }                                
            }
        }   
    }

    /**
     * Metodo para asignar automáticamente (y de manera aleatoria) asientos a un número de pasajeros aleatorio (generados automáticamente).
     *
     * @param  aleatorio generado por el metodo, numero de pasajeros a sentar
     * 
     */
    public void loadPassengers ()
    {
       Random random = new Random();
       int numero = random.nextInt(random.nextInt((this.getFirstRows() + this.getStandardRows())*DEFAULT_COLUMNS));       
       if ((numero<0) || (numero>(this.getFirstRows() + this.getStandardRows())*DEFAULT_COLUMNS))
            throw new RuntimeException ("Error: parámetros incorrectos");        
       int cont=0;        
       while( cont<=numero)
        { 
            Person person =new Person();   
            int columna = random.nextInt(DEFAULT_COLUMNS);
            int fila = random.nextInt((this.getFirstRows() + this.getStandardRows()));  
            if (this.bookSeat(person,columna,fila)==true)                         
             cont++;      
        }
    }    
    
    /**
     * Método que imprime un informe detallado de todos los pasajeros del avión
     *
     * 
     */
    public void printManifest()
    {
        System.out.println("MANIFEST");
        System.out.println("FIRST CLASS");        
        for (int i=0; i< this.getFirstRows() ; i ++)
        {
            for (int j=0; j<DEFAULT_COLUMNS ; j ++)
            {
                if (seats[i][j]!= null)                
                  System.out.println("ROW: " + i + " " + "SEAT: " + I.charAt(j) + " - " + seats[i][j].getName() + " " +
                  seats[i][j].getSurname() +  " - " + "AGE: " + seats[i][j].getAge());          
            }
        }    
        System.out.println("STANDARD CLASS"); 
        for (int i=this.getFirstRows(); i< seats.length ; i ++)
        {
            for (int j=0; j<DEFAULT_COLUMNS ; j ++)
            {
                if (seats[i][j]!= null)                
                  System.out.println("ROW: " + i + " " + "SEAT: " + I.charAt(j) + " - " + seats[i][j].getName() + " "+
                  seats[i][j].getSurname() +  " - " + "AGE: " + seats[i][j].getAge());          
            }
        }  
        System.out.println(); 
     }
     
    // Metodos para hacer las pruebas
    /**
     * Método que devuelve el valor de la persona
     *
     * 
     * @return persona
     */
    public Person getPerson(int column, int row)
    {
        if((column < 0) || (column >=DEFAULT_COLUMNS) || ( row <0 ) || (row > seats.length))
            throw new RuntimeException ("Error: parámetros incorrectos");
        return seats[row][column];
    }

    /**
     * Método que nos dice cuantos pasajeros están sentados en el avión
     *
     * 
     * @return  el numero de pasajeros sentados en el avión
     */
    public int getSize()
    {
        int contadorPassanger =0;
        for (int i=0; i< seats.length ; i ++)
        { for (int j=0; j < seats[i].length ; j++)            
            { 
                if(seats[i][j]!=null)
                    contadorPassanger ++;
            }
        }
        return contadorPassanger;
    }

}
