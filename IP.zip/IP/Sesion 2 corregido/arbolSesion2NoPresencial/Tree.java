
/**
 * Clase Tree, creado para la sesión 2 del laboratorio de IP.
 * 
 * @author Gema Rico Pozas 
 * @version 22 / 09 / 2016
 */
public class Tree
{
    // Atributos de la clase Tree.

    private String typeOfTree;
    private int maxNumberOfFlowers;
    private int numberOfFlowers;
    private int numberOfFruits;

    /**
     * Constructor for objects of class Tree
     */
    public Tree()

    {            
        // Tipo de árbol
        typeOfTree = "Manzano";
        // Máximo número de flores      
        maxNumberOfFlowers = 25;
        //Número de flores
        numberOfFlowers = 7;
        //Número de frutos
        numberOfFruits = 3;

    }  

    /**
     * Método que devuelve el tipo de árbol de la clase Tree.
     * 
     * 
     * @return tipo de árbol del tipo String.   
     */
    public String getTypeOfTree()
    {
        return typeOfTree;
    }

    /**
     * Método que devuelve el número máximo de flores de la clase Tree.
     * 
     *
     * @return número máximo de flores de tipo int.
     */
    public int getMaxNumberOfFlowers()
    {
        return maxNumberOfFlowers;
    }

    /**
     * Método que devuelve el número de flores de la clase Tree.
     *
     * 
     * @return el número de flores de tipo int.
     */
    public int getNumberOfFlowers()
    {
        return numberOfFlowers;
    }

    /**
     * Método que devuelve el número de frutos de la clase Tree.
     *
     * 
     * @return el número de frutos de tipo int.
     */
    public int getNumberOfFruits()
    {
        return numberOfFruits; 
    }

    /**
     * Método que modifica el valor del atributo typeOfTree.
     *
     * @param nuevo tipo de arbol, del tipo String.
     * 
     */
    public void setTypeOfTree(String newTypeOfTree)
    {
        typeOfTree = newTypeOfTree;
    }

    /**
     * Método que modifica el valor del atributo maxNumberOfFlowers.
     *
     * @param nuevo número máximo de flores, del tipo int.
     * 
     */
    public void setMaxNumberOfFlowers(int newMaxNumberOfFlowers)
    {
        if ( ( newMaxNumberOfFlowers >=0 ))        
            maxNumberOfFlowers = newMaxNumberOfFlowers;
    }

    /**
     * Método que modifica el valor del atributo numberOfFlowers.
     *
     * @param nuevo número de flores, del tipo int.
     * 
     */
    public void setNumberOfFlowers(int newNumberOfFlowers)
    {
        if ((newNumberOfFlowers <= maxNumberOfFlowers)&& (newNumberOfFlowers >= 0))
            numberOfFlowers = newNumberOfFlowers;
    }

    /**
     * Método que modifica el valor del atributo numberOfFruits.
     *
     * @param nuevo número de frutos, del tipo int
     * 
     */
    public void setNumberOfFruits(int newNumberOfFruits)
    {
        if ( newNumberOfFruits >=0 ) 
            numberOfFruits = newNumberOfFruits;
    }

    /**
     * Método que devuelve una cadena de caracteres.
     *
     * @return una cadena con la representación textual del objeto (estado) 
     */

    public String toString ()

    { 
        return getTypeOfTree()+ "-" + getMaxNumberOfFlowers()+  "-"  + getNumberOfFlowers()+  "-" + getNumberOfFruits();

    }

    /**
     * Método que muestra por pantalla una cadena de caracteres con información del estado de un objeto. 
     *
     */
    public void print ()
    {

        System.out.println( "Valores de las propiedades del árbol : "   +  toString() );
    }

}
